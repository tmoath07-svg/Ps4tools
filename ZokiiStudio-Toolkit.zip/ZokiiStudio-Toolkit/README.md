# Zokii Studio Toolkit

## GitHub setup (iPad friendly)

1. Upload this ZIP file itself to the **root** of your private repository using the exact name `ZokiiStudio-Toolkit.zip`.
2. Replace the repository workflow at `.github/workflows/zokii-studio.yml` with the workflow included in this package (or download the standalone YAML supplied with the package).
3. For GTA mod files, upload them under `input/`, or provide a Release tag / direct download URL when running the workflow.
4. Open **Actions → Zokii Studio - GTA V Toolkit → Run workflow**.
5. First run `audit` to check Python syntax. Then select the operation you need.

The workflow extracts `toolkit/` from `ZokiiStudio-Toolkit.zip` automatically. Do not upload the toolkit ZIP into `.github/workflows`.

## Modes

- `audit`: syntax-checks embedded Python files and creates a symbol/hash inventory.
- `convert_pc_to_ps4`: stages supported GTA V Y* files and runs the bundled 7N converter.
- `convert_and_build_rpf`: converts supported files, then attempts to build an RPF with the bundled RPFBuilder.
- `extract_ytd`: extracts YTD textures using the bundled extractor.
- `extract_rpf`: extracts RPF archives.
- `build_rpf`: attempts to build an RPF from files in `input/`.

## Important limitations

- The workflow has not been run against the user's private GitHub repository or real GTA V sample files. Passing `audit` verifies Python syntax only; it does not prove that Wine, the Windows builder, or every YFT/YTD variant works correctly.
- The bundled `ragebuilder.exe` and DLLs are Windows binaries. RPF building depends on Wine compatibility on the GitHub runner.
- The 7N converter's normal mode scans the top level of `toolkit/file_input/`; the workflow stages supported source files there.
- YTD extraction output is created beside each YTD file in the input tree. Check the workflow artifact for extracted results.

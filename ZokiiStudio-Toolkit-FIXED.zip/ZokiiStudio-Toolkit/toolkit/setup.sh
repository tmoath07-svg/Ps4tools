#!/data/data/com.termux/files/usr/bin/bash
# setup.sh — Android Dependencies Installer for Termux

set -e

echo "================================================"
echo "  Mobile Dependencies for PS4 Modding — Termux Setup"
echo "================================================"
echo ""

# Step 1 — Update Termux
echo "[1/4] Updating Termux packages..."
pkg update -y && pkg upgrade -y

# Step 2 — Install dependencies
echo "[2/4] Installing dependencies..."
pkg install git python-pip
pkg install -y python wget
pip install pycryptodome watchdog

# Step 3 — Install xow64 (Box64 + Wine)
echo "[3/4] Installing xow64 (Box64 + Wine)..."
cd $HOME
rm -rf ~/xow64
wget https://github.com/ar37-rs/xow64-wine/raw/refs/heads/main/xow64
chmod +x ~/xow64
~/xow64 install

# Step 4 — Enable sdcard access
echo "[4/4] Enabling sdcard access for Wine..."
~/xow64 sdcard=true

echo ""
echo "================================================"
echo "  Setup complete!"
echo ""
echo " Please refer to the tutorial for the next steps! "
echo ""


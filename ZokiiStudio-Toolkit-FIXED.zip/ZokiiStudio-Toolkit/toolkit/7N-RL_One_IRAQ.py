#!/usr/bin/env python3
# 7N-RL One-Click PS4 Converter
# Put source files in file_input/ and run: python converter.py

from pathlib import Path
import subprocess
import sys
import os
import traceback


def safe_subprocess_run(args, **kwargs):
    """Run external tools defensively with bounded retries and no app crash."""
    kwargs.setdefault("timeout", 3600)
    retries = max(0, int(kwargs.pop("_retries", 2)))
    label = Path(str(args[1])).name if len(args) > 1 else str(args[0])
    last_result = None
    for attempt in range(retries + 1):
        try:
            result = subprocess.run(args, **kwargs)
            if result.returncode == 0 or attempt >= retries:
                return result
            # A non-zero return can be a transient external-tool failure on
            # very large workloads. Retry a couple of times before giving up.
            print(f"\n[RETRY] External tool {label} returned code {result.returncode} "
                  f"({attempt + 1}/{retries + 1})...")
            last_result = result
        except subprocess.TimeoutExpired:
            if attempt < retries:
                print(f"\n[RETRY] External tool {label} timed out; retrying safely "
                      f"({attempt + 1}/{retries + 1})...")
                continue
            print("\n[ERROR] External process timed out after 60 minutes. The converter will stop safely.")
            return subprocess.CompletedProcess(args, 124)
        except FileNotFoundError as exc:
            print(f"\n[ERROR] Required executable was not found: {exc}")
            return subprocess.CompletedProcess(args, 127)
        except PermissionError as exc:
            print(f"\n[ERROR] Permission denied while starting external process: {exc}")
            return subprocess.CompletedProcess(args, 126)
        except OSError as exc:
            if attempt < retries:
                print(f"\n[RETRY] Could not start {label}: {exc} "
                      f"({attempt + 1}/{retries + 1})...")
                continue
            print(f"\n[ERROR] Could not start external process: {exc}")
            return subprocess.CompletedProcess(args, 125)
        except Exception as exc:
            print(f"\n[ERROR] Unexpected external-process error: {type(exc).__name__}: {exc}")
            return subprocess.CompletedProcess(args, 125)
    return last_result or subprocess.CompletedProcess(args, 125)


def _optimized_clone_tree(src, dst):
    """Clone a large build tree with hardlinks when possible, copy as fallback.

    Hardlinks avoid doubling disk I/O/space for very large DLCs. If the filesystem
    does not support them, the function transparently falls back to copy2.
    """
    import shutil
    src, dst = Path(src), Path(dst)
    dst.mkdir(parents=True, exist_ok=True)
    for entry in os.scandir(src):
        target = dst / entry.name
        if entry.is_dir(follow_symlinks=False):
            _optimized_clone_tree(entry.path, target)
        elif entry.is_file(follow_symlinks=False):
            try:
                os.link(entry.path, target)
            except (OSError, NotImplementedError):
                shutil.copy2(entry.path, target)

ASCII_BANNER = '7N-RLX7md'


def _logo_lines(width=34):
    # Clean replacement for the old oversized logo.
    # Keeps the same simple terminal look requested by the user.
    text = '7N-RLX7md'
    line = '─' * width
    padding = max(1, (width - len(text)) // 2)
    subtitle = 'First in Iraq, first in Egypt'
    subpad = max(1, (width - len(subtitle)) // 2)
    return line, (' ' * padding + text), (' ' * subpad + subtitle), line


def print_banner():
    line, text, subtitle, bottom = _logo_lines(34)
    print('\033[93m' + line + '\033[0m')
    print('\033[1;93m' + text + '\033[0m')
    print('\033[93m' + subtitle + '\033[0m')
    print('\033[93m' + bottom + '\033[0m')


def print_build_logo():
    line, text, subtitle, bottom = _logo_lines(34)
    print()
    print('\033[93m' + line + '\033[0m')
    print('\033[1;93m' + text + '\033[0m')
    print('\033[93m' + subtitle + '\033[0m')
    print('\033[93m' + bottom + '\033[0m')
    print('\033[96m' + ' ' * max(1, (34 - len('BUILDING...')) // 2) + 'BUILDING...' + '\033[0m')
    print()


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "file_input"
OUTPUT = INPUT / "archive_input"
CORE = ROOT / "core_converter.py"

SUPPORTED = {
    ".yft": ".oft", ".ydr": ".odr", ".ydd": ".odd", ".ypt": ".opt",
    ".ybn": ".obn", ".ybd": ".obd", ".yld": ".old", ".yed": ".oed",
    ".yfd": ".ofd", ".ynd": ".ond", ".ynv": ".onv", ".yvr": ".ovr",
    ".ywr": ".owr", ".ypdb": ".opdb", ".ycd": ".ocd", ".ymap": ".omap",
    ".ytyp": ".otyp", ".ymt": ".omt", ".ymf": ".omf", ".ytd": ".otd",
    ".oft": ".yft", ".odr": ".ydr", ".odd": ".ydd", ".opt": ".ypt",
    ".obn": ".ybn", ".obd": ".ybd", ".old": ".yld", ".oed": ".yed",
    ".ofd": ".yfd", ".ond": ".ynd", ".onv": ".ynv", ".ovr": ".yvr",
    ".owr": ".ywr", ".opdb": ".ypdb", ".ocd": ".ycd", ".omap": ".ymap",
    ".otyp": ".ytyp", ".omt": ".ymt", ".omf": ".ymf", ".otd": ".ytd",
}


def banner():
    # Compact two-line header requested for the file-conversion screen.
    # First line: red. Second line: yellow.
    print("\033[93m" + "-" * 66 + "\033[0m")
    print("\033[91m7USSAIN-RL&7md X 16A PRO\033[0m")
    print("\033[93mpython 7N-RL_One_IRAQ.py\033[0m")
    print("\033[93m" + "-" * 66 + "\033[0m")


def find_sources():
    # Only scan file_input itself. archive_input is deliberately excluded.
    files = []
    if not INPUT.exists():
        INPUT.mkdir(parents=True, exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for p in sorted(INPUT.iterdir(), key=lambda x: x.name.lower()):
        if p.is_file() and p.suffix.lower() in SUPPORTED:
            files.append(p)
    return files



def ask_delete_old_files():
    answer = input("\033[93m\nConversion completed!\n\nDo you want to delete the old archive_input source files? (Y/N): \033[0m").strip().upper()
    if answer in ("Y", "YES"):
        deleted = 0
        for p in INPUT.iterdir():
            if p.is_file() and p.suffix.lower() in SUPPORTED:
                try:
                    p.unlink()
                    deleted += 1
                except Exception as e:
                    print(f"Could not delete {p.name}: {e}")
        print(f"Deleted {deleted} old source file(s).")
    else:
        print("Old files kept.")


def build_rpf_option():
    answer = input("\n\033[93mDo you want to build the file? (Y/N): \033[0m").strip().upper()
    if answer not in ("Y", "YES"):
        print("\033[92mConversion completed successfully.\033[0m")
        return

    name = input("\nEnter the name you want to give the file after the build: ").strip()
    if not name:
        print("No name entered. Build cancelled.")
        return

    builder = ROOT / "RPFBuilder" / "build_rpf.py"
    if not builder.exists():
        print("[ERROR] RPFBuilder is missing.")
        return

    print("Using build source: file_input/archive_input/")
    source_dir = INPUT / "archive_input"
    if not source_dir.is_dir():
        print("[ERROR] file_input/archive_input is missing.")
        return

    print_build_logo()
    print("Starting build directly from file_input/archive_input...")
    result = safe_subprocess_run(
        [sys.executable, str(builder), str(source_dir)],
        cwd=str(builder.parent),
    )

    built = builder.parent / "Archive.rpf"
    if result.returncode == 0 and built.exists():
        finish_dir = ROOT / "Finish"
        finish_dir.mkdir(exist_ok=True)
        new_file = finish_dir / (name + ".rpf")
        built.rename(new_file)
        print(f"\033[92mBuild completed: {new_file.name}\033[0m")
    else:
        print("[ERROR] Build failed.")



def _convert_extracted_tree(extracted_root, core, root, delete_y_all=True):
    """Robust recursive DLC conversion.

    Converts only original Y* resources, places successful O* results beside the
    originals, and then removes/quarantines every remaining supported Y* source.
    The quarantine copy is kept outside the build tree so failed PC resources can
    never be packed back into the final RPF.  Folder-level failures do not abort
    the entire DLC: the next folder is processed.
    """
    import shutil
    failed = []
    converted_count = 0
    failed_root = Path(root) / "Conversion failed ❌" / "DLC One Click"
    failed_root.mkdir(parents=True, exist_ok=True)

    def quarantine(path, reason="conversion failure"):
        nonlocal failed
        path = Path(path)
        if not path.is_file():
            return
        try:
            target = failed_root / path.name
            n = 2
            while target.exists():
                target = failed_root / f"{path.stem}_{n}{path.suffix}"
                n += 1
            shutil.copy2(path, target)
            failed.append(str(path))
            path.unlink()
            print(f"  └── ⚠️ [QUARANTINED] {path.name} ({reason}) -> Conversion failed ❌")
        except Exception as exc:
            failed.append(str(path))
            print(f"  └── ⚠️ Could not quarantine {path.name}: {exc}")

    folders = [extracted_root] + [p for p in extracted_root.rglob('*') if p.is_dir()]
    folders = sorted(folders, key=lambda x: (len(x.parts), str(x).lower()))

    for folder in folders:
        try:
            supported = [
                p for p in folder.iterdir()
                if p.is_file() and p.suffix.lower().startswith('.y') and p.suffix.lower() in SUPPORTED
            ]
        except (OSError, PermissionError) as exc:
            print(f"[WARN] Could not scan folder {folder}: {exc}")
            continue
        if not supported:
            continue

        print(f"[CONVERT] {folder.relative_to(extracted_root)} — {len(supported)} resource(s)")
        try:
            result = safe_subprocess_run(
                [sys.executable, str(core), str(folder)],
                cwd=str(root),
                env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
            )
            rc = result.returncode
        except Exception as exc:
            rc = 1
            print(f"[WARN] Converter could not start for {folder}: {exc}")

        out = folder / 'archive_input'
        placed_stems = set()
        if out.is_dir():
            try:
                converted_files = [x for x in out.iterdir() if x.is_file()]
            except OSError:
                converted_files = []
            for converted in converted_files:
                target = folder / converted.name
                try:
                    if target.exists():
                        target.unlink()
                    shutil.move(str(converted), str(target))
                    placed_stems.add((target.stem.lower(), target.suffix.lower()))
                    source_ext = SUPPORTED.get(target.suffix.lower())
                    if source_ext and source_ext.startswith('.y'):
                        source = folder / f"{target.stem}{source_ext}"
                        if source.is_file():
                            try:
                                source.unlink()
                                print(f"  └── 🧹 [DELETED SOURCE] {source.name} -> {target.name}")
                            except Exception as exc:
                                print(f"  └── ⚠️ Could not delete original {source.name}: {exc}")
                    converted_count += 1
                except Exception as exc:
                    print(f"  └── ⚠️ Could not place {converted.name}: {exc}")
            try:
                # Remove any leftovers in this temporary output directory.
                shutil.rmtree(out)
            except OSError:
                pass

        # Anything still Y* after this folder's conversion is either a failed
        # conversion or an unsupported/leftover source. Quarantine it instead
        # of allowing it into a rebuilt nested RPF or the final DLC.
        if delete_y_all:
            try:
                remaining = [
                    p for p in folder.iterdir()
                    if p.is_file() and p.suffix.lower().startswith('.y') and p.suffix.lower() in SUPPORTED
                ]
            except OSError:
                remaining = []
            for original in remaining:
                quarantine(original, "not converted / leftover Y resource")

    # Last recursive guard: no supported Y* resource may remain anywhere in the
    # extracted tree. If one appears because a folder changed during processing,
    # quarantine it before any RPF build starts.
    if delete_y_all:
        try:
            leftovers = [
                p for p in extracted_root.rglob('*')
                if p.is_file() and p.suffix.lower().startswith('.y') and p.suffix.lower() in SUPPORTED
            ]
        except OSError:
            leftovers = []
        for original in leftovers:
            quarantine(original, "final safety cleanup")

    return converted_count, failed


def _remove_ps4_data_dirs(extracted_root):
    """Remove only data folders located under x64 or ps4."""
    import shutil
    removed = 0
    for data_dir in sorted(
        [d for d in extracted_root.rglob('*')
         if d.is_dir() and d.name.lower() == 'data'
         and any(part.lower() in ('x64', 'ps4') for part in d.relative_to(extracted_root).parts[:-1])],
        key=lambda d: len(d.parts), reverse=True
    ):
        try:
            shutil.rmtree(data_dir)
            if not data_dir.exists():
                removed += 1
                print(f'[DELETED DATA] {data_dir.relative_to(extracted_root)}  [OK] ✅')
        except Exception as exc:
            print(f'[ERROR] Could not delete data folder {data_dir}: {exc}')
    return removed


def _build_map_folders(extracted_root, builder, root):
    """Build map folders as <folder_name>.rpf where the folder is a direct
    child of the extracted DLC root or of x64/ps4, while preserving the rest
    of the DLC tree.  This is the map-DLC counterpart of vehiclemods handling.
    """
    import shutil
    jobs = []
    # Prefer folders that directly contain converted O* resources.
    for folder in sorted([p for p in extracted_root.rglob('*') if p.is_dir()], key=lambda p: len(p.parts), reverse=True):
        if folder.name.lower() in ('archive_input', '_ps4_build_stage'):
            continue
        files = [p for p in folder.iterdir() if p.is_file()]
        if not any(p.suffix.lower().startswith('.o') and p.suffix.lower() in SUPPORTED for p in files):
            continue
        # Avoid rebuilding the entire x64/ps4 root; only actual content folders.
        if folder.name.lower() in ('x64', 'ps4'):
            continue
        jobs.append(folder)

    # Deduplicate nested jobs: when a parent contains child folders that are
    # themselves packed, only pack the highest-level folder that directly holds
    # converted resources and child content.
    seen = set()
    unique = []
    for folder in jobs:
        if folder in seen:
            continue
        unique.append(folder)
        seen.add(folder)

    built_count = 0
    for folder in unique:
        target = folder.parent / f'{folder.name}.rpf'
        print(f'[MAP DLC] Building folder: {folder.relative_to(extracted_root)}')
        print(f'[MAP DLC] Output name: {target.name}')
        archive_out = builder.parent / 'Archive.rpf'
        if archive_out.exists():
            archive_out.unlink()
        print_build_logo()
        result = safe_subprocess_run(
            [sys.executable, str(builder), str(folder)],
            cwd=str(builder.parent),
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        )
        if result.returncode != 0 or not archive_out.is_file() or archive_out.stat().st_size == 0:
            print(f'[ERROR] Map folder build failed: {folder.name}')
            return built_count, False
        try:
            if target.exists():
                target.unlink()
            shutil.move(str(archive_out), str(target))
            shutil.rmtree(folder)
            built_count += 1
            print(f'[MAP DLC] Archive.rpf -> {target.name} -> source folder replaced ✅')
        except Exception as exc:
            print(f'[ERROR] Could not finalize map RPF {target.name}: {exc}')
            return built_count, False
    return built_count, True


def _map_dlc_one_click_impl():
    """Dedicated one-click workflow for map dlc.rpf."""
    import shutil
    dlc_dir = ROOT / 'dlc.rpf map'
    source = dlc_dir / 'dlc.rpf'
    extractor = ROOT / 'RPFBuilder' / 'extract_rpf.py'
    builder = ROOT / 'RPFBuilder' / 'build_rpf.py'
    if not source.is_file():
        print(f'[ERROR] Put the map source dlc.rpf here first:\n    {source}')
        return 1
    if not extractor.is_file() or not builder.is_file():
        print('[ERROR] RPFBuilder extraction/build tools are missing.')
        return 1

    for old in dlc_dir.iterdir():
        if old != source:
            try:
                shutil.rmtree(old) if old.is_dir() else old.unlink()
            except Exception as exc:
                print(f'[WARN] Could not remove {old.name}: {exc}')

    work_root = dlc_dir / '_map_dlc_working'
    shutil.rmtree(work_root, ignore_errors=True)
    work_root.mkdir(parents=True, exist_ok=True)
    extracted_root = work_root / 'dlc.rpf'
    print('\n[MAP DLC ONE CLICK] Starting...')
    print('[1/4] Extracting dlc.rpf...')
    result = safe_subprocess_run(
        [sys.executable, str(extractor), str(source), str(extracted_root)],
        cwd=str(extractor.parent), input='A\n', text=True
    )
    if result.returncode != 0 or not extracted_root.is_dir():
        print('[ERROR] Map dlc.rpf extraction failed; original was kept.')
        shutil.rmtree(work_root, ignore_errors=True)
        return 1

    # Remove extracted nested RPF containers so their old PC resources cannot
    # be packed back. Their extracted folders remain available for conversion.
    nested_jobs = []
    for rpf in list(extracted_root.rglob('*.rpf')):
        if not rpf.is_file():
            continue
        folder = rpf.with_suffix('')
        if folder.is_dir():
            nested_jobs.append((folder, rpf.name))
            try:
                rpf.unlink()
                print(f'[MAP DLC] Removed old nested RPF: {rpf.name} ✅')
            except Exception as exc:
                print(f'[WARN] Could not remove nested RPF {rpf}: {exc}')

    print('[2/4] Converting map resources...')
    converted_count, failed = _convert_extracted_tree(extracted_root, CORE, ROOT, delete_y_all=True)
    if failed:
        print(f'[WARN] {len(failed)} resource(s) had cleanup/conversion warnings; continuing with successful files.')
    _remove_ps4_data_dirs(extracted_root)

    # Rebuild extracted nested RPF folders first, preserving their original RPF
    # names. This mirrors the normal DLC workflow.
    rebuilt_nested = 0
    for folder, old_name in sorted(nested_jobs, key=lambda x: len(x[0].parts), reverse=True):
        if not folder.is_dir():
            continue
        archive_out = builder.parent / 'Archive.rpf'
        if archive_out.exists():
            archive_out.unlink()
        result_nested = safe_subprocess_run(
            [sys.executable, str(builder), str(folder)],
            cwd=str(builder.parent),
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        )
        if result_nested.returncode != 0 or not archive_out.is_file() or archive_out.stat().st_size == 0:
            print(f'[ERROR] Could not rebuild nested map RPF: {old_name}')
            shutil.rmtree(work_root, ignore_errors=True)
            return 1
        out = folder.parent / old_name
        if out.exists(): out.unlink()
        shutil.move(str(archive_out), str(out))
        shutil.rmtree(folder)
        rebuilt_nested += 1
        print(f'[MAP DLC] Rebuilt {old_name} from converted folder ✅')

    # Convert x64 -> ps4 exactly like the old DLC workflow.
    x64 = extracted_root / 'x64'
    ps4 = extracted_root / 'ps4'
    if x64.is_dir():
        if ps4.exists():
            for item in x64.iterdir():
                dest = ps4 / item.name
                if dest.exists() and dest.is_dir() and item.is_dir():
                    shutil.copytree(item, dest, dirs_exist_ok=True)
                    shutil.rmtree(item)
                else:
                    if dest.exists(): dest.unlink()
                    shutil.move(str(item), str(dest))
            x64.rmdir()
        else:
            x64.rename(ps4)
        print('[MAP DLC] Renamed x64 -> ps4 ✅')
    _remove_ps4_data_dirs(extracted_root)

    # Final build: build the ACTUAL converted `dlc.rpf` folder produced by
    # the extraction/conversion stage.  Do not build a second surrogate folder
    # and do not merely stop after conversion.  The user's expected result is
    # always Finish/dlc.rpf.
    print_build_logo()
    print('[3/4] Building the converted dlc.rpf folder...')
    print(f'[MAP DLC] Build source: {extracted_root}')
    if not extracted_root.is_dir():
        print('[ERROR] Converted dlc.rpf folder is missing; Build cancelled.')
        shutil.rmtree(work_root, ignore_errors=True)
        return 1

    remaining_stage_y = [
        p for p in extracted_root.rglob('*')
        if p.is_file() and p.suffix.lower().startswith('.y')
        and p.suffix.lower() in SUPPORTED
    ]
    if remaining_stage_y:
        print('[ERROR] Converted dlc.rpf still contains Y* resources; Build cancelled.')
        for p in remaining_stage_y[:20]:
            print(f'    ❌ {p.relative_to(extracted_root)}')
        shutil.rmtree(work_root, ignore_errors=True)
        return 1

    archive_out = builder.parent / 'Archive.rpf'
    if archive_out.exists():
        try:
            archive_out.unlink()
        except OSError as exc:
            print(f'[ERROR] Could not remove old Archive.rpf: {exc}')
            shutil.rmtree(work_root, ignore_errors=True)
            return 1

    result = safe_subprocess_run(
        [sys.executable, str(builder), str(extracted_root)],
        cwd=str(builder.parent),
        env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
    )

    # build_rpf.py normally writes here.  Keep a few recovery locations for
    # Android/xow64 where the Wine wrapper may leave the file on C:.
    archive_candidates = [
        builder.parent / 'Archive.rpf',
        Path(os.path.expanduser('~/.xow64_wine/drive_c/Archive.rpf')),
    ]
    found_archive = None
    for candidate in archive_candidates:
        try:
            if candidate.is_file() and candidate.stat().st_size > 0:
                found_archive = candidate
                break
        except OSError:
            pass

    if found_archive is None and result.returncode == 0:
        try:
            possible = [
                p for p in builder.parent.rglob('Archive.rpf')
                if p.is_file() and p.stat().st_size > 0
            ]
            if possible:
                found_archive = max(possible, key=lambda p: p.stat().st_mtime)
        except (OSError, PermissionError):
            pass

    if result.returncode != 0 or found_archive is None:
        print(f'[ERROR] dlc.rpf Build failed (builder exit code: {result.returncode}).')
        print('[ERROR] The converted folder exists, but no valid Archive.rpf was produced.')
        print(f'[INFO] Converted folder kept for inspection: {extracted_root}')
        return 1

    finish_dir = ROOT / 'Finish'
    finish_dir.mkdir(parents=True, exist_ok=True)
    final = finish_dir / 'dlc.rpf'
    temp_final = finish_dir / '.dlc.rpf.building'
    try:
        if temp_final.exists():
            temp_final.unlink()
        shutil.copy2(str(found_archive), str(temp_final))
        if temp_final.stat().st_size == 0:
            raise OSError('temporary output is empty')
        if final.exists():
            final.unlink()
        temp_final.replace(final)
    except OSError as exc:
        print(f'[ERROR] Could not finalize Finish/dlc.rpf: {exc}')
        return 1

    if not final.is_file() or final.stat().st_size == 0:
        print('[ERROR] Build finished but Finish/dlc.rpf is missing or empty.')
        return 1

    # Only after the final RPF is verified do we remove the source/work files.
    try:
        source.unlink()
    except OSError as exc:
        print(f'[WARN] Could not delete source dlc.rpf: {exc}')
    shutil.rmtree(work_root, ignore_errors=True)
    print('[4/4] Map DLC Build completed successfully. ✅')
    print(f'[SUCCESS] Final map dlc.rpf: {final} ({final.stat().st_size:,} bytes)')
    return 0


def map_dlc_one_click():
    try:
        return _map_dlc_one_click_impl()
    except KeyboardInterrupt:
        print('\n[STOPPED] Map DLC conversion interrupted safely.')
        return 130
    except Exception as exc:
        print(f'\n[ERROR] Unexpected Map DLC conversion error: {type(exc).__name__}: {exc}')
        print('[SAFE STOP] Map DLC Build stopped safely.')
        return 1

def _dlc_rpf_one_click_impl():
    """Extract, convert, and rebuild a DLC RPF in one click."""
    dlc_dir = ROOT / "cars dlc.rpf One step"
    source = dlc_dir / "dlc.rpf"
    extractor = ROOT / "RPFBuilder" / "extract_rpf.py"
    builder = ROOT / "RPFBuilder" / "build_rpf.py"

    if not source.is_file():
        print(f"[ERROR] Put the source dlc.rpf here first:\n    {source}")
        return 1
    if not extractor.is_file() or not builder.is_file():
        print("[ERROR] RPFBuilder extraction/build tools are missing.")
        return 1

    import shutil
    import tempfile
    original_rpf_size = source.stat().st_size
    print("\n[DLC.RPF ONE CLICK] Starting...")
    print(f"[INFO] Original dlc.rpf size: {original_rpf_size / (1024*1024):.2f} MB")

    # Remove previous extraction/output folders, but keep the source until extraction succeeds.
    for old in dlc_dir.iterdir():
        if old != source:
            try:
                shutil.rmtree(old) if old.is_dir() else old.unlink()
            except Exception as exc:
                print(f"[WARN] Could not remove {old.name}: {exc}")

    source_name = source.stem
    work_root = dlc_dir / f"_{source_name}_working"
    if work_root.exists(): shutil.rmtree(work_root)
    work_root.mkdir(parents=True, exist_ok=True)

    print(f"[1/4] Extracting {source.name}...")
    result = safe_subprocess_run(
        [sys.executable, str(extractor), str(source), str(work_root / source_name)],
        cwd=str(extractor.parent), input="A\n", text=True
    )
    extracted_root = work_root / source_name
    if result.returncode != 0 or not extracted_root.is_dir():
        print("[ERROR] RPF extraction failed; original dlc.rpf was kept.")
        return 1

    # IMPORTANT: nested RPF containers are only extraction sources.  However,
    # vehiclemods has a special workflow: when vehiclemods contains BOTH
    # <folder_name>/ and <folder_name>.rpf, the folder is the source that must be
    # converted and rebuilt.  Keep those jobs separate so the generic nested-RPF
    # rebuild does not overwrite them later.
    nested_rpf_jobs = []
    vehiclemods_folder_jobs = []
    vehiclemods_original_backups = []
    nested_removed = 0
    for nested_rpf in list(extracted_root.rglob('*.rpf')):
        if not nested_rpf.is_file():
            continue
        extracted_dir = nested_rpf.with_suffix('')

        # SPECIAL CASE: vehiclemods can contain ONLY the RPF file, with no
        # extracted sibling folder.  The reference workflow still processes
        # this archive: use its filename as the temporary archive_input marker,
        # build Archive.rpf, then return it to vehiclemods under the SAME name.
        try:
            parent_parts = [part.lower() for part in nested_rpf.relative_to(extracted_root).parts[:-1]]
        except ValueError:
            parent_parts = []
        if 'vehiclemods' in parent_parts and extracted_dir.parent.name.lower() == 'vehiclemods' and not extracted_dir.is_dir():
            backup_path = work_root / '_vehiclemods_originals' / str(len(vehiclemods_original_backups)) / nested_rpf.name
            backup_path.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(nested_rpf, backup_path)
                vehiclemods_original_backups.append((extracted_dir, nested_rpf, backup_path))
            except Exception as exc:
                print(f"[WARN] Could not create vehiclemods backup for {nested_rpf.name}: {exc}")
            extracted_dir.mkdir(parents=True, exist_ok=True)
            vehiclemods_folder_jobs.append((extracted_dir, nested_rpf))
            try:
                nested_rpf.unlink()
                nested_removed += 1
                print(f"[VEHICLEMODS] Found RPF-only entry: {nested_rpf.name}")
                print(f"[VEHICLEMODS] No extracted folder exists; creating empty source stage for the video workflow.")
            except Exception as exc:
                print(f"[ERROR] Could not delete vehiclemods RPF {nested_rpf}: {exc}")
            continue

        if not extracted_dir.is_dir():
            continue

        # Special case: vehiclemods/<folder>/<files> + vehiclemods/<rpf>.
        # The folder itself is the build source.  We do NOT rebuild the old RPF
        # contents; instead the converted folder is packed into a fresh RPF.
        try:
            parent_parts = [part.lower() for part in nested_rpf.relative_to(extracted_root).parts[:-1]]
        except ValueError:
            parent_parts = []
        if 'vehiclemods' in parent_parts and extracted_dir.parent.name.lower() == 'vehiclemods':
            backup_path = work_root / '_vehiclemods_originals' / str(len(vehiclemods_original_backups)) / nested_rpf.name
            backup_path.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(nested_rpf, backup_path)
                vehiclemods_original_backups.append((extracted_dir, nested_rpf, backup_path))
            except Exception as exc:
                print(f"[WARN] Could not create vehiclemods backup for {nested_rpf.name}: {exc}")
            vehiclemods_folder_jobs.append((extracted_dir, nested_rpf))
            try:
                nested_rpf.unlink()
                nested_removed += 1
                print(f"[VEHICLEMODS] Found source folder + RPF: {extracted_dir.name} / {nested_rpf.name}")
                print(f"[VEHICLEMODS] Removed old RPF container; converted folder will be rebuilt as {extracted_dir.name}.rpf")
            except Exception as exc:
                print(f"[ERROR] Could not delete vehiclemods RPF {nested_rpf}: {exc}")
            continue

        try:
            # Remember exactly which extracted folder came from which RPF.
            # That folder will be rebuilt back into the SAME RPF filename after
            # all contained Y* resources have been converted.
            nested_rpf_jobs.append((extracted_dir, nested_rpf.name))
            nested_rpf.unlink()
            nested_removed += 1
            print(f"[DELETED NESTED RPF] {nested_rpf.name}  [EXTRACTED CONTENT KEPT] ✅")
        except Exception as exc:
            print(f"[ERROR] Could not delete nested RPF {nested_rpf}: {exc}")
    if nested_removed:
        print(f"[OK] Removed {nested_removed} extracted nested RPF container(s) before conversion/build.")

    # Convert every directory recursively. The helper handles every supported
    # Y* type (YFT/YDR/YDD/YTD/YMT/YNV/...); successful sources are deleted and
    # failed leftovers are quarantined outside the build tree so the process can
    # continue safely even with very large DLCs.
    print("[2/4] Converting all supported files inside the extracted DLC...")
    # The extractor used above expands nested RPFs automatically (A = all).
    # Verify that the extracted tree really contains Y* resources before the
    # converter is called. This prevents a false "conversion complete" when
    # an extractor on a device returns early or a nested RPF was not expanded.
    pre_y = [
        p for p in extracted_root.rglob('*')
        if p.is_file() and p.suffix.lower() in SUPPORTED and p.suffix.lower().startswith('.y')
    ]
    print(f"[INFO] Found {len(pre_y)} original Y* resource(s) ready for conversion.")
    if pre_y:
        for p in pre_y[:12]:
            print(f"    └── {p.relative_to(extracted_root)}")
        if len(pre_y) > 12:
            print(f"    └── ... and {len(pre_y)-12} more")
    else:
        print("[WARN] No Y* resources were found in the extracted DLC tree.")
    converted_count, failed = _convert_extracted_tree(extracted_root, CORE, ROOT, delete_y_all=True)
    print(f"[OK] Conversion pass finished: {converted_count} converted resource(s). ✅")
    if failed:
        print(f"[WARN] {len(failed)} resource(s) were quarantined; continuing with the clean build tree.")

    # Final absolute guard: all supported original Y* resources must be gone
    # before any nested or top-level RPF is built. This includes YMT, YNV, YMAP,
    # YDR, YFT, YTD and every other supported conversion type.
    remaining_y = [
        p for p in extracted_root.rglob('*')
        if p.is_file() and p.suffix.lower().startswith('.y') and p.suffix.lower() in SUPPORTED
    ]
    if remaining_y:
        print(f"[WARN] {len(remaining_y)} Y* resource(s) survived conversion; quarantining them now...")
        failed_root = ROOT / "Conversion failed ❌" / "DLC One Click"
        failed_root.mkdir(parents=True, exist_ok=True)
        for original in remaining_y:
            try:
                target = failed_root / original.name
                n = 2
                while target.exists():
                    target = failed_root / f"{original.stem}_{n}{original.suffix}"
                    n += 1
                shutil.copy2(original, target)
                original.unlink()
                print(f"  └── 🧹 [FINAL DELETE] {original.name} -> quarantined")
            except Exception as exc:
                print(f"[ERROR] Could not remove leftover Y resource {original}: {exc}")
        remaining_y = [
            p for p in extracted_root.rglob('*')
            if p.is_file() and p.suffix.lower().startswith('.y') and p.suffix.lower() in SUPPORTED
        ]
    if remaining_y:
        print("[ERROR] Supported Y* resources remain. Build cancelled to protect the final RPF:")
        for p in remaining_y:
            print(f"    ❌ {p.relative_to(extracted_root)}")
        shutil.rmtree(work_root, ignore_errors=True)
        return 1
    print("[OK] Full Y* cleanup finished. No original PC resource will enter Build. ✅")

    # Remove only directories named "data" that are descendants of x64 or ps4.
    # A data directory outside x64/ps4 is intentionally preserved.
    # Removing deepest folders first avoids leaving nested data directories
    # behind and guarantees the nested-RPF build cannot pack them back in.
    data_removed = 0
    data_failed = []
    data_dirs = [d for d in extracted_root.rglob('*') if d.is_dir() and d.name.lower() == 'data' and any(part.lower() in ('x64', 'ps4') for part in d.relative_to(extracted_root).parts[:-1])]
    for data_dir in sorted(data_dirs, key=lambda d: len(d.parts), reverse=True):
        try:
            shutil.rmtree(data_dir)
            if not data_dir.exists():
                data_removed += 1
                print(f"[DELETED DATA] {data_dir.relative_to(extracted_root)}  [OK] ✅")
            else:
                data_failed.append(str(data_dir.relative_to(extracted_root)))
        except Exception as exc:
            data_failed.append(str(data_dir.relative_to(extracted_root)))
            print(f"[ERROR] Could not delete data folder {data_dir}: {exc}")

    remaining_data = [d for d in extracted_root.rglob('*') if d.is_dir() and d.name.lower() == 'data' and any(part.lower() in ('x64', 'ps4') for part in d.relative_to(extracted_root).parts[:-1])]
    if remaining_data:
        print("[ERROR] data folders remain. Build cancelled to prevent unwanted files:")
        for d in remaining_data:
            print(f"    ❌ {d.relative_to(extracted_root)}")
        shutil.rmtree(work_root, ignore_errors=True)
        return 1
    print(f"[OK] data-folder cleanup finished: {data_removed} folder(s) deleted. ✅")

    # SPECIAL VEHICLEMODS HANDLING:
    # If vehiclemods contained <folder>/<converted files> together with the old
    # <folder>.rpf, the folder is now packed into a fresh RPF.  The output is
    # always named after the SOURCE FOLDER (not the old RPF name), and both the
    # rebuilt RPF and source folder remain inside vehiclemods.
    if vehiclemods_folder_jobs:
        print(f"[3/5] Processing {len(vehiclemods_folder_jobs)} vehiclemods folder(s)...")
        vehiclemods_builder = ROOT / "RPFBuilder" / "build_rpf.py"
        try:
            for vehiclemods_folder, old_rpf in vehiclemods_folder_jobs:
                if not vehiclemods_folder.is_dir():
                    print(f"[VEHICLEMODS] SKIP — source folder missing: {vehiclemods_folder}")
                    continue

                folder_name = vehiclemods_folder.name
                # Keep the exact filename of the original vehiclemods archive.
                # The legacy vehiclemods workflow used that filename as a small
                # marker in archive_input while the folder was being rebuilt.
                source_file_name = old_rpf.name
                target_rpf = vehiclemods_folder.parent / source_file_name
                archive_input_dir = ROOT / 'RPFBuilder' / 'archive_input'
                archive_input_dir.mkdir(parents=True, exist_ok=True)
                marker_txt = archive_input_dir / f"{Path(source_file_name).stem}.txt"
                try:
                    marker_txt.write_text('', encoding='utf-8')
                except Exception as exc:
                    raise RuntimeError(f"Could not create vehiclemods archive marker: {exc}")

                print(f"[VEHICLEMODS] Source folder: {vehiclemods_folder.relative_to(extracted_root)}")
                print(f"[VEHICLEMODS] Source filename: {source_file_name}")
                print(f"[VEHICLEMODS] Marker -> archive_input/{marker_txt.name}  [0-byte marker, filename carries the RPF name]")

                stale_archive = ROOT / 'RPFBuilder' / 'Archive.rpf'
                if stale_archive.exists():
                    stale_archive.unlink()

                # EXACT vehiclemods workflow from the reference video:
                # when the extracted vehiclemods RPF is only an empty placeholder,
                # create <original_name>.txt in RPFBuilder/archive_input, build that
                # archive_input with the normal builder (no folder argument), then
                # remove the marker and return Archive.rpf to vehiclemods using the
                # original RPF filename.  This is intentionally separate from the
                # non-empty-folder path below, which rebuilds converted vehicle data.
                folder_has_files = any(x.is_file() for x in vehiclemods_folder.rglob('*'))
                if not folder_has_files:
                    # The reference workflow uses an EMPTY TXT marker. The
                    # filename is the only payload: <rpf-name>.txt.
                    try:
                        marker_txt.write_bytes(b'')
                    except Exception as exc:
                        raise RuntimeError(f"Could not reset vehiclemods marker: {exc}")
                    print('[VEHICLEMODS] Empty/RPF-only vehiclemods entry detected.')
                    print('[VEHICLEMODS] Applying the archive_input TXT -> Archive.rpf workflow exactly like the video...')

                    archive_input = ROOT / 'RPFBuilder' / 'archive_input'
                    archive_backup = work_root / '_archive_input_backup' / str(len(vehiclemods_original_backups))
                    archive_backup.mkdir(parents=True, exist_ok=True)
                    saved_archive_input = []
                    try:
                        # Keep any user files that happened to be in archive_input out
                        # of this one-click build, then restore them after the build.
                        for item in list(archive_input.iterdir()) if archive_input.exists() else []:
                            backup_item = archive_backup / item.name
                            if item.is_dir():
                                shutil.copytree(item, backup_item)
                            else:
                                shutil.copy2(item, backup_item)
                            saved_archive_input.append(item.name)
                            if item.is_dir():
                                shutil.rmtree(item)
                            else:
                                item.unlink()

                        marker_txt.write_text('', encoding='utf-8')
                        result_vehicle = safe_subprocess_run(
                            [sys.executable, str(vehiclemods_builder)],
                            cwd=str(vehiclemods_builder.parent),
                            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
                        )
                    finally:
                        # The marker must never survive beside the builder input.
                        if marker_txt.exists():
                            try:
                                marker_txt.unlink()
                                print(f"[VEHICLEMODS] Deleted marker: archive_input/{marker_txt.name} ✅")
                            except OSError as exc:
                                print(f"[WARN] Could not delete marker {marker_txt.name}: {exc}")
                        # Restore archive_input exactly as it was before this job.
                        archive_input.mkdir(parents=True, exist_ok=True)
                        for name in saved_archive_input:
                            backup_item = archive_backup / name
                            dest_item = archive_input / name
                            if backup_item.is_dir():
                                shutil.copytree(backup_item, dest_item, dirs_exist_ok=True)
                            elif backup_item.is_file():
                                shutil.copy2(backup_item, dest_item)

                else:
                    print('[VEHICLEMODS] Converted vehicle folder contains files.')
                    print('[VEHICLEMODS] Building converted folder -> Archive.rpf ...')
                    result_vehicle = safe_subprocess_run(
                        [sys.executable, str(vehiclemods_builder), str(vehiclemods_folder)],
                        cwd=str(vehiclemods_builder.parent),
                        env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
                    )

                built_vehicle = ROOT / 'RPFBuilder' / 'Archive.rpf'
                if result_vehicle.returncode != 0 or not built_vehicle.is_file() or built_vehicle.stat().st_size == 0:
                    raise RuntimeError(f"Could not build vehiclemods folder: {folder_name}")

                # The marker is temporary: delete it before returning the rebuilt
                # archive to vehiclemods.
                if marker_txt.exists():
                    marker_txt.unlink()
                    print(f"[VEHICLEMODS] Deleted marker: archive_input/{marker_txt.name} ✅")

                if target_rpf.exists():
                    target_rpf.unlink()
                shutil.move(str(built_vehicle), str(target_rpf))
                print(f"[VEHICLEMODS] Archive.rpf -> {source_file_name} -> returned to vehiclemods ✅")
                print(f"[VEHICLEMODS] Source folder kept: {folder_name}/ ✅")

            print(f"[OK] vehiclemods folder processing completed: {len(vehiclemods_folder_jobs)} folder(s). ✅")
        except Exception as exc:
            print(f"[ERROR] vehiclemods folder build failed: {exc}")
            # Restore original vehiclemods RPFs from the private copies if the
            # folder build fails, so the extracted DLC is never left without them.
            for _folder, original_rpf, backup_path in vehiclemods_original_backups:
                try:
                    if backup_path.is_file() and not original_rpf.exists():
                        shutil.copy2(backup_path, original_rpf)
                except Exception as restore_exc:
                    print(f"[WARN] Could not restore {original_rpf.name}: {restore_exc}")
            shutil.rmtree(work_root, ignore_errors=True)
            return 1
    else:
        print("[3/5] No vehiclemods folder+RPF pair found — continuing normally. ✅")

    # Rebuild every remaining nested RPF from the folder that was extracted from it.
    # This is deliberately done BEFORE the top-level DLC build: the top-level
    # archive must receive the rebuilt <same-name>.rpf, not the extracted folder
    # containing loose files.  This also prevents the old YFT/YTD container from
    # ever being reintroduced.
    if nested_rpf_jobs:
        print("[4/5] Rebuilding converted nested RPF files...")
        rebuilt_nested = 0
        for nested_dir, original_rpf_name in sorted(nested_rpf_jobs, key=lambda x: len(x[0].parts), reverse=True):
            if not nested_dir.is_dir():
                # The extracted folder may legitimately be gone because it lived
                # under a `data` directory that was intentionally deleted before
                # the build.  Do NOT abort the whole DLC build in this case.
                try:
                    rel_missing = nested_dir.relative_to(extracted_root)
                except ValueError:
                    rel_missing = nested_dir
                print(f"[SKIP NESTED RPF] {original_rpf_name} — extracted folder was removed during data cleanup: {rel_missing}  [OK] ✅")
                continue
            nested_output = nested_dir.parent / original_rpf_name
            if nested_output.exists():
                try: nested_output.unlink()
                except OSError: pass
            nested_builder = ROOT / "RPFBuilder" / "build_rpf.py"
            result_nested = safe_subprocess_run(
                [sys.executable, str(nested_builder), str(nested_dir)],
                cwd=str(nested_builder.parent),
                env={**os.environ, 'PYTHONIOENCODING':'utf-8'}
            )
            archive_out = nested_builder.parent / "Archive.rpf"
            if result_nested.returncode != 0 or not archive_out.is_file() or archive_out.stat().st_size == 0:
                print(f"[ERROR] Could not rebuild nested RPF: {original_rpf_name}")
                shutil.rmtree(work_root, ignore_errors=True)
                return 1
            try:
                if nested_output.exists(): nested_output.unlink()
                shutil.move(str(archive_out), str(nested_output))
                shutil.rmtree(nested_dir)
                rebuilt_nested += 1
                print(f"[OK] Rebuilt {original_rpf_name} from converted folder: {nested_output}")
            except Exception as exc:
                print(f"[ERROR] Could not finalize rebuilt {original_rpf_name}: {exc}")
                shutil.rmtree(work_root, ignore_errors=True)
                return 1
        print(f"[OK] Rebuilt {rebuilt_nested} nested RPF file(s) with their original names. ✅")

    # Rename the GTA V x64 folder to the PS4 folder name before building.
    # If a PS4 folder already exists, merge x64 contents into it safely.
    x64_dir = extracted_root / "x64"
    ps4_dir = extracted_root / "ps4"
    if x64_dir.is_dir():
        try:
            if ps4_dir.exists():
                for item in x64_dir.iterdir():
                    target = ps4_dir / item.name
                    if target.exists():
                        if target.is_dir() and item.is_dir():
                            shutil.copytree(item, target, dirs_exist_ok=True)
                            shutil.rmtree(item)
                        else:
                            target.unlink()
                            shutil.move(str(item), str(target))
                    else:
                        shutil.move(str(item), str(target))
                x64_dir.rmdir()
            else:
                x64_dir.rename(ps4_dir)
            print("[INFO] Renamed x64 -> ps4 for PS4 build.")
        except Exception as exc:
            print(f"[ERROR] Could not rename x64 to ps4: {exc}")
            shutil.rmtree(work_root, ignore_errors=True)
            return 1

    # Final safety pass after x64 -> ps4 rename.  Only data directories inside
    # x64/ps4 are removed; data elsewhere is intentionally preserved.
    late_data_removed = 0
    for data_dir in sorted([d for d in extracted_root.rglob('*') if d.is_dir() and d.name.lower() == 'data' and any(part.lower() in ('x64', 'ps4') for part in d.relative_to(extracted_root).parts[:-1])], key=lambda d: len(d.parts), reverse=True):
        try:
            shutil.rmtree(data_dir)
            late_data_removed += 1
            print(f"[DELETED DATA] {data_dir.relative_to(extracted_root)}  [OK] ✅")
        except Exception as exc:
            print(f"[ERROR] Could not delete data folder {data_dir}: {exc}")
    remaining_data = [d for d in extracted_root.rglob('*') if d.is_dir() and d.name.lower() == 'data' and any(part.lower() in ('x64', 'ps4') for part in d.relative_to(extracted_root).parts[:-1])]
    if remaining_data:
        print("[ERROR] data folders remain after final cleanup. Build cancelled:")
        for d in remaining_data:
            print(f"    ❌ {d.relative_to(extracted_root)}")
        shutil.rmtree(work_root, ignore_errors=True)
        return 1
    if late_data_removed:
        print(f"[OK] Final data cleanup removed {late_data_removed} folder(s). ✅")

    # Remove the original RPF only after extraction and conversion succeeded.
    try: source.unlink()
    except Exception as exc:
        print(f"[WARN] Could not delete old dlc.rpf: {exc}")

    # Create a completely fresh build staging tree. The builder MUST read only
    # this tree so deleted GTA V originals can never be reintroduced from a
    # previous extraction/buffer/cache location.
    build_stage = dlc_dir / "_PS4_BUILD_STAGE"
    if build_stage.exists():
        shutil.rmtree(build_stage, ignore_errors=True)
    build_stage.mkdir(parents=True, exist_ok=True)
    for src_item in extracted_root.iterdir():
        dst_item = build_stage / src_item.name
        if src_item.is_dir():
            shutil.copytree(src_item, dst_item)
        else:
            shutil.copy2(src_item, dst_item)
    # Absolute final guard: no YFT/YTD or directory/file named "data" is ever
    # handed to the builder.  This final pass is intentionally performed on
    # the exact staging tree that RageBuilder will read.
    for old_y in list(build_stage.rglob('*')):
        if old_y.is_file() and old_y.suffix.lower() in ('.yft', '.ytd'):
            try:
                old_y.unlink()
            except OSError:
                pass
    stage_data_removed = 0
    stage_data_items = [p for p in build_stage.rglob('*') if p.name.lower() == 'data' and any(part.lower() in ('x64', 'ps4') for part in p.relative_to(build_stage).parts[:-1])]
    for data_item in sorted(stage_data_items, key=lambda p: len(p.parts), reverse=True):
        try:
            if data_item.is_dir():
                shutil.rmtree(data_item)
            elif data_item.is_file():
                data_item.unlink()
            if not data_item.exists():
                stage_data_removed += 1
                print(f"[DELETED DATA] build-stage/{data_item.relative_to(build_stage)}  [OK] ✅")
        except Exception as exc:
            print(f"[ERROR] Could not delete build-stage data item {data_item}: {exc}")
    remaining_stage_data = [p for p in build_stage.rglob('*') if p.name.lower() == 'data' and any(part.lower() in ('x64', 'ps4') for part in p.relative_to(build_stage).parts[:-1])]
    if remaining_stage_data:
        print("[ERROR] Build stage still contains data; Build cancelled.")
        for p in remaining_stage_data:
            print(f"    ❌ {p.relative_to(build_stage)}")
        shutil.rmtree(build_stage, ignore_errors=True)
        shutil.rmtree(work_root, ignore_errors=True)
        return 1
    if stage_data_removed:
        print(f"[OK] Build-stage data cleanup removed {stage_data_removed} item(s). ✅")
    remaining_stage_y = [p for p in build_stage.rglob('*') if p.is_file() and p.suffix.lower() in ('.yft', '.ytd')]
    if remaining_stage_y:
        print("[ERROR] Build stage still contains YFT/YTD; Build cancelled.")
        for p in remaining_stage_y:
            print(f"    ❌ {p.relative_to(build_stage)}")
        shutil.rmtree(build_stage, ignore_errors=True)
        shutil.rmtree(work_root, ignore_errors=True)
        return 1
    print(f"[OK] Clean PS4 build stage ready: {build_stage}")

    print("[5/5] Building the converted DLC...")
    built = builder.parent / "Archive.rpf"
    if built.exists(): built.unlink()
    # Remove stale RPF outputs so the file selected below is from this build.
    for stale in builder.parent.glob("*.rpf"):
        if stale != built:
            try: stale.unlink()
            except OSError: pass
    result = safe_subprocess_run([sys.executable, str(builder), str(build_stage)], cwd=str(builder.parent))
    if not built.exists():
        candidates = [p for p in builder.parent.glob("*.rpf") if p.is_file()]
        candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        if candidates: built = candidates[0]
    if result.returncode != 0 or not built.exists() or built.stat().st_size == 0:
        print("[ERROR] DLC RPF build failed or produced an empty RPF.")
        return 1

    built_size = built.stat().st_size
    print(f"[INFO] Built RPF: {built.name} — {built_size / (1024*1024):.2f} MB")
    if built_size >= original_rpf_size:
        print("[WARN] Built RPF is not smaller than the original; keeping the valid build.")
        print(f"[INFO] Original: {original_rpf_size:,} bytes | Built: {built_size:,} bytes")
    else:
        print(f"[OK] Built RPF is smaller than original by {original_rpf_size - built_size:,} bytes.")

    print("[5/5] Finalizing as dlc.rpf...")
    finish_dir = ROOT / "Finish"
    finish_dir.mkdir(parents=True, exist_ok=True)
    final = finish_dir / "dlc.rpf"
    if final.exists():
        final.unlink()
    shutil.move(str(built), str(final))
    shutil.rmtree(build_stage, ignore_errors=True)
    shutil.rmtree(work_root, ignore_errors=True)
    print("[OK] Build completed successfully. ✅")
    print(f"[SUCCESS] Final dlc.rpf moved to: {final}")
    return 0

def dlc_rpf_one_click():
    """Crash-safe DLC One Click entry point."""
    try:
        return _dlc_rpf_one_click_impl()
    except KeyboardInterrupt:
        print("\n[STOPPED] DLC conversion interrupted safely.")
        return 130
    except Exception as exc:
        print(f"\n[ERROR] Unexpected DLC conversion error: {type(exc).__name__}: {exc}")
        print("[SAFE STOP] No further Build step will run.")
        return 1



def _sanitize_vehicle_name(name):
    """Return a GTA-friendly lowercase identifier for the generated add-on."""
    import re
    value = re.sub(r'[^A-Za-z0-9_]+', '_', str(name).strip())
    value = re.sub(r'_+', '_', value).strip('_').lower()
    if not value:
        value = 'vehicle_addon'
    if value[0].isdigit():
        value = 'v_' + value
    return value[:48]


def _extract_vehicle_package(source, work_dir):
    """Extract a ZIP/RAR package or copy a source folder into work_dir."""
    import shutil
    import zipfile
    source = Path(source)
    work_dir = Path(work_dir)
    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    if source.is_dir():
        target = work_dir / source.name
        shutil.copytree(source, target)
        return target
    if source.suffix.lower() == '.zip':
        with zipfile.ZipFile(source) as zf:
            zf.extractall(work_dir)
    elif source.suffix.lower() == '.rar':
        try:
            import rarfile
            with rarfile.RarFile(source) as rf:
                rf.extractall(work_dir)
        except Exception as exc:
            extractors = []
            for exe in ('unrar', '7z', '7zz', 'bsdtar'):
                found = shutil.which(exe)
                if found:
                    extractors.append(found)
            last_exc = exc
            for exe in extractors:
                try:
                    if Path(exe).name.lower().startswith('bsdtar'):
                        args = [exe, '-xf', str(source), '-C', str(work_dir)]
                    else:
                        args = [exe, 'x', '-y', str(source), f'-o{work_dir}']
                    result = safe_subprocess_run(args, cwd=str(work_dir), _retries=1)
                    if result.returncode == 0:
                        last_exc = None
                        break
                    last_exc = RuntimeError(f'{Path(exe).name} returned {result.returncode}')
                except Exception as sub_exc:
                    last_exc = sub_exc
            if last_exc is not None:
                raise RuntimeError(
                    'Could not extract RAR. Install a RAR extractor (unrar/7z) or place the vehicle in an extracted folder.'
                ) from last_exc
    else:
        raise ValueError(f'Unsupported vehicle input: {source.name}')

    children = [p for p in work_dir.iterdir()]
    dirs = [p for p in children if p.is_dir()]
    files = [p for p in children if p.is_file()]
    if len(dirs) == 1 and not files:
        return dirs[0]
    return work_dir


def _expand_rpfs_in_tree(root, extractor):
    """Extract every RPF found anywhere in a vehicle package so Y* resources
    inside a supplied DLC/RPF become discoverable by the 5-car workflow.
    The original RPF container is removed only after a successful extraction.
    """
    import shutil
    root = Path(root)
    extractor = Path(extractor)
    seen = set()
    changed = True
    while changed:
        changed = False
        rpfs = sorted([p for p in root.rglob('*.rpf') if p.is_file()],
                      key=lambda x: (len(x.parts), str(x).lower()))
        for rpf in rpfs:
            key = str(rpf.resolve())
            if key in seen:
                continue
            seen.add(key)
            out_dir = rpf.with_suffix('')
            # Never overwrite a real pre-existing extraction folder. If it is
            # already present, simply use it and continue scanning deeper.
            if out_dir.is_dir():
                changed = True
                continue
            print(f'[5 CARS DLC] Extracting nested RPF: {rpf.relative_to(root)}')
            ex = safe_subprocess_run(
                [sys.executable, str(extractor), str(rpf), str(out_dir)],
                cwd=str(extractor.parent),
                input='A\n', text=True,
                env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
            )
            if ex.returncode != 0 or not out_dir.is_dir():
                raise RuntimeError(f'Could not extract vehicle RPF: {rpf.name}')
            rpf.unlink()
            changed = True
    return root


def _discover_replacement_vehicle(source_root):
    """Find one replacement vehicle set and optional tuning RPFs."""
    source_root = Path(source_root)
    resources = []
    for p in source_root.rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.yft', '.ytd'}:
            resources.append(p)
    if not resources:
        # Some replacement packs keep the vehicle resources inside a folder
        # named 'dlc' or inside dlc.rpf; the caller normally expands those RPFs
        # first. Keep this error explicit if a package genuinely has no models.
        raise RuntimeError(f'No .yft/.ytd vehicle files were found in input: {source_root}')

    yfts = [p for p in resources if p.suffix.lower() == '.yft']
    base_candidates = [p for p in yfts if not p.stem.lower().endswith('_hi')]
    model = sorted(base_candidates or yfts, key=lambda p: p.name.lower())[0].stem
    model = model[:-3] if model.lower().endswith('_hi') else model

    model_files = [p for p in resources if p.stem.lower() in {model.lower(), model.lower() + '_hi'}]
    if not model_files:
        model_files = resources

    rpf_files = [p for p in source_root.rglob('*.rpf') if p.is_file()]
    mods_rpfs = [p for p in rpf_files if 'mod' in p.stem.lower()]
    other_rpfs = [p for p in rpf_files if p not in mods_rpfs]
    return model, model_files, mods_rpfs, other_rpfs


def _find_donor_meta_files(source_root):
    """Locate optional donor metadata shipped with a replacement package."""
    source_root = Path(source_root)
    wanted = {k: None for k in ("vehicles.meta", "handling.meta", "carvariations.meta", "vehiclelayouts.meta")}
    for p in source_root.rglob('*'):
        if p.is_file() and p.name.lower() in wanted and wanted[p.name.lower()] is None:
            wanted[p.name.lower()] = p
    return wanted

def _xml_item_matching_model(meta_path, model_name):
    if not meta_path: return None
    try:
        import xml.etree.ElementTree as ET
        root = ET.parse(meta_path).getroot()
        for item in root.iter('Item'):
            if (item.findtext('modelName') or '').strip().lower() == model_name.lower():
                return item
    except Exception:
        pass
    return None

def _xml_item_matching_handling(meta_path, handling_name):
    if not meta_path: return None
    try:
        import xml.etree.ElementTree as ET
        root = ET.parse(meta_path).getroot()
        for item in root.iter('Item'):
            if (item.findtext('handlingName') or '').strip().lower() == handling_name.lower():
                return item
    except Exception:
        pass
    return None

def _write_vehicle_addon_meta(addon_root, addon_name, donor_name, has_mods, donor_meta=None):
    """Generate a conservative GTA V add-on metadata set.

    This mode is packaging-only: original PC YFT/YTD resources are kept intact.
    The generated vehicle keeps the original replacement model/spawn name so the
    generated Add-On matches the vehicle files and can be entered normally.
    """
    from xml.sax.saxutils import escape
    data = Path(addon_root) / 'data'
    data.mkdir(parents=True, exist_ok=True)
    addon_upper = addon_name.upper()
    donor_upper = donor_name.upper()
    donor_meta = donor_meta or {}
    donor_vehicle_item = _xml_item_matching_model(donor_meta.get('vehicles.meta'), donor_name)
    donor_handling_name = ((donor_vehicle_item.findtext('handlingId') if donor_vehicle_item is not None else '') or donor_upper).strip()
    donor_handling_item = _xml_item_matching_handling(donor_meta.get('handling.meta'), donor_handling_name)
    layout_name = ((donor_vehicle_item.findtext('layout') if donor_vehicle_item is not None else '') or 'LAYOUT_STANDARD').strip()

    vehicles_meta = f"""<?xml version="1.0" encoding="UTF-8"?>
<CVehicleModelInfo__InitDataList>
  <residentTxd>vehshare</residentTxd>
  <residentAnims />
  <InitDatas>
    <Item>
      <modelName>{escape(addon_name)}</modelName>
      <txdName>{escape(addon_name)}</txdName>
      <handlingId>{escape(addon_upper if donor_handling_item is None else donor_handling_name)}</handlingId>
      <gameName>{escape(addon_upper)}</gameName>
      <vehicleMakeName>CUSTOM</vehicleMakeName>
      <expressionDictName>null</expressionDictName>
      <expressionName>null</expressionName>
      <animConvRoofDictName>null</animConvRoofDictName>
      <animConvRoofName>null</animConvRoofName>
      <animConvRoofWindowsAffected />
      <ptfxAssetName>null</ptfxAssetName>
      <audioNameHash>{escape(donor_upper)}</audioNameHash>
      <layout>{escape(layout_name)}</layout>
      <coverBoundOffsets>STD_COVER_OFFSET_INFO</coverBoundOffsets>
      <explosionInfo>EXPLOSION_INFO_DEFAULT</explosionInfo>
      <scenarioLayout />
      <cameraName>DEFAULT_FOLLOW_VEHICLE_CAMERA</cameraName>
      <aimCameraName>DEFAULT_THIRD_PERSON_VEHICLE_AIM_CAMERA</aimCameraName>
      <bonnetCameraName>VEHICLE_BONNET_CAMERA_STANDARD</bonnetCameraName>
      <povCameraName>DEFAULT_POV_CAMERA</povCameraName>
      <FirstPersonDriveByIKOffset x="0.000000" y="-0.060000" z="-0.040000" />
      <FirstPersonDriveByUnarmedIKOffset x="0.000000" y="-0.060000" z="-0.020000" />
      <PovCameraOffset x="0.000000" y="-0.210000" z="0.600000" />
      <PovCameraVerticalAdjustmentForRollCage value="0.000000" />
      <PovPassengerCameraOffset x="0.000000" y="0.000000" z="0.000000" />
      <vfxInfoName>VFXVEHICLEINFO_CAR_GENERIC</vfxInfoName>
      <shouldUseCinematicViewMode value="true" />
      <shouldCameraTransitionOnClimbUpDown value="false" />
      <shouldCameraIgnoreExiting value="false" />
      <AllowPretendOccupants value="true" />
      <AllowJoyriding value="true" />
      <AllowSundayDriving value="true" />
      <AllowBodyColorMapping value="true" />
      <wheelScale value="0.288000" />
      <wheelScaleRear value="0.288000" />
      <dirtLevelMin value="0.000000" />
      <dirtLevelMax value="0.550000" />
      <envEffScaleMin value="0.000000" />
      <envEffScaleMax value="1.000000" />
      <envEffScaleMin2 value="0.000000" />
      <envEffScaleMax2 value="1.000000" />
      <damageMapScale value="0.000000" />
      <damageOffsetScale value="0.000000" />
      <diffuseTint value="0x00FFFFFF" />
      <steerWheelMult value="1.000000" />
      <HDTextureDist value="2.500000" />
      <lodDistances content="float_array">70.000000 70.000000 100.000000 180.000000 220.000000 260.000000</lodDistances>
      <minSeatHeight value="0.800000" />
      <identicalModelSpawnDistance value="20" />
      <maxNumOfSameColor value="1" />
      <defaultBodyHealth value="1000.000000" />
      <pretendOccupantsScale value="1.000000" />
      <visibleSpawnDistScale value="1.000000" />
      <trackerPathWidth value="2.000000" />
      <weaponForceMult value="1.000000" />
      <frequency value="10" />
      <swankness>SWANKNESS_3</swankness>
      <maxNum value="10" />
      <flags>FLAG_AVERAGE_CAR</flags>
      <type>VEHICLE_TYPE_CAR</type>
      <plateType>VPT_FRONT_AND_BACK_PLATES</plateType>
      <dashboardType>VDT_GENTAXI</dashboardType>
      <vehicleClass>VC_SEDAN</vehicleClass>
      <wheelType>VWT_SPORT</wheelType>
      <trailers />
      <additionalTrailers />
      <drivers />
      <extraIncludes />
      <doorsWithCollisionWhenClosed />
      <driveableDoors />
      <bumpersNeedToCollideWithMap value="false" />
      <needsRopeTexture value="false" />
      <requiredExtras />
      <rewards />
      <cinematicPartCamera>
        <Item>WHEEL_FRONT_RIGHT_CAMERA</Item>
        <Item>WHEEL_FRONT_LEFT_CAMERA</Item>
        <Item>WHEEL_REAR_RIGHT_CAMERA</Item>
        <Item>WHEEL_REAR_LEFT_CAMERA</Item>
      </cinematicPartCamera>
      <NmBraceOverrideSet />
      <buoyancySphereOffset x="0.000000" y="0.000000" z="0.000000" />
      <buoyancySphereSizeScale value="1.000000" />
      <pOverrideRagdollThreshold type="NULL" />
    </Item>
  </InitDatas>
  <txdRelationships>
    <Item>
      <parent>vehicles_dom_interior</parent>
      <child>{escape(addon_name)}</child>
    </Item>
  </txdRelationships>
</CVehicleModelInfo__InitDataList>
"""
    handling_meta = f"""<?xml version="1.0" encoding="UTF-8"?>
<CHandlingDataMgr>
  <HandlingData>
    <Item type="CHandlingData">
      <handlingName>{escape(addon_upper)}</handlingName>
      <fMass value="1600.000000" />
      <fInitialDragCoeff value="8.500000" />
      <fPercentSubmerged value="85.000000" />
      <vecCentreOfMassOffset x="0.000000" y="0.000000" z="0.000000" />
      <vecInertiaMultiplier x="1.000000" y="1.800000" z="2.000000" />
      <fDriveBiasFront value="0.000000" />
      <nInitialDriveGears value="6" />
      <fInitialDriveForce value="0.280000" />
      <fDriveInertia value="1.000000" />
      <fClutchChangeRateScaleUpShift value="2.000000" />
      <fClutchChangeRateScaleDownShift value="2.000000" />
      <fInitialDriveMaxFlatVel value="180.000000" />
      <fBrakeForce value="1.000000" />
      <fBrakeBiasFront value="0.550000" />
      <fHandBrakeForce value="0.700000" />
      <fSteeringLock value="38.000000" />
      <fTractionCurveMax value="2.650000" />
      <fTractionCurveMin value="2.450000" />
      <fTractionCurveLateral value="23.000000" />
      <fTractionSpringDeltaMax value="0.120000" />
      <fLowSpeedTractionLossMult value="1.000000" />
      <fCamberStiffnesss value="0.000000" />
      <fTractionBiasFront value="0.500000" />
      <fTractionLossMult value="1.000000" />
      <fSuspensionForce value="2.200000" />
      <fSuspensionCompDamp value="1.500000" />
      <fSuspensionReboundDamp value="2.500000" />
      <fSuspensionUpperLimit value="0.060000" />
      <fSuspensionLowerLimit value="-0.070000" />
      <fSuspensionRaise value="0.000000" />
      <fSuspensionBiasFront value="0.500000" />
      <fAntiRollBarForce value="0.850000" />
      <fAntiRollBarBiasFront value="0.520000" />
      <fRollCentreHeightFront value="0.320000" />
      <fRollCentreHeightRear value="0.300000" />
      <fCollisionDamageMult value="0.000000" />
      <fWeaponDamageMult value="0.000000" />
      <fDeformationDamageMult value="0.000000" />
      <fEngineDamageMult value="0.000000" />
      <fPetrolTankVolume value="65.000000" />
      <fOilVolume value="5.000000" />
      <fSeatOffsetDistX value="0.000000" />
      <fSeatOffsetDistY value="-0.100000" />
      <fSeatOffsetDistZ value="0.000000" />
      <nMonetaryValue value="50000" />
      <strModelFlags>440010</strModelFlags>
      <strHandlingFlags>0</strHandlingFlags>
      <strDamageFlags>0</strDamageFlags>
      <AIHandling>AVERAGE</AIHandling>
      <SubHandlingData>
        <Item type="CCarHandlingData" />
        <Item type="NULL" />
        <Item type="NULL" />
      </SubHandlingData>
    </Item>
  </HandlingData>
</CHandlingDataMgr>
"""
    # Large GTA V-style palette: each spawn can receive a different primary/secondary
    # color. Pearlescent values are deliberately varied for metallic-looking finishes.
    # Format: (primary, secondary, pearlescent, wheel)
    color_presets = [
        (111,111,0,0),    # ice white
        (106,106,5,0),    # cream / pearl white
        (4,4,5,0),        # silver metallic
        (5,5,4,0),        # bluish silver
        (7,7,8,0),        # shadow silver
        (10,10,7,0),      # cast iron silver
        (27,27,30,0),     # dark red
        (36,36,31,0),     # bright red
        (38,38,33,0),     # vermillion red
        (64,64,28,0),     # orange
        (88,88,93,0),     # yellow
        (89,89,94,0),     # race yellow
        (53,53,52,0),     # dark green
        (49,49,51,0),     # green
        (50,50,57,0),     # sea green
        (38,38,40,0),     # dark blue
        (54,54,64,0),     # blue
        (70,70,71,0),     # bright blue
        (73,73,74,0),     # deep blue
        (145,145,111,0),  # dark purple
        (71,71,145,0),    # purple
        (148,148,135,0),  # pink
        (135,135,138,0),  # hot pink
        (0,0,0,0),        # gloss black
        (12,12,0,0),      # matte black
        (13,13,0,0),      # matte gray
        (15,15,4,0),      # util black metallic
        (19,19,4,0),      # gun metal
        (20,20,7,0),      # shadow silver metallic
        (42,42,6,0),      # worn gold
        (43,43,6,0),      # gold
        (99,99,6,0),      # bronze
        (101,101,4,0),    # copper
        (120,120,8,0),    # brushed gold
        (123,123,5,0),    # champagne
        (127,127,4,0),    # brushed silver
        (135,135,111,0),  # candy pink pearl
        (70,70,81,0),     # blue pearl
        (64,64,93,0),     # orange/gold pearl
        (36,36,30,0),     # red pearl
        (53,53,57,0),     # green pearl
        (71,71,111,0),    # purple pearl
    ]
    color_items = []
    for primary, secondary, pearlescent, wheel in color_presets:
        color_items.append(f"        <Item>\n          <indices content=\"char_array\">{primary} {secondary} {pearlescent} {wheel}</indices>\n          <liveries>\n            <Item value=\"false\" /><Item value=\"false\" /><Item value=\"false\" /><Item value=\"false\" />\n            <Item value=\"false\" /><Item value=\"false\" /><Item value=\"false\" /><Item value=\"false\" />\n          </liveries>\n        </Item>")
    carvariations = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<CVehicleModelInfoVariation>\n  <variationData>\n    <Item>\n'
        f'      <modelName>{escape(addon_name)}</modelName>\n      <colors>\n{chr(10).join(color_items)}\n      </colors>\n'
        '      <kits />\n      <windowsWithExposedEdges />\n      <plateProbabilities>\n        <Probabilities><Item><Name>Standard White</Name><Value value="100" /></Item></Probabilities>\n      </plateProbabilities>\n      <lightSettings value="0" />\n      <sirenSettings value="0" />\n    </Item>\n  </variationData>\n</CVehicleModelInfoVariation>\n'
    )
    carcols = '<?xml version="1.0" encoding="UTF-8"?>\n<CVehicleModelInfoVarGlobal>\n  <Kits />\n</CVehicleModelInfoVarGlobal>\n'
    dlctext = '<?xml version="1.0" encoding="UTF-8"?>\n<CExtraTextMetaFile>\n  <hasGlobalTextFile value="true"/>\n  <hasAdditionalText value="false"/>\n  <isTitleUpdate value="false"/>\n</CExtraTextMetaFile>\n'
    (data / 'vehicles.meta').write_text(vehicles_meta, encoding='utf-8')
    if donor_meta.get('vehiclelayouts.meta'):
        try:
            import shutil
            shutil.copy2(donor_meta['vehiclelayouts.meta'], data / 'vehiclelayouts.meta')
        except Exception:
            pass
    (data / 'handling.meta').write_text(handling_meta, encoding='utf-8')
    (data / 'carvariations.meta').write_text(carvariations, encoding='utf-8')
    (data / 'carcols.meta').write_text(carcols, encoding='utf-8')
    (data / 'dlctext.meta').write_text(dlctext, encoding='utf-8')
    content_items = [
        ('data/vehicles.meta', 'VEHICLE_METADATA_FILE', False),
        ('data/carcols.meta', 'CARCOLS_FILE', False),
        ('data/carvariations.meta', 'VEHICLE_VARIATION_FILE', False),
        ('data/dlctext.meta', 'TEXTFILE_METAFILE', False),
        ('data/handling.meta', 'HANDLING_FILE', False),
    ]
    if (data / 'vehiclelayouts.meta').is_file():
        content_items.append(('data/vehiclelayouts.meta', 'VEHICLE_LAYOUTS_FILE', False))
    content_items.append(('%PLATFORM%/vehicles.rpf', 'RPF_FILE', True))
    if has_mods:
        content_items.append((f'%PLATFORM%/vehiclemods/{addon_name}_mods.rpf', 'RPF_FILE', True))
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<CDataFileMgr__ContentsOfDataFileXml>', '  <disabledFiles />', '  <includedXmlFiles />', '  <includedDataFiles />', '  <dataFiles>']
    for path, typ, persistent in content_items:
        lines += ['    <Item>', f'      <filename>dlc_{addon_name}:/{path}</filename>', f'      <fileType>{typ}</fileType>', '      <overlay value="false" />', '      <disabled value="true" />', f'      <persistent value="{str(persistent).lower()}" />', '    </Item>']
    lines += ['  </dataFiles>', '  <contentChangeSets>', '    <Item>', f'      <changeSetName>{addon_upper}_AUTOGEN</changeSetName>', '      <filesToDisable />', '      <filesToEnable>']
    for path, _typ, _persistent in content_items:
        lines.append(f'        <Item>dlc_{addon_name}:/{path}</Item>')
    lines += ['      </filesToEnable>', '      <txdToLoad />', '      <txdToUnload />', '      <residentResources />', '      <unregisterResources />', '    </Item>', '  </contentChangeSets>', '  <patchFiles />', '</CDataFileMgr__ContentsOfDataFileXml>', '']
    (Path(addon_root) / 'content.xml').write_text('\n'.join(lines), encoding='utf-8')
    setup = f"""<?xml version="1.0" encoding="UTF-8"?>
<SSetupData>
  <deviceName>dlc_{addon_name}</deviceName>
  <datFile>content.xml</datFile>
  <timeStamp>00/00/0000 00:00:00</timeStamp>
  <nameHash>{addon_name}</nameHash>
  <contentChangeSetGroups>
    <Item>
      <NameHash>GROUP_STARTUP</NameHash>
      <ContentChangeSets>
        <Item>{addon_upper}_AUTOGEN</Item>
      </ContentChangeSets>
    </Item>
  </contentChangeSetGroups>
  <type>EXTRACONTENT_COMPAT_PACK</type>
  <order value="9" />
</SSetupData>
"""
    (Path(addon_root) / 'setup2.xml').write_text(setup, encoding='utf-8')


def _convert_generated_vehicle_dlc_rpf(final_build, builder, root):
    """After replacement->DLC packaging, extract the generated DLC, convert its
    Y* resources to O* resources, rename x64 -> ps4, then rebuild the final DLC.
    This keeps the workflow automatic: replacement -> DLC -> resource conversion -> final DLC.
    """
    import shutil
    final_build = Path(final_build)
    root = Path(root)
    extract_tool = root / 'RPFBuilder' / 'extract_rpf.py'
    if not extract_tool.is_file():
        raise RuntimeError('RPFBuilder/extract_rpf.py is missing.')

    work = final_build.parent / '_auto_convert_dlc'
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    extracted = work / 'dlc.rpf'

    print('\n[AUTO CONVERT] Step 1/3: Extracting generated dlc.rpf...')
    ex = safe_subprocess_run(
        [sys.executable, str(extract_tool), str(final_build), str(extracted)],
        cwd=str(extract_tool.parent),
        input='A\\n', text=True,
        env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
    )
    if ex.returncode != 0 or not extracted.is_dir():
        raise RuntimeError('Could not extract the generated vehicle dlc.rpf.')

    # A vehicle DLC normally contains nested RPF containers such as
    # x64/vehicles.rpf.  The first version only converted loose files in the
    # top-level extraction, so the old Y* files inside nested RPFs survived.
    # Extract every nested RPF to a same-name folder, convert that folder too,
    # then rebuild the nested RPF before the final DLC build.
    nested_jobs = []
    seen_rpfs = set()
    changed = True
    while changed:
        changed = False
        for nested_rpf in sorted(extracted.rglob('*.rpf'), key=lambda x: len(x.parts)):
            if not nested_rpf.is_file() or nested_rpf in seen_rpfs:
                continue
            if nested_rpf == final_build:
                continue
            nested_folder = nested_rpf.with_suffix('')
            seen_rpfs.add(nested_rpf)
            if nested_folder.is_dir():
                nested_jobs.append((nested_folder, nested_rpf.name))
                continue
            print(f'[AUTO CONVERT] Extracting nested RPF: {nested_rpf.name}...')
            ex_nested = safe_subprocess_run(
                [sys.executable, str(extract_tool), str(nested_rpf), str(nested_folder)],
                cwd=str(extract_tool.parent),
                input='A\n', text=True,
                env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
            )
            if ex_nested.returncode != 0 or not nested_folder.is_dir():
                raise RuntimeError(f'Could not extract nested RPF: {nested_rpf.name}')
            nested_rpf.unlink()
            nested_jobs.append((nested_folder, nested_rpf.name))
            changed = True

    print('[AUTO CONVERT] Step 2/3: Converting Y* vehicle resources to O*...')
    count, failed = _convert_extracted_tree(extracted, root / 'core_converter.py', root, delete_y_all=True)
    if failed:
        print(f'[AUTO CONVERT] {len(failed)} file(s) had conversion/cleanup warnings.')
    print(f'[AUTO CONVERT] Converted {count} resource(s).')

    # Rebuild nested RPFs from their converted folders.  This is essential for
    # vehicles.rpf/vehiclemods-style containers: otherwise their original Y*
    # resources are packed back unchanged.
    rebuilt_nested = 0
    for nested_folder, nested_name in sorted(nested_jobs, key=lambda x: len(x[0].parts), reverse=True):
        if not nested_folder.is_dir():
            continue
        archive_nested = builder.parent / 'Archive.rpf'
        if archive_nested.exists():
            try: archive_nested.unlink()
            except OSError: pass
        result_nested = safe_subprocess_run(
            [sys.executable, str(builder), str(nested_folder)],
            cwd=str(builder.parent),
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
        )
        if result_nested.returncode != 0 or not archive_nested.is_file() or archive_nested.stat().st_size == 0:
            raise RuntimeError(f'Could not rebuild converted nested RPF: {nested_name}')
        target_nested = nested_folder.parent / nested_name
        if target_nested.exists():
            target_nested.unlink()
        shutil.move(str(archive_nested), str(target_nested))
        shutil.rmtree(nested_folder, ignore_errors=True)
        rebuilt_nested += 1
        print(f'[AUTO CONVERT] Rebuilt nested RPF: {nested_name} ✅')

    # Final recursive guard: after nested rebuilds, no supported Y* source may
    # remain anywhere in the extracted tree.  Do not allow old resources into
    # the final archive.
    leftovers = [p for p in extracted.rglob('*') if p.is_file() and p.suffix.lower() in SUPPORTED and p.suffix.lower().startswith('.y')]
    if leftovers:
        for old in leftovers:
            try:
                old.unlink()
                print(f'[AUTO CONVERT] Deleted old source: {old.name} 🧹')
            except OSError as exc:
                raise RuntimeError(f'Could not delete old Y* resource: {old}') from exc
    print(f'[AUTO CONVERT] Nested RPFs rebuilt: {rebuilt_nested}')

    # For the PS4 add-on, the platform folder must be ps4. Keep all other data
    # folders intact because this generated vehicle DLC needs its metadata.
    x64 = extracted / 'x64'
    ps4 = extracted / 'ps4'
    if x64.is_dir() and not ps4.exists():
        x64.rename(ps4)
        print('[AUTO CONVERT] Renamed x64 -> ps4 ✅')
    elif x64.is_dir() and ps4.is_dir():
        # Merge only when both exist; never overwrite existing PS4 files.
        for item in x64.iterdir():
            target = ps4 / item.name
            if target.exists():
                if item.is_dir() and target.is_dir():
                    for sub in item.rglob('*'):
                        rel = sub.relative_to(item)
                        dst = target / rel
                        if sub.is_dir():
                            dst.mkdir(parents=True, exist_ok=True)
                        elif not dst.exists():
                            shutil.copy2(sub, dst)
                continue
            shutil.move(str(item), str(target))
        shutil.rmtree(x64, ignore_errors=True)
        print('[AUTO CONVERT] Merged x64 -> ps4 ✅')

    # Never rebuild while supported Y* resources remain.
    leftovers = [p for p in extracted.rglob('*') if p.is_file() and p.suffix.lower() in SUPPORTED and p.suffix.lower().startswith('.y')]
    if leftovers:
        raise RuntimeError(f'Automatic conversion left {len(leftovers)} Y* resource(s); final build cancelled safely.')

    print('[AUTO CONVERT] Step 3/3: Rebuilding converted dlc.rpf...')
    stale = builder.parent / 'Archive.rpf'
    if stale.exists():
        try: stale.unlink()
        except OSError: pass
    rebuilt = safe_subprocess_run(
        [sys.executable, str(builder), str(extracted)],
        cwd=str(builder.parent),
        env={**os.environ, 'PYTHONIOENCODING': 'utf-8'},
    )
    archive = builder.parent / 'Archive.rpf'
    if rebuilt.returncode != 0 or not archive.is_file() or archive.stat().st_size == 0:
        raise RuntimeError('Could not rebuild the converted vehicle dlc.rpf.')

    temp = final_build.parent / '.dlc.rpf.auto_building'
    if temp.exists(): temp.unlink()
    shutil.move(str(archive), str(temp))
    temp.replace(final_build)
    shutil.rmtree(work, ignore_errors=True)
    print(f'[AUTO CONVERT] Final converted DLC ready: {final_build} ({final_build.stat().st_size:,} bytes) ✅')



def _merge_vehicle_meta_files(inputs, output, model_renames):
    """Merge donor XML metadata while renaming each donor model to its new spawn name."""
    import xml.etree.ElementTree as ET
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    parsed = []
    for src, old_model, new_model in inputs:
        try:
            root = ET.parse(src).getroot()
        except Exception:
            continue
        old_l, new_l = old_model.lower(), new_model
        for elem in root.iter():
            if elem.text and elem.text.strip().lower() in {old_l, old_l.upper(), old_model}:
                elem.text = new_model
            for k,v in list(elem.attrib.items()):
                if v.strip().lower() == old_l:
                    elem.attrib[k] = new_model
        parsed.append(root)
    if not parsed:
        return False
    base = parsed[0]
    # Merge the meaningful direct containers used by GTA metadata.
    if base.tag.endswith('CVehicleModelInfo__InitDataList'):
        container = base.find('InitDatas')
        if container is not None:
            existing = {((x.findtext('modelName') or '').strip().lower()) for x in container.findall('Item')}
            for root in parsed[1:]:
                c = root.find('InitDatas')
                if c is not None:
                    for item in c.findall('Item'):
                        name=(item.findtext('modelName') or '').strip().lower()
                        if name and name not in existing:
                            container.append(item); existing.add(name)
    elif base.tag.endswith('CHandlingDataMgr'):
        container = base.find('HandlingData')
        if container is not None:
            existing = {((x.findtext('handlingName') or '').strip().lower()) for x in container.findall('Item')}
            for root in parsed[1:]:
                c=root.find('HandlingData')
                if c is not None:
                    for item in c.findall('Item'):
                        name=(item.findtext('handlingName') or '').strip().lower()
                        if name and name not in existing:
                            container.append(item); existing.add(name)
    else:
        # For carvariations/carcols/layouts and similar files, merge direct Item
        # children into the first matching container when possible.
        def containers(r):
            return [e for e in r.iter() if any(ch.tag.endswith('Item') for ch in list(e))]
        base_containers=containers(base)
        for root in parsed[1:]:
            for bc in base_containers:
                path_tag=bc.tag
                rc=next((e for e in root.iter() if e.tag==path_tag), None)
                if rc is None: continue
                seen={ET.tostring(x, encoding='unicode') for x in list(bc)}
                for item in list(rc):
                    raw=ET.tostring(item, encoding='unicode')
                    if raw not in seen:
                        bc.append(item); seen.add(raw)
    ET.ElementTree(base).write(output, encoding='utf-8', xml_declaration=True)
    return True


def _write_multi_dlc_descriptor(root, dlc_name, vehicle_entries, mod_entries):
    from xml.sax.saxutils import escape
    root=Path(root)
    common=root/'common'/'data'
    (common/'levels'/'gta5').mkdir(parents=True, exist_ok=True)
    (common/'ai').mkdir(parents=True, exist_ok=True)
    lines=['<?xml version="1.0" encoding="UTF-8"?>','<CDataFileMgr__ContentsOfDataFileXml>','  <disabledFiles />','  <includedXmlFiles />','  <includedDataFiles />','  <dataFiles>']
    files=[('common/data/vehicles.meta','VEHICLE_METADATA_FILE'),('common/data/carvariations.meta','VEHICLE_VARIATION_FILE'),('common/data/carcols.meta','CARCOLS_FILE'),('common/data/dlctext.meta','TEXTFILE_METAFILE'),('common/data/ai/vehiclelayouts.meta','VEHICLE_LAYOUTS_FILE'),('common/data/handling.meta','HANDLING_FILE'),('common/data/carraddonContentUnlocks.meta','CONTENT_UNLOCKING_META_FILE')]
    for rel,typ in files:
        if (root/rel).is_file():
            lines += [f'    <Item><filename>{dlc_name}:/{rel}</filename><fileType>{typ}</fileType><overlay value="false" /><disabled value="true" /><persistent value="true" /></Item>']
    lines += [f'    <Item><filename>{dlc_name}:/%PLATFORM%/levels/gta5/vehicles/{dlc_name}vehicles.rpf</filename><fileType>RPF_FILE</fileType><overlay value="false" /><disabled value="true" /><persistent value="true" /></Item>']
    for mod in mod_entries:
        lines += [f'    <Item><filename>{dlc_name}:/%PLATFORM%/levels/{dlc_name}/vehiclemods/{mod}.rpf</filename><fileType>RPF_FILE</fileType><overlay value="false" /><disabled value="true" /><persistent value="true" /></Item>']
    lines += ['  </dataFiles>','  <contentChangeSets>','    <Item>','      <changeSetName>DEFAULT</changeSetName>','      <filesToDisable />','      <filesToEnable />','      <filesToCopy />','    </Item>','  </contentChangeSets>','</CDataFileMgr__ContentsOfDataFileXml>']
    (root/'content.xml').write_text('\n'.join(lines), encoding='utf-8')
    setup=f"""<?xml version="1.0" encoding="UTF-8"?>\n<SSetupData>\n  <deviceName>dlc_{escape(dlc_name)}</deviceName>\n  <datFile>content.xml</datFile>\n  <nameHash>{escape(dlc_name)}</nameHash>\n  <contentChangeSetGroups><Item><NameHash>GROUP_STARTUP</NameHash><ContentChangeSets><Item>{escape(dlc_name)}_AUTOGEN</Item></ContentChangeSets></Item></contentChangeSetGroups>\n  <type>EXTRACONTENT_COMPAT_PACK</type>\n  <order value="4" />\n</SSetupData>"""
    (root/'setup2.xml').write_text(setup, encoding='utf-8')


def five_vehicles_one_dlc():
    """Build exactly five vehicle DLC sources into one PS4-ready add-on pack.

    Input is intentionally permissive: each of the five folders may contain a
    complete DLC, a dlc.rpf, nested RPFs, or loose YFT/YTD files.  The output
    layout follows the supplied 5car reference: common/data plus
    %PLATFORM%/levels/gta5/vehicles/<pack>vehicles.rpf and
    %PLATFORM%/levels/<pack>/vehiclemods/*.rpf.
    """
    import shutil
    base=ROOT/'5 cars DLC'
    finish=base/'Finish'
    builder=ROOT/'RPFBuilder'/'build_rpf.py'
    base.mkdir(parents=True, exist_ok=True); finish.mkdir(parents=True, exist_ok=True)
    inputs=[]
    for p in sorted(base.iterdir(), key=lambda x:x.name.lower()):
        if p.name in {'Finish','_work','_build'} or p.name.startswith('_'): continue
        if p.is_dir() or (p.is_file() and p.suffix.lower() in {'.zip','.rar'}): inputs.append(p)
    if len(inputs)!=5:
        print(f'[5 CARS DLC] Put exactly 5 vehicle folders or .zip/.rar packages in: {base}')
        print(f'[5 CARS DLC] Found: {len(inputs)}')
        return 1

    work=base/'_work'; build=base/'_build'
    shutil.rmtree(work, ignore_errors=True); shutil.rmtree(build, ignore_errors=True)
    work.mkdir(); build.mkdir()
    try:
        sources=[]
        for i,src in enumerate(inputs,1):
            dst=work/f'car{i}'; dst.mkdir()
            if src.is_dir():
                for item in src.iterdir():
                    target=dst/item.name
                    if item.is_dir(): shutil.copytree(item,target)
                    else: shutil.copy2(item,target)
            else:
                extracted=_extract_vehicle_package(src,dst)
                if extracted != dst:
                    for item in extracted.iterdir():
                        target=dst/item.name
                        if item.is_dir(): shutil.copytree(item,target)
                        else: shutil.copy2(item,target)
            _expand_rpfs_in_tree(dst, ROOT/'RPFBuilder'/'extract_rpf.py')
            sources.append(dst)

        entries=[]
        print('\n[5 CARS DLC] Exactly 5 vehicles detected. Enter spawn names:')
        for i,src in enumerate(sources,1):
            model, model_files, mods_rpfs, other_rpfs=_discover_replacement_vehicle(src)
            print(f'  [{i}/5] Detected vehicle: {model}')
            while True:
                raw=input(f'  [{i}/5] {model} -> spawn name: ').strip()
                name=_sanitize_vehicle_name(raw)
                if name!='vehicle_addon' and name:
                    break
                print('[ERROR] Invalid spawn name.')
            # Record the user selection explicitly; later stages use this exact
            # value for model/txd/handling references and output filenames.
            print(f'  [{i}/5] Spawn selected: {name}  <- source {model}')
            entries.append((model,name,model_files,mods_rpfs,other_rpfs,src))

        # Reference layout: common/data and platform-specific resources.
        common=build/'common'/'data'
        (common/'ai').mkdir(parents=True, exist_ok=True)
        vehicles_dir=build/'x64'/'levels'/'gta5'/'vehicles'
        mods_dir=build/'x64'/'levels'/'five_cars_pack'/'vehiclemods'
        vehicles_dir.mkdir(parents=True, exist_ok=True)
        mods_dir.mkdir(parents=True, exist_ok=True)

        dlc_name='five_cars_pack'
        all_meta={k:[] for k in ('vehicles.meta','handling.meta','carvariations.meta','carcols.meta','vehiclelayouts.meta')}
        mod_names=[]

        # Put every vehicle's model set into one vehicles RPF, using the selected
        # spawn name.  Keep all non-model Y* resources associated with the model
        # only when they are clearly part of that vehicle.
        vehicle_source=vehicles_dir/f'{dlc_name}vehicles_source'
        vehicle_source.mkdir(parents=True, exist_ok=True)
        used_model_names=set()
        for model,name,model_files,mods_rpfs,other_rpfs,src in entries:
            for p in model_files:
                stem=p.stem
                sl=stem.lower()
                if sl == model.lower(): out=f'{name}{p.suffix.lower()}'
                elif sl == model.lower()+'_hi': out=f'{name}_hi{p.suffix.lower()}'
                else: out=f'{name}_{p.name}'
                target=vehicle_source/out
                # Avoid accidental collision between packs whose source names
                # contain the same auxiliary filename.
                if target.exists():
                    target=f'{name}_{p.name}'
                shutil.copy2(p,target)
                used_model_names.add(target.name.lower())

            donor=_find_donor_meta_files(src)
            for k,v in donor.items():
                if v: all_meta[k].append((v,model,name))

            # Match the reference's author/mod RPF naming: <source folder>_mods.rpf.
            # Prefer a real mods folder; if only a mods RPF exists, preserve it.
            mods_dirs=[p for p in src.rglob('*') if p.is_dir() and 'mod' in p.name.lower() and any(q.is_file() for q in p.rglob('*'))]
            mod_source=mods_dirs[0] if mods_dirs else None
            author=src.name
            if mod_source:
                ar=builder.parent/'Archive.rpf'
                if ar.exists(): ar.unlink()
                r=safe_subprocess_run([sys.executable,str(builder),str(mod_source)],cwd=str(builder.parent))
                ar=builder.parent/'Archive.rpf'
                if r.returncode!=0 or not ar.is_file() or ar.stat().st_size==0:
                    raise RuntimeError(f'Could not build vehiclemods for {name}')
                modfile=f'{_sanitize_vehicle_name(author)}_mods.rpf'
                shutil.move(str(ar),str(mods_dir/modfile))
                mod_names.append(Path(modfile).stem)
                print(f'  [MODS] {name}: {modfile}')
            elif mods_rpfs:
                # Preserve the first supplied mods RPF as a fallback. If the
                # source has a nested vehiclemods RPF, it is carried as-is.
                rpf=mods_rpfs[0]
                modfile=f'{_sanitize_vehicle_name(author)}_mods.rpf'
                shutil.copy2(rpf,mods_dir/modfile)
                mod_names.append(Path(modfile).stem)
                print(f'  [MODS] {name}: carried {modfile}')

        # Merge donor metadata.  The merge function rewrites exact old model
        # references to the user's selected spawn name.
        for k,items in all_meta.items():
            if not items: continue
            out=common/k
            if k=='vehiclelayouts.meta': out=common/'ai'/k
            _merge_vehicle_meta_files(items,out,[(a,b) for _,a,b in items])

        first_src=entries[0][5]
        for fname,default in [
            ('dlctext.meta','<?xml version="1.0" encoding="UTF-8"?><CTextFileMerger__InitDataList><dataFiles /></CTextFileMerger__InitDataList>'),
            ('carraddonContentUnlocks.meta','<?xml version="1.0" encoding="UTF-8"?><CContentUnlockingMetaData><contentUnlockingItems /></CContentUnlockingMetaData>')]:
            if not (common/fname).exists():
                found=next((p for p in first_src.rglob(fname)),None)
                if found: shutil.copy2(found,common/fname)
                else: (common/fname).write_text(default,encoding='utf-8')

        # Generate content.xml/setup2.xml using the same paths as the reference.
        _write_multi_dlc_descriptor(build,dlc_name,entries,mod_names)

        # Build the combined vehicles RPF at common reference path.
        ar=builder.parent/'Archive.rpf'
        if ar.exists(): ar.unlink()
        r=safe_subprocess_run([sys.executable,str(builder),str(vehicle_source)],cwd=str(builder.parent))
        ar=builder.parent/'Archive.rpf'
        if r.returncode!=0 or not ar.is_file() or ar.stat().st_size==0:
            raise RuntimeError('Could not build combined vehicles RPF')
        final_vehicle_rpf=vehicles_dir/f'{dlc_name}vehicles.rpf'
        if final_vehicle_rpf.exists(): final_vehicle_rpf.unlink()
        shutil.move(str(ar),str(final_vehicle_rpf))
        shutil.rmtree(vehicle_source,ignore_errors=True)

        # Build the complete DLC in one RPF.
        final=finish/'dlc.rpf'
        if final.exists(): final.unlink()
        ar=builder.parent/'Archive.rpf'
        if ar.exists(): ar.unlink()
        r=safe_subprocess_run([sys.executable,str(builder),str(build)],cwd=str(builder.parent))
        ar=builder.parent/'Archive.rpf'
        if r.returncode!=0 or not ar.is_file() or ar.stat().st_size==0:
            raise RuntimeError('Could not build 5-car DLC')
        shutil.move(str(ar),str(final))
        print(f'[5 CARS DLC] Built: {final}')

        # Automatic Y* -> O* conversion, nested RPF rebuild, x64 -> ps4 and
        # final fresh DLC rebuild.
        _convert_generated_vehicle_dlc_rpf(final,builder,ROOT)
        print('[5 CARS DLC] Conversion + rebuild complete. 🔥')
        print('[5 CARS DLC] Selected spawn names are now embedded in filenames and metadata:')
        for _,name,_,_,_,_ in entries:
            print(f'    ✓ {name}')
        return 0
    except Exception as exc:
        print(f'[5 CARS DLC] ERROR: {type(exc).__name__}: {exc}')
        return 1
    finally:
        shutil.rmtree(work,ignore_errors=True)
        shutil.rmtree(build,ignore_errors=True)

def vehicles_to_dlc_rpf():
    """Package a replacement vehicle into DLC, then automatically convert its Y* resources."""
    import shutil
    # Android/Windows filenames cannot contain '>' or ':'; keep the menu label
    # as 'Vehicles --> DLC.RPF' but use a filesystem-safe input folder name.
    vehicle_dir = ROOT / 'vehicles to dlc.rpf'
    finish_dir = vehicle_dir / 'Finish'
    source_dir = vehicle_dir / '_source_working'
    build_root = vehicle_dir / '_addon_build'
    builder = ROOT / 'RPFBuilder' / 'build_rpf.py'
    vehicle_dir.mkdir(parents=True, exist_ok=True)
    finish_dir.mkdir(parents=True, exist_ok=True)
    # Android file managers can inherit restrictive permissions on folders
    # created by another app. Try to make this input folder user-writable;
    # on filesystems that ignore chmod this is harmless.
    try:
        os.chmod(vehicle_dir, 0o777)
        os.chmod(finish_dir, 0o777)
    except OSError:
        pass

    candidates = []
    loose_vehicle_files = []
    for p in sorted(vehicle_dir.iterdir(), key=lambda x: x.name.lower()):
        if p.name in {'Finish', '_source_working', '_addon_build', 'archive_input'} or p.name.startswith('_'):
            continue
        if p.is_dir() or (p.is_file() and p.suffix.lower() in {'.rar', '.zip'}):
            candidates.append(p)
        elif p.is_file() and p.suffix.lower() in {'.yft', '.ytd'}:
            # Also accept loose replacement files directly in the input folder.
            # This avoids forcing Android users to move files into another
            # subfolder, which can fail with "Operation not permitted".
            loose_vehicle_files.append(p)

    if loose_vehicle_files and not candidates:
        candidates = [vehicle_dir]
    if not candidates:
        print(f'[VEHICLES -> DLC.RPF] Put one replacement vehicle (.rar/.zip, extracted folder, or loose .yft/.ytd files) here:\n    {vehicle_dir}')
        return 1
    if len(candidates) > 1:
        print('[WARN] More than one vehicle input was found. This mode builds one DLC at a time.')
        print(f'[INFO] Using: {candidates[0].name}')
    source = candidates[0]

    # Ask for the Add-On/spawn name before building. The user-selected name
    # becomes the base name of the vehicle files (for example, entering
    # "apc" produces apc.yft, apc_hi.yft and apc.ytd) and is also used
    # throughout the generated DLC metadata.
    while True:
        requested_name = input('\nEnter vehicle spawn name (example: apc): ').strip()
        addon_name_override = _sanitize_vehicle_name(requested_name)
        if requested_name and addon_name_override != 'vehicle_addon':
            break
        print('[ERROR] Invalid vehicle name. Use letters, numbers, _ or -.')

    try:
        if not builder.is_file():
            print('[ERROR] RPFBuilder/build_rpf.py is missing.')
            return 1
        if source_dir.exists(): shutil.rmtree(source_dir, ignore_errors=True)
        if build_root.exists(): shutil.rmtree(build_root, ignore_errors=True)
        if source == vehicle_dir:
            # Use the input folder itself as the source when the user placed
            # loose YFT/YTD files directly here. Do not copy/move them.
            work = vehicle_dir
        else:
            work = _extract_vehicle_package(source, source_dir)
        model, model_files, mods_rpfs, other_rpfs = _discover_replacement_vehicle(work)
        if not model_files:
            print('[ERROR] No vehicle model files (.yft/.ytd) were found. Build cancelled safely.')
            return 1
        addon_name = addon_name_override
        print('\n[VEHICLES -> DLC.RPF] Starting...')
        print(f'[INFO] Replacement model: {model}')
        print(f'[INFO] Add-On / spawn name: {addon_name}')
        print(f'[INFO] Vehicle files will be renamed to: {addon_name}.yft / {addon_name}_hi.yft / {addon_name}.ytd')
        print('[INFO] PS4 conversion: ON — after DLC packaging, Y* resources will be converted automatically.')

        build_root.mkdir(parents=True, exist_ok=True)
        (build_root / 'data').mkdir(parents=True, exist_ok=True)
        (build_root / 'x64').mkdir(parents=True, exist_ok=True)
        vehicles_src = build_root / '_vehicles_source'
        vehicles_src.mkdir(parents=True, exist_ok=True)
        for p in model_files:
            lower_stem = p.stem.lower()
            suffix = p.suffix.lower()
            if lower_stem == model.lower() + '_hi':
                target_name = f'{addon_name}_hi{suffix}'
            elif lower_stem == model.lower():
                target_name = f'{addon_name}{suffix}'
            else:
                target_name = p.name
            shutil.copy2(p, vehicles_src / target_name)
        model_set = {p.resolve() for p in model_files}
        for p in work.rglob('*'):
            if not p.is_file() or p.resolve() in model_set or p.suffix.lower() == '.rpf':
                continue
            if p.suffix.lower() in {'.ydr', '.ydd', '.ybn', '.ycd', '.ypt', '.yld', '.ymap', '.ytyp', '.ymt', '.ymf', '.ynd', '.ynv', '.ywr', '.yvr', '.ypdb', '.ybd', '.yed', '.yfd'}:
                shutil.copy2(p, vehicles_src / p.name)

        stale_archive = builder.parent / 'Archive.rpf'
        if stale_archive.exists():
            try: stale_archive.unlink()
            except OSError: pass
        inner_result = safe_subprocess_run([sys.executable, str(builder), str(vehicles_src)], cwd=str(builder.parent))
        inner_archive = builder.parent / 'Archive.rpf'
        if inner_result.returncode != 0 or not inner_archive.is_file() or inner_archive.stat().st_size == 0:
            print('[ERROR] Could not build the inner vehicles.rpf.')
            return 1
        vehicles_rpf = build_root / 'x64' / 'vehicles.rpf'
        if vehicles_rpf.exists(): vehicles_rpf.unlink()
        shutil.move(str(inner_archive), str(vehicles_rpf))
        shutil.rmtree(vehicles_src, ignore_errors=True)

        has_mods = bool(mods_rpfs)
        if has_mods:
            mods_target = build_root / 'x64' / 'vehiclemods'
            mods_target.mkdir(parents=True, exist_ok=True)
            shutil.copy2(mods_rpfs[0], mods_target / f'{addon_name}_mods.rpf')
            if len(mods_rpfs) > 1:
                print(f'[WARN] {len(mods_rpfs)} tuning RPFs found; using the first one: {mods_rpfs[0].name}')

        for idx, p in enumerate(other_rpfs, 1):
            target = build_root / 'x64' / p.name
            if target.exists():
                target = build_root / 'x64' / f'{p.stem}_{idx}{p.suffix}'
            shutil.copy2(p, target)

        donor_meta = _find_donor_meta_files(work)
        found_meta = [k for k, v in donor_meta.items() if v is not None]
        if found_meta:
            print(f'[INFO] Donor metadata detected: {", ".join(found_meta)}')
        else:
            print('[INFO] No donor metadata in package; using safe fallback layout.')
        _write_vehicle_addon_meta(build_root, addon_name, model, has_mods, donor_meta)

        final_build = finish_dir / 'dlc.rpf'
        if final_build.exists(): final_build.unlink()
        top_archive = builder.parent / 'Archive.rpf'
        if top_archive.exists():
            try: top_archive.unlink()
            except OSError: pass
        top_result = safe_subprocess_run([sys.executable, str(builder), str(build_root)], cwd=str(builder.parent))
        top_archive = builder.parent / 'Archive.rpf'
        if top_result.returncode != 0 or not top_archive.is_file() or top_archive.stat().st_size == 0:
            print('[ERROR] Could not build the final add-on dlc.rpf.')
            return 1
        shutil.move(str(top_archive), str(final_build))
        print(f'[OK] Replacement vehicle -> DLC created: {final_build}')
        # New automatic sequence requested by the user:
        # 1) finish replacement -> DLC packaging
        # 2) extract that generated DLC
        # 3) convert all Y* resources to O*
        # 4) rename x64 -> ps4
        # 5) rebuild the final converted dlc.rpf in the same Finish folder
        _convert_generated_vehicle_dlc_rpf(final_build, builder, ROOT)
        print('[OK] Replacement -> DLC -> PS4 resource conversion completed successfully. ✅')
        print(f'    Final file: {final_build}')
        return 0
    except KeyboardInterrupt:
        print('\n[STOPPED] Vehicles -> DLC.RPF interrupted safely.')
        return 130
    except Exception as exc:
        print(f'[ERROR] Vehicles -> DLC.RPF failed: {type(exc).__name__}: {exc}')
        return 1
    finally:
        shutil.rmtree(source_dir, ignore_errors=True)
        shutil.rmtree(build_root, ignore_errors=True)


def _replace_character_template_text(path, original_name):
    """Apply the exact placeholder rules used by the character DLC template."""
    from pathlib import Path
    path = Path(path)
    text = path.read_text(encoding='utf-8')
    # Specific tokens first: preserve the requested case for each token.
    # dlc_TEMPLATE -> dlc_<lowercase spawn>
    text = text.replace('dlc_TEMPLATE', f'dlc_{original_name.lower()}')
    # TEMPLATE_GEN -> <UPPERCASE spawn>_GEN
    text = text.replace('TEMPLATE_GEN', f'{original_name.upper()}_GEN')
    # TEMPLATE.rpf -> exactly the case typed by the user.
    text = text.replace('TEMPLATE.rpf', f'{original_name}.rpf')
    # peds.meta and setup2.xml may contain a plain TEMPLATE placeholder.
    text = text.replace('TEMPLATE', original_name)
    path.write_text(text, encoding='utf-8')


def _character_convert_sources(src_dir, root):
    """Convert character source Y* files into a private archive_input tree."""
    import shutil
    src_dir = Path(src_dir)
    work = root / 'Characters One Click' / '_work'
    converted = work / 'converted'
    shutil.rmtree(work, ignore_errors=True)
    converted.mkdir(parents=True, exist_ok=True)
    # Use the existing core converter so all resource-specific conversion and
    # the proven YTD texture-name preservation stay identical to normal mode.
    local_input = work / 'file_input'
    local_input.mkdir(parents=True, exist_ok=True)
    found = []
    for p in sorted(src_dir.rglob('*'), key=lambda x: str(x).lower()):
        if p.is_file() and p.suffix.lower() in SUPPORTED:
            rel = p.relative_to(src_dir)
            dest = local_input / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
            found.append(dest)
    if not found:
        raise RuntimeError(f'No supported character resource files found in {src_dir}')
    local_archive = local_input / 'archive_input'
    local_archive.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.setdefault('PYTHONIOENCODING', 'utf-8')
    result = safe_subprocess_run([sys.executable, str(CORE), str(local_input)], cwd=str(root), env=env)
    if result.returncode != 0:
        raise RuntimeError('Character resource conversion failed')
    # The core writes converted resources into local_input/archive_input.
    for p in local_archive.rglob('*'):
        if p.is_file():
            rel = p.relative_to(local_archive)
            dst = converted / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
    if not any(converted.rglob('*')):
        raise RuntimeError('Character conversion produced no output resources')
    return converted


def characters_one_click():
    """One-click character/ped DLC workflow matching the supplied video."""
    import shutil
    from datetime import datetime
    base = ROOT / 'Characters One Click'
    source = base / 'file_input'
    finish = base / 'Finish'
    template = ROOT / 'ADD-ON FEMALE PED TEMPLATE'
    builder = ROOT / 'RPFBuilder' / 'build_rpf.py'
    archive_input = ROOT / 'RPFBuilder' / 'archive_input'
    base.mkdir(parents=True, exist_ok=True)
    source.mkdir(parents=True, exist_ok=True)
    finish.mkdir(parents=True, exist_ok=True)
    # Character Finish is reserved for the final output only: dlc.rpf.
    # Remove stale intermediate character RPFs from older runs.
    for stale in finish.iterdir():
        if stale.name.lower() != 'dlc.rpf':
            try:
                if stale.is_dir(): shutil.rmtree(stale)
                else: stale.unlink()
            except OSError: pass

    print('\n' + '=' * 62)
    print('             CHARACTER / PED ONE-CLICK DLC')
    print('=' * 62)
    print(f'Input files : {source}')
    print(f'Template    : {template}')
    print()

    if not template.is_dir():
        print('[ERROR] ADD-ON FEMALE PED TEMPLATE is missing.')
        print(f'Create/copy the template folder here:\n  {template}')
        return 1
    required = [template / 'common', template / 'ps4', template / 'ps4' / 'models' / 'cdimages', template / 'content.xml', template / 'setup2.xml']
    missing = [str(x.relative_to(template)) for x in required if not x.exists()]
    peds = template / 'common' / 'data' / 'peds.meta'
    if not peds.is_file():
        # Some templates place peds.meta one level differently; locate it safely.
        hits = list(template.rglob('peds.meta'))
        if hits:
            peds = hits[0]
        else:
            missing.append('common/data/peds.meta')
    if missing:
        print('[ERROR] Character template is incomplete:')
        for x in missing: print(f'  - {x}')
        return 1
    if not builder.is_file():
        print('[ERROR] RPFBuilder/build_rpf.py is missing.')
        return 1

    inputs = [p for p in source.iterdir() if p.is_file() and p.suffix.lower() in SUPPORTED]
    # Also accept a single extracted folder containing the character resources.
    folders = [p for p in source.iterdir() if p.is_dir() and not p.name.startswith('_')]
    if not inputs and len(folders) == 1:
        input_root = folders[0]
    else:
        input_root = source
    if not any(p.is_file() and p.suffix.lower() in SUPPORTED for p in input_root.rglob('*')):
        print('[ERROR] Put the character Y* files in Characters One Click/file_input/')
        return 1

    raw_name = input('\nEnter character file name (example: apc): ').strip()
    if not raw_name or any(c in raw_name for c in '/\\:*?"<>|'):
        print('[ERROR] Invalid character name.')
        return 1
    # IMPORTANT: character names are case-sensitive for the generated RPF and
    # template placeholders. Keep the exact case typed by the user (e.g. CR7 ->
    # CR7.rpf). Only validate the characters here; do NOT run the vehicle-name
    # sanitizer because that intentionally lowercases vehicle identifiers.
    original_name = raw_name.strip()
    import re
    if not re.fullmatch(r'[A-Za-z0-9_]+', original_name):
        print('[ERROR] Character name may contain only A-Z, a-z, 0-9 and _.')
        return 1
    print(f'[CHARACTER] Name selected: {original_name}')

    stage = base / '_build'
    shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True, exist_ok=True)
    try:
        # 1) Convert source files using the existing core converter.
        print('\n[1/7] Converting character files...')
        converted = _character_convert_sources(input_root, ROOT)
        print('[OK] Character resources converted. ✅')

        # 2) Build the character RPF under the exact entered name.
        print(f'[2/7] Building {original_name}.rpf...')
        char_source = stage / 'character_rpf'
        shutil.copytree(converted, char_source, dirs_exist_ok=True)
        ar = builder.parent / 'Archive.rpf'
        if ar.exists(): ar.unlink()
        result = safe_subprocess_run([sys.executable, str(builder), str(char_source)], cwd=str(builder.parent))
        if result.returncode != 0 or not ar.is_file() or ar.stat().st_size == 0:
            raise RuntimeError('Character RPF build failed')
        # Keep the intermediate character RPF inside the private build workspace.
        # Characters One Click/Finish must contain ONLY the final dlc.rpf.
        character_rpf = stage / f'{original_name}.rpf'
        if character_rpf.exists(): character_rpf.unlink()
        shutil.move(str(ar), str(character_rpf))
        print(f'[OK] Built: {character_rpf.name} ({character_rpf.stat().st_size:,} bytes)')

        # 3) Clone the template so the user's original template is never modified.
        print('[3/7] Preparing a fresh character DLC template...')
        dlc_stage = stage / 'dlc_template'
        shutil.copytree(template, dlc_stage, dirs_exist_ok=True)
        # 4) Copy the character RPF into the exact template path shown in the
        # supplied character template/video: ps4/models/cdimages/<name>.rpf.
        print('[4/7] Copying character RPF into ps4/models/cdimages/...')
        cdimages = dlc_stage / 'ps4' / 'models' / 'cdimages'
        cdimages.mkdir(parents=True, exist_ok=True)
        # The supplied template contains a 0-byte placeholder named
        # UR_PED_TEMPLATE.rpf. It is only a template marker and must not be
        # shipped beside the real character RPF. Remove placeholder RPFs only.
        for old in list(cdimages.glob('UR_PED_TEMPLATE.rpf')) + list(cdimages.glob('TEMPLATE.rpf')):
            try: old.unlink()
            except OSError: pass
        shutil.copy2(character_rpf, cdimages / f'{original_name}.rpf')

        # 5) Apply content.xml/setup2.xml/peds.meta placeholder substitutions.
        print('[5/7] Applying DLC / peds names...')
        for name in ('content.xml', 'setup2.xml'):
            f = dlc_stage / name
            if f.is_file():
                _replace_character_template_text(f, original_name)
        _replace_character_template_text(peds := next(dlc_stage.rglob('peds.meta')), original_name)
        print(f'[OK] dlc_{original_name.lower()} + {original_name.upper()}_GEN + models/cdimages/{original_name}.rpf applied.')

        # 6) Stage exactly the four items shown in the video into archive_input.
        print('[6/7] Staging common + ps4 + setup2.xml + content.xml...')
        shutil.rmtree(archive_input, ignore_errors=True)
        archive_input.mkdir(parents=True, exist_ok=True)
        for item in ('common', 'ps4', 'setup2.xml', 'content.xml'):
            src_item = dlc_stage / item
            if not src_item.exists():
                raise RuntimeError(f'Template staging item is missing: {item}')
            dst_item = archive_input / item
            if src_item.is_dir(): shutil.copytree(src_item, dst_item)
            else: shutil.copy2(src_item, dst_item)

        # 7) Build the final dlc.rpf. Finish contains only this final output.
        print('[7/7] Building final dlc.rpf...')
        ar = builder.parent / 'Archive.rpf'
        if ar.exists(): ar.unlink()
        result = safe_subprocess_run([sys.executable, str(builder), str(archive_input)], cwd=str(builder.parent))
        if result.returncode != 0 or not ar.is_file() or ar.stat().st_size == 0:
            raise RuntimeError('Final character dlc.rpf build failed')
        final_dlc = finish / 'dlc.rpf'
        if final_dlc.exists(): final_dlc.unlink()
        shutil.move(str(ar), str(final_dlc))
        print('\n' + '=' * 62)
        # Remove original character Y* inputs only after both builds succeeded.
        removed = 0
        for q in sorted(input_root.rglob('*'), key=lambda x: str(x), reverse=True):
            if q.is_file() and q.suffix.lower() in SUPPORTED:
                try:
                    q.unlink(); removed += 1
                except OSError as exc:
                    print(f'[WARN] Could not delete original {q.name}: {exc}')
        print(f'[CLEANUP] Removed {removed} original Y*/O* source file(s) after successful build.')
        print(f'[CHARACTER DLC] COMPLETE ✅  {final_dlc}')
        print('[CHARACTER RPF] Intermediate build kept inside private workspace only.')
        print('=' * 62)
        return 0
    except KeyboardInterrupt:
        print('\n[STOPPED] Character workflow interrupted safely.')
        return 130
    except Exception as exc:
        print(f'[CHARACTER DLC] ERROR: {type(exc).__name__}: {exc}')
        return 1
    finally:
        # Do not leave build/archive_input debris that could contaminate the next build.
        shutil.rmtree(stage, ignore_errors=True)
        shutil.rmtree(archive_input, ignore_errors=True)
        shutil.rmtree(ROOT / 'Characters One Click' / '_work', ignore_errors=True)

def _fivem_extract_rpfs_with_manifest(root, extractor):
    """Extract every nested RPF in a FiveM map package and remember the exact
    container filename so it can be rebuilt after Y* -> O* conversion."""
    import shutil
    root = Path(root)
    extractor = Path(extractor)
    jobs = []
    seen = set()
    while True:
        found_new = False
        rpfs = sorted((p for p in root.rglob('*.rpf') if p.is_file()), key=lambda p: (len(p.parts), str(p).lower()))
        for rpf in rpfs:
            key = str(rpf.resolve()).lower()
            if key in seen:
                continue
            seen.add(key)
            out_dir = rpf.with_suffix('')
            print(f'[FIVEM MAP DLC] Extracting nested RPF: {rpf.relative_to(root)}')
            ex = safe_subprocess_run([sys.executable, str(extractor), str(rpf), str(out_dir)], cwd=str(extractor.parent), input='A\n', text=True, env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})
            if ex.returncode != 0 or not out_dir.is_dir():
                raise RuntimeError(f'Could not extract FiveM map RPF: {rpf.name}')
            rpf.unlink()
            jobs.append((out_dir, rpf.name))
            found_new = True
        if not found_new:
            break
    return jobs


def _write_fivem_map_dlc_descriptor(addon_root, dlc_name, map_rpf_rel):
    from xml.sax.saxutils import escape
    addon_root = Path(addon_root); dlc_name = str(dlc_name)
    rel = str(map_rpf_rel).replace('\\', '/')
    common = addon_root / 'common' / 'data'; common.mkdir(parents=True, exist_ok=True)
    (common / 'dlctext.meta').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<CExtraTextMetaFile>\n  <hasGlobalTextFile value="true"/>\n  <hasAdditionalText value="false"/>\n  <isTitleUpdate value="false"/>\n</CExtraTextMetaFile>\n', encoding='utf-8')
    uri = f'dlc_{dlc_name}:/{rel}'
    content = ['<?xml version="1.0" encoding="UTF-8"?>','<CDataFileMgr__ContentsOfDataFileXml>','  <disabledFiles />','  <includedXmlFiles />','  <includedDataFiles />','  <dataFiles>','    <Item>',f'      <filename>dlc_{escape(dlc_name)}:/common/data/dlctext.meta</filename>','      <fileType>TEXTFILE_METAFILE</fileType>','      <overlay value="false" />','      <disabled value="true" />','      <persistent value="true" />','    </Item>','    <Item>',f'      <filename>{escape(uri)}</filename>','      <fileType>RPF_FILE</fileType>','      <overlay value="false" />','      <disabled value="true" />','      <persistent value="true" />','    </Item>','  </dataFiles>','  <contentChangeSets>','    <Item>',f'      <changeSetName>{escape(dlc_name.upper())}_AUTOGEN</changeSetName>','      <filesToDisable />','      <filesToEnable>',f'        <Item>dlc_{escape(dlc_name)}:/common/data/dlctext.meta</Item>',f'        <Item>{escape(uri)}</Item>','      </filesToEnable>','      <txdToLoad />','      <txdToUnload />','      <residentResources />','      <unregisterResources />','    </Item>','  </contentChangeSets>','  <patchFiles />','</CDataFileMgr__ContentsOfDataFileXml>','']
    (addon_root / 'content.xml').write_text('\n'.join(content), encoding='utf-8')
    setup = f'''<?xml version="1.0" encoding="UTF-8"?>
<SSetupData>
  <deviceName>dlc_{escape(dlc_name)}</deviceName>
  <datFile>content.xml</datFile>
  <nameHash>{escape(dlc_name)}</nameHash>
  <contentChangeSetGroups><Item><NameHash>GROUP_STARTUP</NameHash><ContentChangeSets><Item>{escape(dlc_name.upper())}_AUTOGEN</Item></ContentChangeSets></Item></contentChangeSetGroups>
  <type>EXTRACONTENT_LEVEL_PACK</type>
  <order value="2" />
  <minorOrder value="0" />
  <isLevelPack>true</isLevelPack>
</SSetupData>
'''
    (addon_root / 'setup2.xml').write_text(setup, encoding='utf-8')


def _fivem_map_one_click_impl():
    """FiveM map -> DLC workflow matching the supplied DLC reference layout.

    Input:
        FiveM Maps One Click/input/

    The selected map name is used to create:
        ps4/levels/gta5/<name>/<name>.rpf
        ps4/levels/gta5/<name>_metadata/<name>_metadata.rpf

    Only .ymap/.ytyp/.ymf resources go into the metadata RPF. All other
    supported GTA Y* resources go into the main map RPF. Resources are then
    converted Y* -> O*, nested RPFs are rebuilt, content.xml/setup2.xml are
    generated, and the final builder Archive.rpf is renamed to dlc.rpf.

    Existing project features are left untouched; this replaces only the old
    FiveM Map -> DLC implementation behind menu option 7.
    """
    import shutil, zipfile, re

    base = ROOT / 'FiveM Maps One Click'
    input_dir = base / 'input'
    finish = base / 'Finish'
    extractor = ROOT / 'RPFBuilder' / 'extract_rpf.py'
    builder = ROOT / 'RPFBuilder' / 'build_rpf.py'

    input_dir.mkdir(parents=True, exist_ok=True)
    finish.mkdir(parents=True, exist_ok=True)

    # Keep the user's source untouched. Accept a single folder/package/file.
    inputs = [p for p in input_dir.iterdir() if not p.name.startswith('.') and p.name.lower() != 'finish']
    if len(inputs) != 1:
        print(f'[FIVEM MAP DLC] Put ONE FiveM map file/folder in: {input_dir}')
        print(f'[FIVEM MAP DLC] Found: {len(inputs)}')
        return 1

    source = inputs[0]
    raw = input('\n[FIVEM MAP DLC] Enter map/DLC name: ').strip()
    if not re.fullmatch(r'[A-Za-z0-9_]+', raw):
        print('[FIVEM MAP DLC] Invalid name. Use A-Z, a-z, 0-9 and _.')
        return 1
    dlc_name = raw

    work = base / '_work_fivem_dlc'
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)

    try:
        # ---------------------------------------------------------------
        # 1) Unpack/copy the FiveM source into a private working tree.
        # ---------------------------------------------------------------
        src_root = work / 'source'
        src_root.mkdir(parents=True, exist_ok=True)
        if source.is_dir():
            shutil.copytree(source, src_root / source.name)
            source_tree = src_root / source.name
        elif source.suffix.lower() == '.zip':
            with zipfile.ZipFile(source) as zf:
                zf.extractall(src_root)
            dirs = [p for p in src_root.iterdir() if p.is_dir()]
            source_tree = dirs[0] if len(dirs) == 1 else src_root
        elif source.suffix.lower() == '.rar':
            # Reuse the project's existing package extractor for RAR support.
            source_tree = Path(_extract_vehicle_package(source, src_root))
        else:
            # A single resource file is also accepted.
            target = src_root / source.name
            shutil.copy2(source, target)
            source_tree = src_root

        print('\n' + '=' * 72)
        print(f'[FIVEM MAP DLC] Source: {source.name}')
        print(f'[FIVEM MAP DLC] Name:   {dlc_name}')
        print(f'[FIVEM MAP DLC] Input:  {input_dir}')
        print('=' * 72)

        # ---------------------------------------------------------------
        # 2) Extract nested RPFs first so files inside them are included.
        # ---------------------------------------------------------------
        print('[1/7] Extracting nested RPF containers...')
        rpf_jobs = _fivem_extract_rpfs_with_manifest(source_tree, extractor)

        all_supported = [
            p for p in source_tree.rglob('*')
            if p.is_file() and p.suffix.lower() in SUPPORTED
        ]
        if not all_supported:
            raise RuntimeError('No supported GTA Y*/O* resources were found in the FiveM map.')
        print(f'[FIVEM MAP DLC] Found {len(all_supported)} supported resource(s).')

        # ---------------------------------------------------------------
        # 3) Convert every supported Y* resource to O*.
        # ---------------------------------------------------------------
        print('[2/7] Converting Y* resources to O*...')
        converted_count, failed = _convert_extracted_tree(
            source_tree, CORE, ROOT, delete_y_all=True
        )
        if converted_count <= 0:
            raise RuntimeError('No resources were converted from Y* to O*.')
        if failed:
            print(f'[WARN] {len(failed)} resource(s) were quarantined.')

        # Remove only GTA data folders under x64/ps4, matching the existing
        # project behaviour, before packing the map.
        _remove_ps4_data_dirs(source_tree)

        # ---------------------------------------------------------------
        # 3b) Separate metadata BEFORE rebuilding nested RPFs. This guarantees
        # that YMAP/YTYP/YMF resources never get trapped inside a rebuilt map
        # RPF and that the dedicated *_metadata.rpf contains only those three
        # resource types (converted to OMAP/OTYP/OMF).
        # ---------------------------------------------------------------
        print('[3/7] Separating YMAP/YTYP/YMF metadata...')
        pack_root = work / 'pack'
        map_stage = work / 'map_stage'
        metadata_stage = work / 'metadata_stage'
        map_stage.mkdir(parents=True, exist_ok=True)
        metadata_stage.mkdir(parents=True, exist_ok=True)
        metadata_exts = {'.omap', '.otyp', '.omf'}
        metadata_count = 0
        for p in sorted(source_tree.rglob('*'), key=lambda x: (len(x.parts), str(x).lower())):
            if not p.is_file() or p.suffix.lower() not in metadata_exts:
                continue
            rel = p.relative_to(source_tree)
            dst = metadata_stage / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(p), str(dst))
            metadata_count += 1
        if metadata_count == 0:
            print('[FIVEM MAP DLC] No YMAP/YTYP/YMF files found; continuing without metadata RPF.')
        else:
            print(f'[FIVEM MAP DLC] Metadata resources separated: {metadata_count}')

        # ---------------------------------------------------------------
        # 4) Rebuild any original nested RPFs after metadata separation.
        # ---------------------------------------------------------------
        print('[4/7] Rebuilding converted nested RPF containers...')
        for folder, old_name in sorted(rpf_jobs, key=lambda x: len(x[0].parts), reverse=True):
            if not folder.is_dir():
                continue
            archive = builder.parent / 'Archive.rpf'
            if archive.exists():
                archive.unlink()
            result = safe_subprocess_run(
                [sys.executable, str(builder), str(folder)],
                cwd=str(builder.parent),
                env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
            )
            if result.returncode != 0 or not archive.is_file() or archive.stat().st_size == 0:
                raise RuntimeError(f'Could not rebuild map RPF: {old_name}')
            out = folder.parent / old_name
            if out.exists():
                out.unlink()
            shutil.move(str(archive), str(out))
            shutil.rmtree(folder)

        # ---------------------------------------------------------------
        # 5) Distribute resources exactly like the supplied reference:
        #       x64/levels/gta5/<name>/<name>.rpf
        #       x64/levels/gta5/<name>_metadata/<name>_metadata.rpf
        # Metadata receives ONLY YMAP/YTYP/YMF equivalents (OMAP/OTYP/OMF).
        # Everything else belongs to the main map RPF.
        # ---------------------------------------------------------------
        print('[4/7] Distributing files into map + metadata folders...')
        map_folder = pack_root / 'ps4' / 'levels' / 'gta5' / dlc_name
        metadata_folder = pack_root / 'ps4' / 'levels' / 'gta5' / f'{dlc_name}_metadata'
        map_folder.mkdir(parents=True, exist_ok=True)
        if metadata_count > 0:
            metadata_folder.mkdir(parents=True, exist_ok=True)

        # Never copy source Y* files back into the final tree.
        copied_map = 0
        for p in source_tree.rglob('*'):
            if not p.is_file():
                continue
            if p.suffix.lower().startswith('.y') and p.suffix.lower() in SUPPORTED:
                raise RuntimeError(f'Unconverted Y* resource reached packaging: {p.name}')
            rel = p.relative_to(source_tree)
            dst = map_folder / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
            copied_map += 1

        # Metadata stage is already guaranteed to contain ONLY OMAP/OTYP/OMF.
        copied_metadata = 0
        if metadata_count > 0:
            for p in metadata_stage.rglob('*'):
                if not p.is_file():
                    continue
                if p.suffix.lower() not in metadata_exts:
                    raise RuntimeError(f'Non-metadata resource reached metadata.rpf: {p.name}')
                rel = p.relative_to(metadata_stage)
                dst = metadata_folder / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dst)
                copied_metadata += 1

        # The reference keeps metadata files directly inside the metadata
        # directory and the main map resources inside the map directory. The
        # source-relative structure is retained so multiple FiveM stream/map
        # folders do not collide.
        if copied_metadata == 0:
            print('[WARN] No .ymap/.ytyp/.ymf resources were found for metadata.')
        print(f'[FIVEM MAP DLC] Main map files: {copied_map}')
        print(f'[FIVEM MAP DLC] Metadata files: {copied_metadata}')

        # ---------------------------------------------------------------
        # 6) Build the two RPFs, then generate DLC descriptors.
        # ---------------------------------------------------------------
        print('[5/7] Building map RPF + metadata RPF...')
        archive = builder.parent / 'Archive.rpf'

        # Main map RPF
        if archive.exists():
            archive.unlink()
        result = safe_subprocess_run(
            [sys.executable, str(builder), str(map_folder)],
            cwd=str(builder.parent),
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        )
        if result.returncode != 0 or not archive.is_file() or archive.stat().st_size == 0:
            raise RuntimeError('Main map RPF build failed.')
        map_rpf = map_folder.parent / f'{dlc_name}.rpf'
        if map_rpf.exists():
            map_rpf.unlink()
        shutil.move(str(archive), str(map_rpf))
        shutil.rmtree(map_folder, ignore_errors=True)

        # Generate descriptors and content.xml for the main map RPF.
        _write_fivem_map_dlc_descriptor(
            pack_root,
            dlc_name,
            f'%PLATFORM%/levels/gta5/{dlc_name}/{dlc_name}.rpf'
        )

        # Add the metadata RPF only when YMAP/YTYP/YMF resources actually exist.
        if metadata_count > 0:
            if archive.exists():
                archive.unlink()
            result = safe_subprocess_run(
                [sys.executable, str(builder), str(metadata_folder)],
                cwd=str(builder.parent),
                env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
            )
            if result.returncode != 0 or not archive.is_file() or archive.stat().st_size == 0:
                raise RuntimeError('Metadata RPF build failed.')
            metadata_rpf = metadata_folder.parent / f'{dlc_name}_metadata.rpf'
            if metadata_rpf.exists():
                metadata_rpf.unlink()
            shutil.move(str(archive), str(metadata_rpf))
            shutil.rmtree(metadata_folder, ignore_errors=True)

            content_path = pack_root / 'content.xml'
            content = content_path.read_text(encoding='utf-8')
            main_uri = f'dlc_{dlc_name}:/%PLATFORM%/levels/gta5/{dlc_name}/{dlc_name}.rpf'
            meta_uri = f'dlc_{dlc_name}:/%PLATFORM%/levels/gta5/{dlc_name}_metadata/{dlc_name}_metadata.rpf'
            marker = '  <dataFiles>\n'
            entries = (
                '  <dataFiles>\n'
                '    <Item>\n'
                f'      <filename>{meta_uri}</filename>\n'
                '      <fileType>RPF_FILE</fileType>\n'
                '      <overlay value="false" />\n'
                '      <disabled value="false" />\n'
                '      <persistent value="false" />\n'
                '    </Item>\n'
                '    <Item>\n'
                f'      <filename>{main_uri}</filename>\n'
                '      <fileType>RPF_FILE</fileType>\n'
                '      <overlay value="false" />\n'
                '      <disabled value="false" />\n'
                '      <persistent value="false" />\n'
                '    </Item>\n'
            )
            data_start = content.find(marker)
            data_end = content.find('  </dataFiles>', data_start)
            if data_start < 0 or data_end < 0:
                raise RuntimeError('Generated content.xml has an unexpected format.')
            content = content[:data_start] + entries + content[data_end:]
            content_path.write_text(content, encoding='utf-8')

        # ---------------------------------------------------------------
        # 7) Build final archive.rpf and rename it to dlc.rpf.
        # ---------------------------------------------------------------
        print('[6/7] Building final DLC archive...')
        if archive.exists():
            archive.unlink()
        result = safe_subprocess_run(
            [sys.executable, str(builder), str(pack_root)],
            cwd=str(builder.parent),
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
        )
        if result.returncode != 0 or not archive.is_file() or archive.stat().st_size == 0:
            raise RuntimeError('Final Archive.rpf build failed.')

        print('[7/7] Renaming Archive.rpf -> dlc.rpf...')
        final = finish / 'dlc.rpf'
        temp_final = finish / '.dlc.rpf.building'
        if temp_final.exists():
            temp_final.unlink()
        shutil.move(str(archive), str(temp_final))
        if final.exists():
            final.unlink()
        temp_final.replace(final)

        if not final.is_file() or final.stat().st_size == 0:
            raise RuntimeError('Final dlc.rpf is missing or empty.')

        print('\n' + '=' * 72)
        print('[FIVEM MAP DLC] COMPLETE ✅')
        print(f'[SUCCESS] Final file: {final}')
        print(f'[SUCCESS] Size: {final.stat().st_size:,} bytes')
        print('[INFO] Original input was preserved.')
        print('=' * 72)
        return 0

    except KeyboardInterrupt:
        print('\n[STOPPED] FiveM Map workflow interrupted safely.')
        return 130
    except Exception as exc:
        print(f'[FIVEM MAP DLC] ERROR: {type(exc).__name__}: {exc}')
        print('[SAFE STOP] Original input was preserved.')
        return 1
    finally:
        shutil.rmtree(work, ignore_errors=True)


def fivem_map_one_click():
    try: return _fivem_map_one_click_impl()
    except Exception as exc: print(f'[FIVEM MAP DLC] ERROR: {type(exc).__name__}: {exc}'); return 1


def show_main_menu():
    """Render the main launcher in the supplied reference style.
    Only the title branding changes; menu options remain unchanged.
    """
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
    except Exception:
        pass

    C = '\033[94m'   # blue
    P = '\033[95m'   # magenta
    Y = '\033[93m'   # yellow
    R = '\033[91m'   # red
    RESET = '\033[0m'
    width = 78

    top = C + '╔' + '═' * width + '╗' + RESET
    mid = C + '╠' + '═' * width + '╣' + RESET
    bot = C + '╚' + '═' * width + '╝' + RESET

    def row(text='', color='\033[97m', align='center'):
        text = str(text)
        if len(text) > width:
            text = text[:width]
        if align == 'left':
            left, right = 2, width - len(text) - 2
        else:
            left = max(0, (width - len(text)) // 2)
            right = width - len(text) - left
        return C + '║' + RESET + (' ' * left) + color + text + RESET + (' ' * max(0, right)) + C + '║' + RESET

    # Main launcher follows the supplied reference image:
    # cyan frame, yellow text, then the yellow status line below the frame.
    print(top)
    print(row('⭐   🌐   G   T   A   V   ×   7N-RL IRAQ TOOL   🌐   ⭐', Y))
    print(row())
    print(row('7N-RL IRAQ', Y))
    print(row('ULTIMATE PS4 MODEL CONVERSION ENGINE', Y))
    print(row())
    print(mid)
    print(row('🔥  ULTIMATE PS4 MODEL CONVERSION ENGINE  🔥', Y))
    print(row())
    print(bot)
    print()
    print(P + '━' * 78 + RESET)
    status = '🚀 STATUS:  ENGINE ONLINE  •  PS4 / PC PIPELINE'
    left = max(0, (78 - len(status)) // 2)
    print(P + ' ' * left + status + RESET)
    print(P + '━' * 78 + RESET)


def _main_impl():
    show_main_menu()
    G = '\033[92m'
    R = '\033[91m'
    RESET = '\033[0m'
    print("\n" + G + "[1] Normal file conversion" + RESET)
    print(G + "[2] DLC.RPF One Click" + RESET)
    print(G + "[3] DLC.RPF Map One Click" + RESET)
    print(G + "[4] Vehicles --> DLC.RPF" + RESET)
    print(G + "[5] 5 Vehicles --> One DLC.RPF" + RESET)
    print(G + "[6] Characters --> DLC.RPF One Click" + RESET)
    print(G + "[7] FiveM Map --> DLC.RPF" + RESET)
    print(R + "[8] Exit" + RESET)
    mode = input("\nChoose an option [1-8]: ").strip() or "1"
    if mode == "2":
        return dlc_rpf_one_click()
    if mode == "3":
        return map_dlc_one_click()
    if mode == "4":
        return vehicles_to_dlc_rpf()
    if mode == "5":
        return five_vehicles_one_dlc()
    if mode == "6":
        return characters_one_click()
    if mode == "7":
        return fivem_map_one_click()
    if mode == "8":
        print("\n[EXIT] Goodbye 👋")
        return 0
    if mode != "1":
        print("[ERROR] Invalid option.")
        return 1
    if not CORE.is_file():
        print("[ERROR] core_converter.py is missing.")
        return 2

    files = find_sources()
    if not files:
        print("[ERROR] No supported files found in file_input/")
        print("Put .yft/.ydr/.ydd/.ytd and other supported GTA V files there, then run again.")
        return 1

    print(f"Found {len(files)} file(s). Starting automatic conversion...\n")

    # Pass the directory to the proven all-format core. Its own output directory
    # is created beside the supplied input directory, which is exactly file_input/archive_input.
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    try:
        result = safe_subprocess_run(
            [sys.executable, str(CORE), str(INPUT)],
            cwd=str(ROOT),
            env=env,
        )
    except KeyboardInterrupt:
        print("\n[STOPPED] Conversion interrupted.")
        return 130
    except Exception as exc:
        print(f"[ERROR] Could not start converter: {exc}")
        return 2

    print("\n" + "=" * 62)
    print("\033[92mFinished. Check: file_input/archive_input/\033[0m")
    print("=" * 62)
    if result.returncode == 0:
        ask_delete_old_files()
        build_rpf_option()
    return result.returncode


def main():
    try:
        return _main_impl()
    except KeyboardInterrupt:
        print("\n[STOPPED] Program interrupted safely.")
        return 130
    except Exception as exc:
        print(f"\n[ERROR] Unexpected program error: {type(exc).__name__}: {exc}")
        print("[SAFE STOP] The program closed without continuing to the Build step.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

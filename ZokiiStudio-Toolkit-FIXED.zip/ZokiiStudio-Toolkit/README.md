# Zokii Studio Toolkit (CI bundle)

## GitHub setup from iPad

1. Upload this ZIP to the **root** of the private repository with the exact name `ZokiiStudio-Toolkit.zip`.
2. Upload the standalone `zokii-studio-fixed.yml` to `.github/workflows/zokii-studio.yml`.
3. Put the mod under `input/` in the repository. For the supplied vehicle layout, keep the `buccaneer2/stream/` folder structure.
4. Open **Actions → Zokii Studio - GTA V Toolkit → Run workflow**.

The workflow extracts the toolkit ZIP automatically. Do not put the ZIP inside `.github/workflows`.

## Available modes

- `audit`: syntax and symbol audit of bundled Python scripts.
- `convert_pc_to_ps4`: runs the bundled 7N converter on supported GTA resource files.
- `vehicle_to_dlc`: packages one replacement vehicle as a PS4 add-on `dlc.rpf`, converts resources, rebuilds nested RPFs, and changes the platform folder from `x64` to `ps4`. The spawn name is an input.
- `convert_and_build_rpf`: converts resources and attempts to package the converted output into `Archive.rpf`.
- `extract_ytd`: extracts textures from YTD files to DDS.
- `extract_rpf`: extracts RPF archives, automatically choosing all nested RPFs.
- `build_rpf`: attempts to build an RPF from the contents of `input/`.

## Fixes included in this bundle

- Installs the archive utility for every non-audit mode, not only build mode.
- Installs Wine + Xvfb for conversion/build modes, because the YTD-to-OTD path invokes the bundled Windows `ragebuilder.exe`.
- Initializes an isolated 64-bit Wine prefix.
- Avoids interactive waiting in CI. YTDs whose unpacked texture folder exceeds 130 MB are safely skipped by default.
- Fixes 16-bit uncompressed YTD texture byte sizing and DDS channel masks (A1R5G5B5 / A4R4G4B4).
- Detects duplicate resource basenames before staging, preventing silent overwrites.
- Adds a per-resource conversion report and preserves extracted/failed files in the artifact.

## Validation status

The Python sources pass syntax compilation. The workflow YAML parses successfully. The previous audit artifact listed the input files `buccaneer2.yft`, `buccaneer2_hi.yft`, and `buccaneer2.ytd`, but it contained only their paths, not the binary file contents. Therefore the actual model/texture conversion and final PS4 game compatibility still need a real run on those files. The Windows `ragebuilder.exe` is invoked through Wine on the GitHub runner; its runtime behavior cannot be proven by a syntax audit alone.

CHARACTERS ONE CLICK

Put the source character Y* resources in:
  file_input/

Run 7N-RL OneIraq and choose:
  [6] Characters --> DLC.RPF One Click

The workflow uses the integrated ADD-ON FEMALE PED TEMPLATE exactly as supplied.
It converts the character resources, asks for the character name, builds <name>.rpf,
and places it at:
  ps4/models/cdimages/<name>.rpf

It then updates:
  dlc_TEMPLATE     -> dlc_<name in lowercase>
  TEMPLATE_GEN     -> <name in uppercase>_GEN
  TEMPLATE.rpf     -> <name>.rpf (typed case preserved)
  peds.meta TEMPLATE -> typed character name
  setup2.xml TEMPLATE -> typed character name

Finally it stages common + ps4 + setup2.xml + content.xml into
RPFBuilder/archive_input and builds the final Finish/dlc.rpf.

The 0-byte UR_PED_TEMPLATE.rpf shipped in the source template is only a
placeholder and is removed from the staged DLC before the real character RPF
is copied in.

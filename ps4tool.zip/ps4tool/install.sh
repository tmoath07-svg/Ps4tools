#!/bin/bash
# تثبيت Wine مرة واحدة فقط (يشغّل ragebuilder.exe على لينكس)
set -e
echo "[1/2] تحديث الحزم..."
sudo apt-get update -y
echo "[2/2] تثبيت Wine (ياخذ كم دقيقة)..."
sudo apt-get install -y wine wine64 xvfb python3
echo "تم التثبيت. الحين شغّل:  bash run.sh"

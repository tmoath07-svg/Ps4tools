#!/usr/bin/env python3
"""
Vans Model Converter for GTA 5 PS4 v1.5
"""

import sys
import os
import glob
import re
import struct
import zlib
import shutil
import time

def _supports_ansi():
    if os.environ.get('NO_COLOR'):
        return False
    if os.environ.get('TERM') == 'dumb':
        return False
    if sys.platform == 'win32':
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.GetStdHandle(-11)
            mode = ctypes.c_ulong(0)
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                kernel32.SetConsoleMode(handle, mode.value | 0x0004)
            return True
        except Exception:
            return False
    try:
        return sys.stdout.isatty()
    except Exception:
        return False

ANSI  = _supports_ansi()
RESET = '\033[0m' if ANSI else ''

_PALETTE = [
    (255,  30,  30),
    (255, 140,   0),
    (255, 230,   0),
    ( 30, 220,  30),
    (  0, 180, 255),
    ( 80,  80, 255),
    (180,   0, 255),
    (255,   0, 180),
]

_CYAN = (0, 220, 220)

def _col(r, g, b, text):
    if not ANSI:
        return text
    return '\033[38;2;{};{};{}m{}{}'.format(r, g, b, text, RESET)

def cprint(text):
    print(_col(_CYAN[0], _CYAN[1], _CYAN[2], text))

def vprint(text, slot=0):
    if not ANSI:
        print(text)
        return
    r, g, b = _PALETTE[slot % len(_PALETTE)]
    print(_col(r, g, b, text))

def rdiv(char='=', width=56, slot=0):
    vprint(char * width, slot)

VANS_ART = [
    "",
    "██╗   ██╗ █████╗ ███╗  ██╗███████╗",
    "██║   ██║██╔══██╗████╗ ██║██╔════╝",
    "██║   ██║███████║██╔██╗██║███████╗ ",
    "╚██╗ ██╔╝██╔══██║██║╚████║╚════██║",
    " ╚████╔╝ ██║  ██║██║ ╚███║███████║",
    "  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚══╝╚══════╝",
    "",
]

def print_header():
    for line in VANS_ART:
        cprint(line)

GTAV1_LE         = struct.pack('<Q', 0x7755555555996996)
PS4_LE           = struct.pack('<Q', 8598872888530528406)
RSC7_MAGIC       = b'RSC7'
RSC7_HEADER_SIZE = 16

_RAGE_TEX_NAME_PTR_OFFSET = 0x18
_RAGE_TEX_WIDTH_OFFSET    = 0x40
_RAGE_TEX_HEIGHT_OFFSET   = 0x42
_RAGE_TEX_FOURCC_OFFSET   = 0x48
_RAGE_TEX_MIPS_OFFSET     = 0x4D
_RAGE_TEX_STRUCT_MIN_SIZE = 0x4E

_D3DFMT = {
    b'DXT1':              'D3DFMT_DXT1 (BC1)',
    b'DXT3':              'D3DFMT_DXT3 (BC2)',
    b'DXT5':              'D3DFMT_DXT5 (BC3)',
    b'ATI2':              'D3DFMT_ATI2 (BC5)',
    b'ATI1':              'D3DFMT_ATI1 (BC4)',
    b'BC4U':              'D3DFMT_BC4U',
    b'BC4S':              'D3DFMT_BC4S',
    b'BC5U':              'D3DFMT_BC5U',
    b'BC5S':              'D3DFMT_BC5S',
    b'DX10':              'D3DFMT_DX10',
    b'\x1c\x00\x00\x00': 'D3DFMT_A8',
    b'\x15\x00\x00\x00': 'D3DFMT_A8R8G8B8',
    b'\x16\x00\x00\x00': 'D3DFMT_X8R8G8B8',
    b'\x32\x00\x00\x00': 'D3DFMT_A8B8G8R8',
    b'\x28\x00\x00\x00': 'D3DFMT_L8',
}

_TEX_NAME_RE = re.compile(rb'^[a-zA-Z][a-zA-Z0-9_]+$')

PC_TO_PS4 = {
    '.yft':  {'out': '.oft',  'patch': True,  'desc': 'Fragment model'},
    '.ydr':  {'out': '.odr',  'patch': True,  'desc': 'Drawable model'},
    '.ydd':  {'out': '.odd',  'patch': True,  'desc': 'Drawable dictionary'},
    '.ypt':  {'out': '.opt',  'patch': True,  'desc': 'Particle effect'},
    '.ybn':  {'out': '.obn',  'patch': True,  'desc': 'Collision bounds'},
    '.ybd':  {'out': '.obd',  'patch': True,  'desc': 'Bounds dictionary'},
    '.yld':  {'out': '.old',  'patch': True,  'desc': 'Cloth data'},
    '.yed':  {'out': '.oed',  'patch': True,  'desc': 'Expression dictionary'},
    '.yfd':  {'out': '.ofd',  'patch': True,  'desc': 'Frame filter dictionary'},
    '.ynd':  {'out': '.ond',  'patch': True,  'desc': 'Path nodes'},
    '.ynv':  {'out': '.onv',  'patch': True,  'desc': 'Navigation mesh'},
    '.yvr':  {'out': '.ovr',  'patch': True,  'desc': 'Vehicle records'},
    '.ywr':  {'out': '.owr',  'patch': True,  'desc': 'Waypoint recordings'},
    '.ypdb': {'out': '.opdb', 'patch': True,  'desc': 'Pose matching database'},
    '.ycd':  {'out': '.ocd',  'patch': False, 'desc': 'Animation clips'},
    '.ymap': {'out': '.omap', 'patch': False, 'desc': 'Map placement'},
    '.ytyp': {'out': '.otyp', 'patch': False, 'desc': 'Archetype definition'},
    '.ymt':  {'out': '.omt',  'patch': False, 'desc': 'Metadata file'},
    '.ymf':  {'out': '.omf',  'patch': False, 'desc': 'Manifest file'},
}

PS4_TO_PC          = {v['out']: {'out': k, 'patch': v['patch'], 'desc': v['desc']}
                      for k, v in PC_TO_PS4.items()}
ALL_EXTS           = set(PC_TO_PS4.keys()) | set(PS4_TO_PC.keys())
EMBEDDED_TEX_EXTS  = {ext for ext, cfg in PC_TO_PS4.items() if cfg['patch']}

SLOT_FILE  = 4
SLOT_SAVED = 2
SLOT_FIX   = 1
SLOT_OK    = 3
SLOT_WARN  = 0
SLOT_ERR   = 0
SLOT_SKIP  = 7

DIVIDER_WIDTH    = 56
ZLIB_LEVEL_MAX   = 9
ZLIB_RAW_DEFLATE = -15


def detect_embedded_textures(decompressed):
    textures   = []
    seen_bases = set()
    seen_names = set()
    n          = len(decompressed)
    limit      = n - 4  # matches the original loop's exclusive upper bound
    if limit <= 0:
        return textures

    # (ptr_val >> 24) == 0x50  <=>  the most-significant (last) byte of the
    # little-endian u32 at offset i equals 0x50, i.e. decompressed[i+3].
    # This runs on *every* embedded-texture-capable file during PC->PS4
    # conversion regardless of whether it actually has any embedded
    # textures, so it was the single biggest per-file cost in the whole
    # conversion pipeline — a Python-level loop doing a struct.unpack_from()
    # call on every 4-byte-aligned offset in a multi-MB buffer. Pulling out
    # just the fixed-alignment marker byte and scanning it with bytes.find()
    # (a fast C-level memchr) turns that into a handful of iterations over
    # the sparse actual candidate matches instead.
    sample = decompressed[3::4]   # sample[j] == decompressed[4*j + 3]
    search_from = 0
    while True:
        j = sample.find(b'\x50', search_from)
        if j == -1:
            break
        search_from = j + 1
        i = j * 4
        if i >= limit:
            continue

        ptr_val = struct.unpack_from('<I', decompressed, i)[0]

        struct_base = i - _RAGE_TEX_NAME_PTR_OFFSET
        if struct_base < 0 or struct_base in seen_bases:
            continue
        if struct_base + _RAGE_TEX_STRUCT_MIN_SIZE >= n:
            continue

        if struct.unpack_from('<I', decompressed, i + 4)[0] != 0:
            continue

        name_offset = ptr_val & 0x00FFFFFF
        if name_offset == 0 or name_offset >= n:
            continue
        name_end = decompressed.find(b'\x00', name_offset)
        if name_end == -1 or not (3 <= name_end - name_offset <= 64):
            continue
        name_bytes = decompressed[name_offset:name_end]
        if not _TEX_NAME_RE.match(name_bytes):
            continue

        fourcc = bytes(decompressed[struct_base + _RAGE_TEX_FOURCC_OFFSET:
                                    struct_base + _RAGE_TEX_FOURCC_OFFSET + 4])
        if fourcc not in _D3DFMT:
            continue

        width  = struct.unpack_from('<H', decompressed, struct_base + _RAGE_TEX_WIDTH_OFFSET)[0]
        height = struct.unpack_from('<H', decompressed, struct_base + _RAGE_TEX_HEIGHT_OFFSET)[0]
        mips   = decompressed[struct_base + _RAGE_TEX_MIPS_OFFSET]

        if not (1 <= width <= 8192 and 1 <= height <= 8192 and 1 <= mips <= 16):
            continue

        name = name_bytes.decode('ascii')
        if name in seen_names:
            continue

        seen_bases.add(struct_base)
        seen_names.add(name)
        textures.append({
            'name':   name,
            'width':  width,
            'height': height,
            'format': _D3DFMT[fourcc],
            'mips':   mips,
        })

    return textures


def decompress_rsc7(data):
    header = data[:RSC7_HEADER_SIZE]
    try:
        decompressed = zlib.decompress(data[RSC7_HEADER_SIZE:], ZLIB_RAW_DEFLATE)
    except zlib.error as e:
        raise ValueError("Decompression failed: {}".format(e))
    return header, decompressed


def recompress_rsc7(header, decompressed):
    return header + zlib.compress(decompressed, level=ZLIB_LEVEL_MAX)[2:-4]


def process_file(filepath):
    basename = os.path.basename(filepath)
    ext      = os.path.splitext(filepath)[1].lower()

    if ext in PC_TO_PS4:
        config    = PC_TO_PS4[ext]
        direction = 'pc2ps4'
    elif ext in PS4_TO_PC:
        config    = PS4_TO_PC[ext]
        direction = 'ps42pc'
    else:
        vprint("  [SKIP] Unsupported: {}".format(basename), SLOT_SKIP)
        return False

    out_ext  = config['out']
    do_patch = config['patch']
    desc     = config['desc']
    out_path = os.path.splitext(filepath)[0] + out_ext

    dir_label = 'PC->PS4' if direction == 'pc2ps4' else 'PS4->PC'
    vprint("  [{}][{}] {}".format(desc, dir_label, basename), SLOT_FILE)

    if not do_patch:
        try:
            shutil.copy2(filepath, out_path)
            vprint("    [SAVED] {}".format(os.path.basename(out_path)), SLOT_SAVED)
            return True
        except Exception as e:
            vprint("    [ERROR] {}".format(e), SLOT_ERR)
            return False

    try:
        with open(filepath, 'rb') as f:
            data = f.read()
    except Exception as e:
        vprint("    [ERROR] Cannot read: {}".format(e), SLOT_ERR)
        return False

    if data[:4] != RSC7_MAGIC:
        vprint("    [WARN] Not RSC7 - renaming only", SLOT_WARN)
        try:
            shutil.copy2(filepath, out_path)
            vprint("    [SAVED] {}".format(os.path.basename(out_path)), SLOT_SAVED)
            return True
        except Exception as e:
            vprint("    [ERROR] {}".format(e), SLOT_ERR)
            return False

    try:
        header, decompressed = decompress_rsc7(data)
    except ValueError as e:
        vprint("    [ERROR] {}".format(e), SLOT_ERR)
        return False

    if direction == 'pc2ps4' and ext in EMBEDDED_TEX_EXTS:
        textures = detect_embedded_textures(decompressed)
        if textures:
            vprint("    [SKIP] Embedded textures not supported - skipping conversion", SLOT_WARN)
            vprint("           {} texture(s) found:".format(len(textures)), SLOT_WARN)
            for tex in textures:
                vprint("             - {}".format(tex['name']), SLOT_SKIP)
            return False

    if direction == 'pc2ps4':
        count = decompressed.count(GTAV1_LE)
        if count > 0:
            decompressed = decompressed.replace(GTAV1_LE, PS4_LE)
            vprint("    [FIX] Replaced {}x GTAV1 -> PS4 value".format(count), SLOT_FIX)
        else:
            vprint("    [OK]  No GTAV1 found (already PS4 compatible)", SLOT_OK)
    else:
        count = decompressed.count(PS4_LE)
        if count > 0:
            decompressed = decompressed.replace(PS4_LE, GTAV1_LE)
            vprint("    [FIX] Replaced {}x PS4 -> GTAV1 value".format(count), SLOT_FIX)
        else:
            vprint("    [OK]  No PS4 value found (already PC compatible)", SLOT_OK)

    output = recompress_rsc7(header, decompressed)

    try:
        with open(out_path, 'wb') as f:
            f.write(output)
        vprint("    [SAVED] {} ({:,} bytes)".format(
            os.path.basename(out_path), len(output)), SLOT_SAVED)
        return True
    except Exception as e:
        vprint("    [ERROR] Cannot save: {}".format(e), SLOT_ERR)
        return False


def collect_files(paths):
    files = []
    for path in paths:
        expanded = glob.glob(path)
        if not expanded:
            expanded = [path]
        for p in expanded:
            if os.path.isdir(p):
                for root, dirs, filenames in os.walk(p):
                    for fname in filenames:
                        if os.path.splitext(fname)[1].lower() in ALL_EXTS:
                            files.append(os.path.join(root, fname))
            elif os.path.isfile(p):
                files.append(p)
            else:
                vprint("[WARN] Not found: {}".format(p), SLOT_WARN)
    return files


def _fmt_elapsed(seconds):
    if seconds < 60:
        return "{:.3f}s".format(seconds)
    m = int(seconds // 60)
    s = seconds % 60
    return "{}m {:.3f}s".format(m, s)


def _prompt_delete(pc_files):
    print()
    rdiv('-', DIVIDER_WIDTH, slot=1)
    vprint("  {} PC source file(s) were converted.".format(len(pc_files)), slot=6)
    vprint("  Delete the original PC files? [y/N]: ", slot=1)

    try:
        answer = input().strip().lower()
    except (EOFError, KeyboardInterrupt):
        answer = ''

    if answer != 'y':
        vprint("  Keeping original PC files.", slot=3)
        return

    deleted = failed = 0
    for fp in pc_files:
        try:
            os.remove(fp)
            vprint("    [DELETED] {}".format(os.path.basename(fp)), SLOT_WARN)
            deleted += 1
        except Exception as e:
            vprint("    [ERROR] Could not delete {}: {}".format(
                os.path.basename(fp), e), SLOT_ERR)
            failed += 1
    vprint("  Deleted: {}  Failed: {}".format(deleted, failed), slot=2)


def main():
    if sys.platform == 'win32':
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

    print_header()

    rdiv('=', DIVIDER_WIDTH, slot=5)
    vprint("  Vans Model Converter for GTA 5 PS4 v1.5", slot=6)
    rdiv('=', DIVIDER_WIDTH, slot=5)
    vprint("  PC -> PS4:  .yft .ydr .ydd .ypt .ybn .ybd .yld", slot=4)
    vprint("              .yed .yfd .ynd .ynv .yvr .ywr .ypdb", slot=4)
    vprint("              .ycd .ymap .ytyp .ymt .ymf", slot=4)
    vprint("  PS4 -> PC:  .oft .odr .odd .opt .obn .obd .old", slot=4)
    vprint("              .oed .ofd .ond .onv .ovr .owr .opdb", slot=4)
    vprint("              .ocd .omap .otyp .omt .omf", slot=4)
    rdiv('=', DIVIDER_WIDTH, slot=5)
    print()

    if len(sys.argv) < 2:
        vprint("USAGE:", slot=2)
        vprint("  python vansconverter.py vehicle.yft", slot=3)
        vprint("  python vansconverter.py *.yft *.ydr *.ydd", slot=3)
        vprint("  python vansconverter.py C:\\path\\to\\folder\\", slot=3)
        vprint("  python vansconverter.py vehicle.oft  (PS4->PC)", slot=3)
        sys.exit(0)

    files = collect_files(sys.argv[1:])

    if not files:
        vprint("[ERROR] No supported files found!", slot=SLOT_ERR)
        vprint("Supported PC : .yft .ydr .ydd .ypt .ybn .ybd .yld .yed .yfd .ynd .ynv .yvr .ywr .ypdb .ycd .ymap .ytyp .ymt .ymf", slot=4)
        vprint("Supported PS4: .oft .odr .odd .opt .obn .obd .old .oed .ofd .ond .onv .ovr .owr .opdb .ocd .omap .otyp .omt .omf", slot=4)
        sys.exit(1)

    vprint("Found {} file(s) to convert:".format(len(files)), slot=6)
    print()
    rdiv('-', DIVIDER_WIDTH, slot=5)

    start_time   = time.perf_counter()
    success      = failed = 0
    converted_pc = []

    for idx, filepath in enumerate(files):
        ext = os.path.splitext(filepath)[1].lower()
        ok  = process_file(filepath)
        if ok:
            success += 1
            if ext in PC_TO_PS4:
                converted_pc.append(filepath)
        else:
            failed += 1
        rdiv('-', DIVIDER_WIDTH, slot=(idx + 2) % 8)

    elapsed_str = _fmt_elapsed(time.perf_counter() - start_time)

    print()
    rdiv('=', DIVIDER_WIDTH, slot=3)
    vprint("  DONE!  {} converted,  {} failed".format(success, failed), slot=2)
    vprint("  Time elapsed: {}".format(elapsed_str), slot=1)
    rdiv('=', DIVIDER_WIDTH, slot=3)

    if converted_pc:
        _prompt_delete(converted_pc)


if __name__ == "__main__":
    main()

@echo off
cd /d "%~dp0"
"ragebuilder.exe" archive_builder.lua
echo.\
pause

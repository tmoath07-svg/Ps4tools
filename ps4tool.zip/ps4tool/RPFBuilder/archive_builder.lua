function save_archive(packfile)
	save_pack(packfile)
	close_pack()
end


local ROOT = "archive_input/"

local function addList(path)

    local files = find_files(path .. "/*.*")
    if files then
        for _, file in pairs(files) do
            local fullPath = path .. "/" .. file
            local relativePath = string.gsub(fullPath, "^" .. ROOT, "")
			add_to_pack(fullPath, relativePath, 1)
        end
    end
    local dirs = find_dirs(path)
    if dirs then
        for _, dir in pairs(dirs) do
            addList(path .. "/" .. dir)
        end
    end
end
print_version()
start_uncompressed_pack()
local archive_file = "Archive.rpf"
addList(ROOT)
save_archive(archive_file)



#!/usr/bin/env python3
"""
build_rpf.py — PS4 GTA V RPF Builder
Wraps ragebuilder.exe via xow64 Wine (Android/Termux) or native Wine/Windows.

Setup:
    1. Place this script in the same folder as ragebuilder.exe and all its DLLs
    2. Pass the source directory as the first argument
    3. Run: python3 build_rpf.py <source_directory>

Output: Archive.rpf
"""

import os
import sys
import subprocess
import shutil
import platform
import glob

SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
# Build directly from the supplied archive_input directory.
# Falls back to the legacy RPFBuilder/archive_input only when run manually
# without an argument.
INPUT_DIR   = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(SCRIPT_DIR, "archive_input")
OUTPUT_RPF  = os.path.join(SCRIPT_DIR, "Archive.rpf")
RAGEBUILDER = os.path.join(SCRIPT_DIR, "ragebuilder.exe")
XOW64       = os.path.expanduser("~/xow64")
WINE_C      = os.path.expanduser("~/.xow64_wine/drive_c")


def collect_files():
    if not os.path.isdir(INPUT_DIR):
        print(f"[!] Build input folder not found:\n    {INPUT_DIR}")
        sys.exit(1)
    entries = []
    for dirpath, dirnames, filenames in os.walk(INPUT_DIR):
        dirnames.sort(key=str.lower)
        for fname in sorted(filenames, key=str.lower):
            disk = os.path.join(dirpath, fname)
            arc  = os.path.relpath(disk, INPUT_DIR).replace(os.sep, "/")
            entries.append((arc, disk))
    return entries


def generate_lua_xow64(entries):
    """Generate a recursive pack script rooted at the exact staged folder.

    ragebuilder's add_to_pack_path expects a directory root plus a relative
    filename. Passing a complete source filename can make it concatenate the
    two without a separator (e.g. C:\\NRL_BUILDcontent.xml), which produces
    an empty Archive.rpf. Keep the same addList pattern as the known-good
    archive_builder.lua and let the builder discover files from the root.
    """
    lines = [
        'local ROOT = "7NRL_BUILD/"',
        '',
        'local function addList(path)',
        '    local files = find_files(path .. "/*.*")',
        '    if files then',
        '        for _, file in pairs(files) do',
        '            local fullPath = path .. "/" .. file',
        '            local relativePath = string.gsub(fullPath, "^" .. ROOT, "")',
        '            add_to_pack(fullPath, relativePath, 1)',
        '        end',
        '    end',
        '    local dirs = find_dirs(path)',
        '    if dirs then',
        '        for _, dir in pairs(dirs) do',
        '            addList(path .. "/" .. dir)',
        '        end',
        '    end',
        'end',
        '',
        'print_version()',
        'start_uncompressed_pack()',
        'addList(ROOT)',
        'save_pack("Archive.rpf")',
        'close_pack()',
    ]
    return "\n".join(lines) + "\n"

def generate_lua_native(entries):
    """Lua for Windows/Linux Wine — native paths."""
    lines = ["start_uncompressed_pack()"]
    for arc_path, disk_path in entries:
        disk_esc = disk_path.replace("\\", "\\\\").replace("'", "\\'")
        lines.append(f"add_to_pack('{disk_esc}', '{arc_path}', 1)")
    lines += [
        "save_pack('Archive.rpf')",
        "close_pack()",
    ]
    return "\n".join(lines) + "\n"


def main():
    print("=" * 50)
    print("  PS4 GTA V RPF Builder")
    print("=" * 50)

    if not os.path.isfile(RAGEBUILDER):
        print(f"[!] ragebuilder.exe not found in:\n    {SCRIPT_DIR}")
        sys.exit(1)

    # Never let a previous build be reused as a successful result.
    try:
        if os.path.isfile(OUTPUT_RPF):
            os.remove(OUTPUT_RPF)
    except OSError:
        pass
    try:
        stale = os.path.join(WINE_C, "Archive.rpf")
        if os.path.isfile(stale):
            os.remove(stale)
    except OSError:
        pass

    entries = collect_files()
    if not entries:
        print(f"[!] No files found in build input:\n    {INPUT_DIR}")
        sys.exit(1)

    dirs = set(os.path.dirname(e[0]) for e in entries if os.path.dirname(e[0]))
    print(f"[*] Found {len(entries)} file(s) in {len(dirs)+1} folder(s)")
    print(f"[*] Source: {INPUT_DIR}")

    # -----------------------------------------------------------------------
    # xow64 (Android/Termux)
    # -----------------------------------------------------------------------
    if os.path.isfile(XOW64):
        print("[*] Mode: xow64 Wine (Android/Termux)")

        print("[*] Copying files to Wine C drive (mirrored, collision-safe)...")
        shutil.copy2(RAGEBUILDER, WINE_C)
        for dll in glob.glob(os.path.join(SCRIPT_DIR, "*.dll")):
            shutil.copy2(dll, WINE_C)
        staging_c = os.path.join(WINE_C, "7NRL_BUILD")
        shutil.rmtree(staging_c, ignore_errors=True)
        os.makedirs(staging_c, exist_ok=True)
        for arc_path, disk_path in entries:
            target = os.path.join(staging_c, *arc_path.split('/'))
            os.makedirs(os.path.dirname(target), exist_ok=True)
            shutil.copy2(disk_path, target)

        # Verify the exact C-drive paths that the Lua script will use.
        missing_stage = []
        for arc_path, disk_path in entries:
            staged = os.path.join(WINE_C, "7NRL_BUILD", *arc_path.split('/'))
            if not os.path.isfile(staged):
                missing_stage.append(arc_path)
        if missing_stage:
            print("[!] Build staging is incomplete; missing files:")
            for name in missing_stage[:50]:
                print(f"    ❌ {name}")
            sys.exit(1)

        lua      = generate_lua_xow64(entries)
        lua_path = os.path.join(WINE_C, "_build.lua")
        with open(lua_path, "w") as f:
            f.write(lua)

        print(f"[*] Running ragebuilder...")
        print()
        result = subprocess.run(
            [XOW64, "r", "ragebuilder.exe", "_build.lua"],
            cwd=WINE_C
        )

        out_wine = os.path.join(WINE_C, "Archive.rpf")
        if os.path.isfile(out_wine) and os.path.getsize(out_wine) > 0:
            shutil.copy2(out_wine, OUTPUT_RPF)

        for f in ["_build.lua", "ragebuilder.exe", "Archive.rpf"]:
            try: os.remove(os.path.join(WINE_C, f))
            except: pass
        shutil.rmtree(os.path.join(WINE_C, "7NRL_BUILD"), ignore_errors=True)

    # -----------------------------------------------------------------------
    # Windows native
    # -----------------------------------------------------------------------
    elif platform.system() == "Windows":
        print("[*] Mode: Windows native")
        lua      = generate_lua_native(entries)
        lua_path = os.path.join(SCRIPT_DIR, "_build.lua")
        with open(lua_path, "w") as f:
            f.write(lua)
        print("[*] Running ragebuilder...")
        subprocess.run([RAGEBUILDER, lua_path], cwd=SCRIPT_DIR)
        try: os.remove(lua_path)
        except: pass

    # -----------------------------------------------------------------------
    # Standard Wine (Linux/macOS)
    # -----------------------------------------------------------------------
    else:
        wine = shutil.which("wine") or shutil.which("wine64")
        if not wine:
            print("[!] Wine not found.")
            print("    Android: install xow64 (~/xow64 install)")
            print("    Linux:   sudo apt install wine")
            sys.exit(1)
        print(f"[*] Mode: Wine ({wine})")
        lua      = generate_lua_native(entries)
        lua_path = os.path.join(SCRIPT_DIR, "_build.lua")
        with open(lua_path, "w") as f:
            f.write(lua)
        print("[*] Running ragebuilder...")
        subprocess.run([wine, RAGEBUILDER, lua_path], cwd=SCRIPT_DIR)
        try: os.remove(lua_path)
        except: pass

    print()
    if os.path.isfile(OUTPUT_RPF):
        size = os.path.getsize(OUTPUT_RPF)
        print(f"[+] Done! Archive.rpf ({size:,} bytes)")
        print(f"    Saved to: {OUTPUT_RPF}")
    else:
        print("[!] Archive.rpf was not created.")
        sys.exit(1)


if __name__ == "__main__":
    main()

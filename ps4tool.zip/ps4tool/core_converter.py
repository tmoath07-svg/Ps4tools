

import sys
import os
import glob
import gc
import struct
import zlib
import subprocess
import shutil
import platform
import time
import math
import random
from pathlib import Path

def _supports_ansi():
    if os.environ.get('NO_COLOR') or os.environ.get('TERM') == 'dumb': return False
    if sys.platform == 'win32':
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.GetStdHandle(-11)
            mode = ctypes.c_ulong(0)
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                kernel32.SetConsoleMode(handle, mode.value | 0x0004)
            return True
        except: return False
    try: return sys.stdout.isatty()
    except: return False

ANSI = _supports_ansi()
RESET = '\033[0m' if ANSI else ''

def _col(r, g, b, text):
    if not ANSI: return text
    return '\033[38;2;{};{};{}m{}{}'.format(r, g, b, text, RESET)

def clear_7md_screen():
    if ANSI:
        sys.stdout.write("\033[H\033[2J")
        sys.stdout.flush()

def type_7md_text(text, speed=0.001):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    print()

def print_7md_gradient_line(length=55, step_offset=0):
    if not ANSI:
        print("=" * length)
        return
    line_str = ""
    for i in range(length):
        r = int(127 + 127 * math.sin(0.1 * i + step_offset))
        g = int(200 + 55 * math.cos(0.05 * i + step_offset))
        b = int(255)
        line_str += '\033[38;2;{};{};{}m═'.format(r, g, b)
    print(line_str + RESET)

def print_7md_ultimate_banner():
    """Render the original 7N-RL OneIraq logo from the supplied reference image.

    The logo artwork itself is kept unchanged; it is stored as compressed RGB
    pixels so the banner does not depend on Pillow or any external image tool.
    On ANSI/true-colour terminals it is reconstructed with Unicode half-blocks.
    """
    if not ANSI:
        print("\n        7N-RL ONEIRAQ")
        print("          GTA V CONVERTER")
        print("============================================================")
        return

    import base64
    import zlib

    _logo_b64 = (
        'eNrdWgmQHNV5nn7362u6e7rnnp3d2ZnZmZ3ZS1hrpJVWlhArI4yEJCTLWCWRGJCTYETFgcQ4HA4YbJDk2K5yQDYOThURAQnMGSDI'
        'dnGkHFI5XKkyVTZJyuLSYSMoHJUIkjb/694ZjbQJgSBlJb96+/b1u/r9/b3/fBOLvb+kaSp3JEIE0/0TRqHjx/xmJA1hKDMTf9Rz'
        'zU9IRPKZT6amIfhToIYlkw5poxlSZ1bO8Sf+GBG9PYVi3G3oWgf9KJx7ZlENaMKOu9f/ReGKH1IiKSWEqD/AGDLBGOqcUoTxhp6u'
        'yVUT415cnXaEzhRMYyEi0skwPVBtGoFHa2BVfPQyTcNaawB8B4RpBF/ItlrTMjf3l/OCxdSn0AjSao4rWoRHM08jYiMqQgoxZr2f'
        'fyaz7h6AjzFGAVSADE4sJfR/TjFM1GxCBWMIk3PSqck1S3+rkFVHXcOtt5wuMggOrpmsEyMJhEM9PvJpq3a+Fh1pSHCq0RREWiu1'
        'xPZUgnEETVWgJ83Zn1RK/ZYRHe9ZrhdQBqugGYY1PMaxGONW+Uv/6i/bSjGiQkaAMsYZZe0U4dhZjx6nt8M/BIgDdYRhSvsdB1j7'
        'pmrpNDjGIGmYXRhhVjY+9EmZH404OQQUfThpECNTWMd0jK8sdc1y7NHA79J1OD8zKLeJcKs3v5yauB54jOHYfwvidDQ/WGIUXpQz'
        'zclVH/9KX28kvmaEWNAnTvlj7pwrWLIGQgaydgqSYm2MOcYgvv6g2lPS9ZlSzMIt9t7wc2fORgCXcvHeEvjDJNDRGiEml28vHd/W'
        'qM4UxJga6Qtuk6VzFLKInLoXAceClDYI+fORxupUMFPGNne7eq9/yfnY1ZoyCDXgNGU/hYlMS1FjJ2rtxukDOkdGNXhdwpCHLlh0'
        'Z7MyU/hqiOo9C7hbdAcv4MmGUqeITOnc950iid5ZdiaqxLEmCFnX0wU22Lm+02fqM2V7aKHlQ3WvetPu4PxbMVJKSBnGykSeShF2'
        '7To+Pk1v6ewAWy1UeqhmxydXTmzur0SneyatZo0C1Xp6FrVygGxi1hq9OBbZTZGdHDmA73854NM27g7jV1ZLNQN0rjbPdXOc41D7'
        'zrCj0DpchFm91/5LevU2jBEJeVkLwSCdqBFMOnCPHknrORZaa6DnWOg0jfoe6NxrerpOO99IMZnaKvV6sJlqe7Hu0Ap7YEVLi4LN'
        'pdwi1MHgSmcjhWhkNpcs87r+ao6ziEPB4xq2rDhRkp+EDtjp7B8C7oXPPla4/K8jaas835C7aYdAjqHILSJCAUo+XcgCn54fahx8'
        'RsQ9przgVtTCTDErM9UOCqWxJDn/95TnCzyP1Mi5qeQtw02H0AhQjnDDNliH7Y20MzLcEwU6zOWb45teoMIFtJWfS8i1pfzkubPr'
        'hvjNiNfh0DVu07Ku2rh99lyh2pTIgragd2x05W2Ix1s8oHj8jI/gaVP0fnektmfRaEIIkMbgHQPF7tzPZK/9OXWL7TN/xpKoiuub'
        '9RtrvSCUlSmCkMlYSjc0JZCnxDUlXJpJJZ9hiBYzs83C6m8yr3TGkR8G5rQfzp313NwRiqfiksCwYIK2beaogpEKbQHcBMfi9YnS'
        'dT/Tu+co4d4yVKJo/QlnfHrLtMDLcfk9utq9H8bNjCZypMn/NdBxwr6ReWxfCmJ0QlSwY3kVK0PadGtaO/bJj2UYeCyCeuK30drD'
        'Yv8PCkEy6pjc1hlkSyAo4ZErda1xil2Dxw2mc3osqIIxtNiSKyrQieEd4A5TZ3GdQWmFGVbA0RWAhqUgjgGNNMwMtB9TzhdilLgm'
        '1xn90Kf6vSMkqrz10uyvHsvtvjf18n3BL/4q/W/b03sfSt3zxSLs5ML5yT0PF1/dkXpiS8E0eARnNWvsvq/w07uzlbzZCUjrP31y'
        'S3n/95Ov3Jt67T4og30P5zZemMPhy266vGv/o5nd26Er9fK9wS8fSW6/rgC8tXI8te+p/EO3dFmGPHXxExLS+/XfLbz9dO7V+zO/'
        'fih15HHn8KPu4SeDp7dWUgn7onn+5I9yk49bv/hefkHDi2bV88aRx7MHdyZXjBWUqAvPKXwJHJqmgW68uK148InUqzszrz8IZfrw'
        'E8H9XygFcCAouefqwrs/SL26I7PngcxrO9MHHkvt+lrZt8zVC5KTf5t5cVvurKofRRhOkbMBaSBvf/Ls4tn13LZ16UNbncN/am2/'
        'JL24kSun4ssHnMPf9N+4JX7o9vhzm5IJU8KMekq+tTnYfaOzsHriJSOO0b+5IvfuVu+yef78Zm7JYHa8mX/yyvzBbzifnR/cuDT3'
        'zp8ltqwM5tSzS4ZyCxvZef3Z80bySUcuH0ocvcP/0Sa3L2OeOnqn+JeQetptZoO7Vvrv3Gwf+FL87k/5470pQ7BVg+6Rr/ivf9F+'
        '7QbjpWvS53Y7ML6RlG/fGLzyh/ZENUjpLGvSjMGyBoMS6H3hc8kjN1tXL0hX04lqMt4TOI9ckpncat+6NHfX6tzkFnvbqmC4EFSS'
        'zqy8v6DH/3gl5Rly2YB3dIv37MZELW2danoj1+Cq4fiBdeah9fp3x805XUE9oS4XVpXiRy83dy7W19fdQ5fI5z/h2lJW4+zAeutn'
        'K/SLq8kXL3J/+Slrz1p731prz8XOknxi13nOOxvklQNem6HvXuRMXmp8vpn4+jz/6KX6HeOeK0DWxX6n3957sf3KGv2OMWdtn+ra'
        'tdSquDJ2ai5pI2WjPCaEEox+6yPOoVVy90rzq6NePR53BIXeC4vWuxdbD88zN9ZTu1dZLy21J5J2j0HfWBn/6RJjbSn48bLEP11o'
        '/v0y+x+Xmy8sc367mnx2sXtwpdxUcxmhOLykvHte/N211jV17xuz/SNA3aiTMiR0Xdbw9q9x37lI3znP2dRI/ecaY9ciuy8u0cmn'
        't63yppTerUX71wPsYBN9rUs2LTNLp/TCioScHKZPlUWPZXwmbb4xSJ+q8AnH3Nek/97HFjnGfN8esc1By2haRtkyRx37mZr+ZgNd'
        'BmwINlv4Xb9XkkeH0ecy8du7rcNDaHM3aDvAF3w0sjHNj4ygbxXkhmz84DB5rMKzuojc7ZMYJItuyrowaWA8SLCJ0FVp85+r7Pkq'
        'vzFrgL+fpmSE4BzCS1z9J3WxsygXSrHBkm+UxTNFsT7l/qAiHi+JsyzdwjTNWJLRbs7HpFjA5bNFub9Er08YA5QZ4eXLloL1qyr/'
        'csL8TsZ8u0LuyuhzOU+FhtDlnjzUx/4yzb8QWG9W2NMFuUTKbnVxgE8mwypTB39byLcQeouQqzivcp4Dk1PThJIU2gbGj2C8XYqA'
        'UIa035diP8IvI/RmDP2YshEhwDBlytQ4ZhcNcfEPlO7T0B4N7Y2hvRo6QNgaxns5b3DxIONvatqesPc1Df0HwreBMc/Fl6V+IKa9'
        'rtrxXg1D5QBCz3KRbrnkJ01AaegmXT6NyUMIXSFlmqvrzoipoW+V4H/H6Q1c5NTBi53DxXNC7NDwwwjfyfhs04h1XDpH96guIQ/o'
        '+qMY7UDogTB/H+F1UgD0BKGvSrmL0vvC9h0IP4LwtVwEnK8V8nnO70fagwjtVF0I9nMnpcPqVJ80Jo7cw6plfjRh91pybiLhhQIT'
        'tT5pRsrxpDfLAelhAeAOY4uzQZ9l9FlyyNbH08noo3WY+qo2lvKGYYpp1iy9bukVSx8LPIOoaFgtbs3xnV5TQlfNhi75Uc9OwvmR'
        'YnE2WbX0/rhRt3XI8Iph1xpJOCc1yq2FMgE5hMQptghBx8sHwM7G0E6n4nbgesSQhYjHeNqSklBNI1GEEEwqRkhMGZoYzE2HEodS'
        'X3D4RC7wLzjalIFcAhPd49wXIiGYDS8l1AGZheFTYBEDAaKygYiFYT8qs5m4WtcF6cnLnpwoZkUxxwOfC86G+rPJhL58YTfWYrap'
        'u5ZYe145borunNeeuHCs6MXF0gU9tsEnxqpglvX3ZkxDH/9ItlRw+stuqcupleJnNXxdop68yKdZIcO6sixIiFNzd6G1PNG2o3di'
        'hkaKsSGILsCpwVAKUKgEWwbXuegpWMIwpWAAblfG4owUcz6401GYt5iNG4Ys5hxDF11ZsJ6k74EfIJOe4blmOmX5XjztW+Vun0kB'
        'XpJhMAP8KVNIhlv36Z35/0ykFsVpj/1047gfcUz3w4/P4QEWbio9e35MY6naIKIys/ATrS2h9FljTDcjpe41ZsU04o0twjB+dNzI'
        'Fp1Kgwcpr3/ESObNobPNvmFu+1YqbxXKXnlAT+aDuYtDpxodv6n2PtAHNzE6aUQhARqKdVA9LfaAWsH6MKsphAsj04UxYRz4mJnJ'
        'NHhz0VLcTSCkRAGAJBIpTJkeZInUoZ0aFjNsyrhwE8y0qe0y28VEBb2Z6Yi4r5bzAm3qV1MnZBRr/bjiA51gt6cc1IaC+lDQN5Co'
        'NBPVAb82HNSGVb3SDOqDydoQVLxq0+8bgGF+dcALh6l6bUi1V5tBrZko1xPVpleuh+uE9XCKX234fVBvJPoGE6o+6JWqgF2i0u/3'
        'Nbxyf6LcCOuwQr9X6k9UB5N19UYXFiz3+5VGUBtMwAqwmdpgtAGY4teH/XI/Qh/YAsFcUKHDBydQCgklFQZROXyUOoUsol5Vj8aQ'
        'Y42SqnaD6ka0jhqvt6dL1SWiwapOoroMp7QWUe3HFjTUBsLeqWHtF4UtGJbl0T51gPi/ADTzJJ8='
    )

    raw = zlib.decompress(base64.b64decode(_logo_b64))
    src_w, src_h = 80, 46

    try:
        terminal_width = max(1, shutil.get_terminal_size((80, 24)).columns)
    except Exception:
        terminal_width = 80

    # The source artwork is 80x46 pixels.  A terminal half-block cell is
    # roughly twice as tall as it is wide, so rendering all 80 columns makes
    # the logo — especially the 7N-RL lettering — look stretched and broken.
    # Keep the source height and use 40 terminal columns: two source pixels
    # per horizontal cell gives the original visual aspect ratio.
    target_w = min(40, max(20, terminal_width - 2))
    if target_w != src_w:
        pixels = bytearray(target_w * src_h * 3)
        for y in range(src_h):
            for x in range(target_w):
                sx = min(src_w - 1, int(x * src_w / target_w))
                si = (y * src_w + sx) * 3
                di = (y * target_w + x) * 3
                pixels[di:di+3] = raw[si:si+3]
        raw = bytes(pixels)
        src_w = target_w

    # Two source pixels become one terminal cell: top pixel in the foreground
    # and bottom pixel in the background of a half block. This preserves the
    # exact red/gold/blue artwork much more faithfully than ASCII characters.
    rows = (src_h + 1) // 2
    left_pad = max(0, (terminal_width - src_w) // 2)
    BLACK = 10

    def px(x, y):
        if y >= src_h:
            return (0, 0, 0)
        i = (y * src_w + x) * 3
        return raw[i], raw[i + 1], raw[i + 2]

    for row in range(rows):
        out = [" " * left_pad]
        top_y = row * 2
        bot_y = top_y + 1
        for x in range(src_w):
            top = px(x, top_y)
            bot = px(x, bot_y)
            if max(top) <= BLACK and max(bot) <= BLACK:
                out.append(" ")
                continue
            out.append(
                f"\033[38;2;{top[0]};{top[1]};{top[2]}m"
                f"\033[48;2;{bot[0]};{bot[1]};{bot[2]}m▀"
            )
        out.append(RESET)
        print("".join(out))

def run_7md_intro_cosmic_show():

    if not ANSI: return

    sys.stdout.flush()
    

    end_warp = time.time() + 0.6
    stars = [{"x": random.randint(-25, 25), "y": random.randint(-12, 12), "z": random.randint(1, 20)} for _ in range(35)]
    clear_7md_screen()
    while time.time() < end_warp:
        sys.stdout.write("\033[H")
        screen = [[" " for _ in range(60)] for _ in range(22)]
        for s in stars:
            s["z"] -= 0.6
            if s["z"] <= 0:
                s["x"], s["y"], s["z"] = random.randint(-25, 25), random.randint(-12, 12), 20
            sx = int(30 + (s["x"] * 12) / s["z"])
            sy = int(11 + (s["y"] * 6) / s["z"])
            if 0 <= sx < 60 and 0 <= sy < 22:
                b_val = int(255 * (1 - s["z"] / 20))
                screen[sy][sx] = _col(b_val, b_val, 255, "█" if s["z"] < 5 else "•")
        sys.stdout.write("\n".join("".join(r) for r in screen) + "\n")
        sys.stdout.flush()
        time.sleep(0.02)


    end_dna = time.time() + 1.5
    t = 0
    clear_7md_screen()
    while time.time() < end_dna:
        pos1 = int(25 + 18 * math.sin(t))
        pos2 = int(25 + 18 * math.sin(t + math.pi))
        line = [" "] * 60
        start, end = min(pos1, pos2), max(pos1, pos2)
        for i in range(start + 1, end): line[i] = _col(45, 45, 45, "─")
        line[pos1] = _col(0, 255, 200, "🔴")
        line[pos2] = _col(255, 0, 150, "🔵")
        sys.stdout.write("".join(line) + "\n")
        sys.stdout.flush()
        t += 0.3
        time.sleep(0.02)
    
    clear_7md_screen()

    sys.stdout.flush()

def run_7md_glitch_text_fx(target_text, duration=0.4):

    if not ANSI:
        print(target_text)
        return
    glitch_chars = "!@#$%^&*()_+{}|:<>?-=[]\\;',./"
    end_time = time.time() + duration
    while time.time() < end_time:
        glitched = ""
        for char in target_text:
            if char.isspace():
                glitched += " "
            elif random.random() < 0.30:
                glitched += _col(255, 60, 60, random.choice(glitch_chars))
            else:
                glitched += _col(0, 255, 255, char)
        sys.stdout.write(f"\r{glitched}")
        sys.stdout.flush()
        time.sleep(0.04)
    sys.stdout.write(f"\r{target_text}\n")
    sys.stdout.flush()

def run_7md_fluid_bar_fx(prefix_text, total_steps=15):

    if not ANSI: return
    for step in range(total_steps + 1):
        pct = int((step / total_steps) * 100)
        bar_len = 20
        filled = int(bar_len * (step / total_steps))
        
        bar_str = ""
        for i in range(bar_len):
            if i < filled:
                r = int(127 + 127 * math.sin(0.4 * i + step * 0.5))
                g = int(150 + 105 * math.cos(0.3 * i + step * 0.5))
                bar_str += _col(r, g, 255, "█")
            else:
                bar_str += _col(45, 45, 45, "░")
                
        sys.stdout.write(f"\r  ├── {prefix_text} [{bar_str}] {pct}%")
        sys.stdout.flush()
        time.sleep(0.02)
    print()

def run_7md_stream_flash_fx(text, duration=0.2):

    if not ANSI:
        print(text)
        return
    end_time = time.time() + duration
    while time.time() < end_time:
        sys.stdout.write(f"\r⚡ [Core Engine Payload] -> {text} .. {random.randint(10,99)}%")
        sys.stdout.flush()
        time.sleep(0.04)
    sys.stdout.write(f"\r{text}\n")
    sys.stdout.flush()










_7MD_SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
_7MD_RAGEBUILDER = os.path.join(_7MD_SCRIPT_DIR, "ragebuilder.exe")
_7MD_LUA_SCRIPT  = os.path.join(_7MD_SCRIPT_DIR, "texture_builder.lua")
_7MD_XOW64       = os.path.expanduser("~/xow64")
_7MD_WINE_C      = os.path.expanduser("~/.xow64_wine/drive_c")
_7MD_REQUIRED_DLLS = ["xg.dll", "zlib.dll", "zlib1.dll"]

RSC7_MAGIC = b"RSC7"
DDS_MAGIC  = b"DDS "
GTAV1_LE   = struct.pack('<Q', 0x7755555555996996)
PS4_LE     = struct.pack('<Q', 8598872888530528406)

_7MD_ALL_SUPPORTED_TYPES = {
    '.yft':  {'out': '.oft',  'patch': True,  'desc': '🚀 Fragment Model'},
    '.ydr':  {'out': '.odr',  'patch': True,  'desc': '💎 Drawable Model'},
    '.ydd':  {'out': '.odd',  'patch': True,  'desc': '📦 Drawable Dictionary'},
    '.ypt':  {'out': '.opt',  'patch': True,  'desc': '✨ Particle Effect'},
    '.ybn':  {'out': '.obn',  'patch': True,  'desc': '🚧 Collision Bounds'},
    '.ybd':  {'out': '.obd',  'patch': True,  'desc': '🗺️ Bounds Dictionary'},
    '.yld':  {'out': '.old',  'patch': True,  'desc': '🧵 Cloth Data'},
    '.yed':  {'out': '.oed',  'patch': True,  'desc': '🙂 Expression Dictionary'},
    '.yfd':  {'out': '.ofd',  'patch': True,  'desc': '🎞️ Frame Filter Dictionary'},
    '.ynd':  {'out': '.ond',  'patch': True,  'desc': '🛣️ Path Nodes'},
    '.ynv':  {'out': '.onv',  'patch': True,  'desc': '🧭 Navigation Mesh'},
    '.yvr':  {'out': '.ovr',  'patch': True,  'desc': '🚗 Vehicle Records'},
    '.ywr':  {'out': '.owr',  'patch': True,  'desc': '📍 Waypoint Recordings'},
    '.ypdb': {'out': '.opdb', 'patch': True,  'desc': '🧩 Pose Matching Database'},
    '.ycd':  {'out': '.ocd',  'patch': False, 'desc': '🎬 Animation Clips'},
    '.ymap': {'out': '.omap', 'patch': False, 'desc': '🗺️ Map Placement'},
    '.ytyp': {'out': '.otyp', 'patch': False, 'desc': '🏗️ Archetype Definition'},
    '.ymt':  {'out': '.omt',  'patch': False, 'desc': '⚙️ Metadata File'},
    '.ymf':  {'out': '.omf',  'patch': False, 'desc': '📋 Manifest File'},
}

_7MD_REVERSE_TYPES = {
    cfg['out']: {'out': ext, 'patch': cfg['patch'], 'desc': cfg['desc']}
    for ext, cfg in _7MD_ALL_SUPPORTED_TYPES.items()
}
_7MD_ALL_CONVERSION_TYPES = {**_7MD_ALL_SUPPORTED_TYPES, **_7MD_REVERSE_TYPES}

def u8 (d,o): return struct.unpack_from("<B",d,o)[0]
def u16(d,o): return struct.unpack_from("<H",d,o)[0]
def u32(d,o): return struct.unpack_from("<I",d,o)[0]
def u64(d,o): return struct.unpack_from("<Q",d,o)[0]
def ptr_off(p): return p & 0x0FFFFFFF

def cstring(data, off, maxlen=256):
    end = data.find(b'\x00', off, off+maxlen)
    return (data[off:end] if end!=-1 else data[off:off+maxlen]).decode("latin-1","replace")

def decode_rsc7_size(flag):
    base = (((flag >> 17) & 0x7f) + (((flag >> 11) & 0x3f) << 1) + 
            (((flag >>  7) & 0x0f) << 2) + (((flag >>  5) & 0x03) << 3) + 
            (((flag >>  4) & 0x01) << 4))
    return base * (0x2000 << (flag & 0xF))

def decompress_payload(data):
    """Best-effort RSC7 payload decompression.
    Supports zlib-wrapped, raw-deflate, and already-uncompressed payloads.
    Never raises for empty/tiny payloads.
    """
    if not data:
        return b""
    # zlib wrapped
    for wbits in (15, -15, 31):
        try:
            return zlib.decompress(data, wbits)
        except (zlib.error, ValueError, EOFError):
            pass
    # Some tiny/old resources are stored without compression.
    return data

def decompress_rsc7_ytd(raw):
    """Read an RSC7 YTD safely, including very small resources."""
    if not raw:
        raise ValueError("Empty file (0 bytes)")
    if len(raw) < 16:
        raise ValueError(f"File is too small for an RSC7 header ({len(raw)} bytes)")
    if raw[:4] != RSC7_MAGIC:
        raise ValueError("Not an RSC7 file")
    virt_flags = u32(raw, 8)
    virt_size = decode_rsc7_size(virt_flags)
    dec = decompress_payload(raw[16:])
    if not dec:
        raise ValueError("RSC7 payload is empty")
    # Never blindly allocate an absurd amount from a corrupt flag.
    if virt_size > 512 * 1024 * 1024:
        raise ValueError(f"Invalid virtual size: {virt_size:,} bytes")
    virt = dec[:virt_size]
    if len(virt) < virt_size:
        virt = virt.ljust(virt_size, b'\x00')
    phys = dec[virt_size:]
    return virt, phys

def parse_7md_ytd(virt, phys):
    textures = []
    tex_arr_ptr = u64(virt, 0x30); tex_count = u16(virt, 0x38)
    if tex_count == 0 or tex_count > 4096: return textures
    arr_off = ptr_off(tex_arr_ptr)
    for i in range(tex_count):
        try:
            tex_ptr = u64(virt, arr_off + i*8)
            if tex_ptr == 0: continue
            tb = ptr_off(tex_ptr)
            name_ptr = u64(virt, tb + 0x28)
            raw_name = cstring(virt, ptr_off(name_ptr)) if name_ptr else f"tex_{i}"
            # GTA V map YTDs can store texture names as pack:/foo.dds.
            # The texture dictionary hash is based on the basename (foo),
            # not the pack:/ namespace.  Strip that namespace BEFORE writing
            # the DDS filename so Orbis RageBuilder recreates the same key.
            if raw_name.lower().startswith("pack:/"):
                raw_name = raw_name[6:]
            name = raw_name.strip()
            name = "".join(c for c in name if c.isalnum() or c in "._-") or f"tex_{i}"
            width = u16(virt, tb + 0x50); height = u16(virt, tb + 0x52)
            mips = u8(virt, tb + 0x54); fmt = u32(virt, tb + 0x58)
            pix_ptr = u64(virt, tb + 0x70)
            
            total_bytes = 0; cw, ch = width, height
            for _ in range(max(mips,1)):
                if fmt in (0x31545844, 0x31495441):
                    total_bytes += max(1,(cw+3)//4) * max(1,(ch+3)//4) * 8
                elif fmt in (0x33545844, 0x35545844, 0x32495441, 0x20374342):
                    total_bytes += max(1,(cw+3)//4) * max(1,(ch+3)//4) * 16
                else:
                    total_bytes += max(1,cw) * max(1,ch) * 4
                cw = max(1, cw >> 1); ch = max(1, ch >> 1)
                
            avail = len(phys) - ptr_off(pix_ptr)
            pixels = phys[ptr_off(pix_ptr):ptr_off(pix_ptr)+min(total_bytes, avail)] if avail > 0 else b''
            textures.append({"name":name, "width":width, "height":height, "mips":max(mips,1), "fmt":fmt, "pixels":pixels})
        except: pass
    return textures

def build_7md_dds(tex):
    w,h,mips,fmt,px = tex["width"],tex["height"],tex["mips"],tex["fmt"],tex["pixels"]
    if fmt in (0x31545844, 0x31495441, 0x33545844, 0x35545844, 0x32495441, 0x20374342):
        bpb = 8 if fmt in (0x31545844, 0x31495441) else 16
        pitch = max(1,(w+3)//4) * max(1,(h+3)//4) * bpb
        pf = struct.pack("<IIIIIIII",32,4,fmt,0,0,0,0,0)
        ddsd = 0x1 | 0x2 | 0x4 | 0x1000 | 0x80000
    else:
        pitch = max(1, (w * 32 + 7) // 8)
        pf = struct.pack("<IIIIIIII",32,0x40|0x01,0,32,0x00FF0000,0x0000FF00,0x000000FF,0xFF000000)
        ddsd = 0x1 | 0x2 | 0x4 | 0x1000 | 0x8
    if mips > 1: ddsd |= 0x20000
    caps = 0x1000 | (0x400000 | 0x8 if mips > 1 else 0)
    hdr = struct.pack("<IIIIIII",124,ddsd,h,w,pitch,1,mips)
    hdr += b'\x00'*44 + pf + struct.pack("<IIII",caps,0,0,0) + b'\x00'*4
    return DDS_MAGIC + hdr + px

def check_7md_folder_size(unpacked_folder):
    total_bytes = 0
    for run_dir, dirs, files in os.walk(unpacked_folder):
        for f in files:
            if f.lower().endswith('.dds'):
                try: total_bytes += os.path.getsize(os.path.join(run_dir, f))
                except OSError: pass
    total_mb = total_bytes / (1024 * 1024)
    total_kb = total_bytes / 1024
    run_7md_fluid_bar_fx("Analyzing VRAM Texture Space", 14)
    if total_mb > 130:
        type_7md_text(_col(255, 30, 30, f"  ├── [🚨] WARNING: Total texture size ({total_mb:.2f} MB) is above 130 MB."))
        while True:
            try: answer = input(_col(255, 215, 0, "  ├── Continue and leave this YTD skipped? [Y/N]: ")).strip().lower()
            except (EOFError, KeyboardInterrupt): answer = 'n'
            if answer in ('y','yes'):
                type_7md_text(_col(255, 200, 0, "  └── [SKIPPED] YTD left untouched; continuing.")); return 'skip'
            if answer in ('n','no'):
                type_7md_text(_col(255, 80, 80, "  └── [STOPPED] YTD left untouched; conversion stopped.")); return 'stop'
            print(_col(255,80,80,"      Please enter Y or N."))
    else:
        type_7md_text(_col(0,255,120, f"  ├── [✔️] Texture memory size ({total_mb:.2f} MB / {total_kb:.1f} KB) is within 130 MB."))
    return 'ok'

def run_7md_ragebuilder_forced(temp_unpack_dir, final_otd_output):
    if platform.system() != "Windows":
        try:
            subprocess.run(["killall", "-9", "ragebuilder.exe"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["killall", "-9", "wine"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except: pass

    unique_id = f"7N-RL_batch_{int(time.time())}_{random.randint(1000, 9999)}"
    process_input_dir = os.path.join(_7MD_SCRIPT_DIR, unique_id)
    local_default_otd = os.path.join(_7MD_SCRIPT_DIR, "texture.otd")
    
    os.makedirs(process_input_dir, exist_ok=True)
    for f in glob.glob(os.path.join(temp_unpack_dir, "*.dds")): 
        shutil.copy2(f, process_input_dir)

    if os.path.exists(local_default_otd): os.remove(local_default_otd)
    
    success = False

    if os.path.isfile(_7MD_XOW64):
        shutil.copy2(_7MD_RAGEBUILDER, _7MD_WINE_C)
        shutil.copy2(_7MD_LUA_SCRIPT, _7MD_WINE_C)
        for dll in _7MD_REQUIRED_DLLS:
            dll_p = os.path.join(_7MD_SCRIPT_DIR, dll)
            if os.path.isfile(dll_p): shutil.copy2(dll_p, _7MD_WINE_C)
            
        wine_input = os.path.join(_7MD_WINE_C, "texture_input")
        if os.path.exists(wine_input): shutil.rmtree(wine_input)
        os.makedirs(wine_input, exist_ok=True)
        
        for tex in glob.glob(os.path.join(process_input_dir, "*")): 
            shutil.copy2(tex, wine_input)
            
        subprocess.run([_7MD_XOW64, "r", "ragebuilder.exe", "texture_builder.lua"], cwd=_7MD_WINE_C, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        wine_otd = os.path.join(_7MD_WINE_C, "texture.otd")
        if os.path.isfile(wine_otd): 
            shutil.move(wine_otd, final_otd_output)
            success = True
            
        for f in ["ragebuilder.exe", "texture_builder.lua", "texture.otd"] + _7MD_REQUIRED_DLLS:
            try: os.remove(os.path.join(_7MD_WINE_C, f))
            except: pass
        try: shutil.rmtree(wine_input)
        except: pass
        
    elif platform.system() == "Windows":
        def_input = os.path.join(_7MD_SCRIPT_DIR, "texture_input")
        if os.path.exists(def_input): shutil.rmtree(def_input)
        shutil.copytree(process_input_dir, def_input)
        
        subprocess.run([_7MD_RAGEBUILDER, _7MD_LUA_SCRIPT], cwd=_7MD_SCRIPT_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if os.path.isfile(local_default_otd): 
            shutil.move(local_default_otd, final_otd_output)
            success = True
        try: shutil.rmtree(def_input)
        except: pass
        
    else:
        wine = shutil.which("wine") or shutil.which("wine64")
        if wine:
            def_input = os.path.join(_7MD_SCRIPT_DIR, "texture_input")
            if os.path.exists(def_input): shutil.rmtree(def_input)
            shutil.copytree(process_input_dir, def_input)
            
            subprocess.run([wine, _7MD_RAGEBUILDER, _7MD_LUA_SCRIPT], cwd=_7MD_SCRIPT_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if os.path.isfile(local_default_otd): 
                shutil.move(local_default_otd, final_otd_output)
                success = True
            try: shutil.rmtree(def_input)
            except: pass
        
    try: shutil.rmtree(process_input_dir)
    except: pass

    time.sleep(2.5)
    return success

def _7md_atomic_write(path, data):
    """Write output atomically so a failed conversion never leaves a corrupt file."""
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_bytes(data)
        if tmp.stat().st_size != len(data):
            raise IOError("Output size verification failed")
        tmp.replace(path)
        return True
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def _7md_recompress_raw(data):
    """RSC7 resources use a raw-deflate stream after the 16-byte header."""
    return zlib.compress(data, level=6)[2:-4]


def process_7md_structural_file(filepath, destination_folder):
    basename = os.path.basename(filepath)
    ext = os.path.splitext(filepath)[1].lower()
    config = _7MD_ALL_CONVERSION_TYPES[ext]
    direction = 'PC -> PS4' if ext in _7MD_ALL_SUPPORTED_TYPES else 'PS4 -> PC'
    out_name = os.path.splitext(basename)[0] + config['out']
    out_path = os.path.join(destination_folder, out_name)

    print(_col(140, 180, 255, f"  {config['desc']} [{direction}]: {basename}"))

    try:
        size = os.path.getsize(filepath)
    except OSError:
        print(_col(255, 80, 80, "    └── ❌ Cannot read file size"))
        return False

    # A zero-byte file cannot contain a valid GTA resource. Handle it cleanly
    # instead of throwing a traceback.
    if size == 0:
        print(_col(255, 200, 0, "    └── ⚠️ Empty 0-byte file; skipped safely"))
        return False

    try:
        data = Path(filepath).read_bytes()
    except Exception as e:
        print(_col(255, 80, 80, f"    └── ❌ Read failed: {e}"))
        return False

    # Non-patched resource types are intentionally extension conversions.
    if not config['patch']:
        try:
            shutil.copy2(filepath, out_path)
            print(_col(30, 220, 30, f"    └── 📁 Copied -> archive_input/{out_name}"))
            return True
        except Exception as e:
            print(_col(255, 80, 80, f"    └── ❌ Copy failed: {e}"))
            return False

    if len(data) < 16 or data[:4] != RSC7_MAGIC:
        try:
            shutil.copy2(filepath, out_path)
            print(_col(255, 200, 0, "    └── ⚠️ Not RSC7; extension archive_input only"))
            return True
        except Exception as e:
            print(_col(255, 80, 80, f"    └── ❌ Save failed: {e}"))
            return False

    header = data[:16]
    compressed = data[16:]
    if not compressed:
        print(_col(255, 200, 0, "    └── ⚠️ RSC7 has no payload; skipped safely"))
        return False

    decompressed = None
    for wbits in (-15, 15, 31):
        try:
            decompressed = zlib.decompress(compressed, wbits)
            break
        except (zlib.error, ValueError, EOFError):
            pass

    if decompressed is None:
        # Some resources may actually contain an uncompressed payload.
        # Only use it when it is structurally plausible.
        try:
            flags = u32(header, 8)
            expected = decode_rsc7_size(flags)
            if expected and len(compressed) >= min(expected, 16):
                decompressed = compressed
        except Exception:
            decompressed = None

    if decompressed is None:
        print(_col(255, 80, 80, "    └── ❌ Could not decompress RSC7 payload"))
        return False

    original = decompressed
    if direction == 'PC -> PS4':
        count = decompressed.count(GTAV1_LE)
        if count:
            decompressed = decompressed.replace(GTAV1_LE, PS4_LE)
            run_7md_stream_flash_fx(
                _col(255, 230, 0, f"    ├── 🛠️ Fixed {count}x GTAV1 -> PS4 Tables"), 0.18
            )
    else:
        count = decompressed.count(PS4_LE)
        if count:
            decompressed = decompressed.replace(PS4_LE, GTAV1_LE)
            run_7md_stream_flash_fx(
                _col(255, 230, 0, f"    ├── 🛠️ Fixed {count}x PS4 -> GTAV1 Tables"), 0.18
            )

    try:
        payload = _7md_recompress_raw(decompressed)
        output = header + payload
        if len(output) < 16:
            raise ValueError("Generated output is too small")
        if not _7md_atomic_write(out_path, output):
            raise IOError("Atomic output failed")
        print(_col(30, 220, 30, f"    └── 💽 Saved -> archive_input/{out_name}"))
        return True
    except Exception as e:
        print(_col(255, 80, 80, f"    └── ❌ Conversion failed safely: {e}"))
        return False

def print_conversion_header():
    # Compact conversion header: separators + red title + yellow script name.
    line = '-' * 66
    print(_col(255, 255, 0, line))
    print(_col(255, 60, 60, '7USSAIN-RL&7md X 16A PRO'))
    print(_col(255, 255, 0, 'python 7N-RL_One_IRAQ.py'))
    print(_col(255, 255, 0, line))


if __name__ == "__main__":

    # Keep the original animated intro (cosmic + DNA), then clear its frame
    # and show the new requested conversion header.  This way the animation
    # is preserved without hiding the header during the actual conversion.
    run_7md_intro_cosmic_show()
    clear_7md_screen()
    print_conversion_header()
    raw_args = sys.argv[1:]

    if not raw_args:
        print(_col(255, 140, 0, "Usage: python3 7md_ultimate_converter.py <file_or_folder>"))
        sys.exit(0)

    all_paths = []
    for arg in raw_args:
        expanded = glob.glob(arg)
        all_paths.extend(expanded if expanded else [arg])

    ytd_to_process = []
    structures_to_process = []
    
    first_path = Path(all_paths[0])
    base_dir = first_path if first_path.is_dir() else first_path.parent
    archive_input_folder = base_dir / "archive_input"
    archive_input_folder.mkdir(parents=True, exist_ok=True)
    failed_folder = Path(_7MD_SCRIPT_DIR) / "Conversion failed ❌"
    failed_files = []

    def record_failed_file(path):
        """Keep failed originals safely in a clearly named folder."""
        path = Path(path)
        if not path.is_file():
            return
        try:
            failed_folder.mkdir(parents=True, exist_ok=True)
            target = failed_folder / path.name
            if target.exists():
                stem, suffix = path.stem, path.suffix
                n = 2
                while target.exists():
                    target = failed_folder / f"{stem}_{n}{suffix}"
                    n += 1
            shutil.copy2(path, target)
            failed_files.append(target.name)
        except Exception as exc:
            print(_col(255, 80, 80, f"  └── ⚠️ Could not archive failed file {path.name}: {exc}"))

    isolated_temp_root = Path(_7MD_SCRIPT_DIR) / "7N-RL_vram_buffer"
    if os.path.exists(isolated_temp_root): shutil.rmtree(isolated_temp_root)
    os.makedirs(isolated_temp_root, exist_ok=True)

    # Single-pass directory scan: much lighter than running one glob per extension
    # and far more stable when a DLC contains tens of thousands of files.
    for p_str in all_paths:
        p = Path(p_str)
        if p.is_dir():
            try:
                with os.scandir(p) as scan:
                    for entry in scan:
                        if not entry.is_file(follow_symlinks=False):
                            continue
                        suffix = Path(entry.name).suffix.lower()
                        if suffix == ".ytd":
                            ytd_to_process.append(Path(entry.path))
                        elif suffix in _7MD_ALL_CONVERSION_TYPES:
                            structures_to_process.append(Path(entry.path))
            except (OSError, PermissionError) as exc:
                print(_col(255, 200, 0, f"  └── ⚠️ Could not scan folder {p}: {exc}"))
        elif p.is_file():
            suffix = p.suffix.lower()
            if suffix == ".ytd": ytd_to_process.append(p)
            elif suffix in _7MD_ALL_CONVERSION_TYPES: structures_to_process.append(p)

    ytd_to_process = list(set(ytd_to_process))
    structures_to_process = list(set(structures_to_process))

    if structures_to_process:

        run_7md_glitch_text_fx("⚡ [STAGE 1] Processing Models, Maps & Metadata...")
        for s_file in structures_to_process:
            ok = process_7md_structural_file(str(s_file), str(archive_input_folder))
            if not ok:
                record_failed_file(s_file)
            else:
                # Keep originals during conversion. DLC One Click performs its
                # explicit cleanup gate after conversion work.
                pass
            gc.collect()

    if ytd_to_process:
        print_7md_gradient_line(55, 5.0)

        run_7md_glitch_text_fx("⚡ [STAGE 2] Unpacking & Compiling Textures safely...")
        
        for idx, f in enumerate(ytd_to_process, 1):
            print(_col(255, 215, 0, f"\n⚙️ Processing YTD [{idx}/{len(ytd_to_process)}]: {f.name}"))
            
            out_dir = isolated_temp_root / ("7N-RL" if f.stem.lower() == "7md" else f.stem)
            if os.path.exists(out_dir): shutil.rmtree(out_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            
            try:
                virt, phys = decompress_rsc7_ytd(f.read_bytes())
                textures = parse_7md_ytd(virt, phys)
                extracted = 0
                for tex in textures:
                    if not tex["pixels"]:
                        continue
                    name = tex["name"] if tex["name"].lower().endswith(".dds") else tex["name"] + ".dds"
                    safe_name = "".join(c for c in name if c not in '<>:"/\\\\|?*') or f"tex_{extracted}.dds"
                    try:
                        dds = build_7md_dds(tex)
                        if len(dds) >= 128:
                            (out_dir / safe_name).write_bytes(dds)
                            extracted += 1
                    except Exception:
                        continue

                if extracted:
                    run_7md_stream_flash_fx(
                        _col(0, 255, 150, f"  ├── 🖼️  [UNPACKED] {extracted} texture(s): {f.name}"), 0.12
                    )
                else:
                    type_7md_text(_col(255, 200, 0,
                        f"  ├── ⚠️ [YTD FAILED] No readable textures found: {f.name}; OTD build skipped safely"))
                    record_failed_file(f)
                    continue

                all_dds_files = glob.glob(os.path.join(out_dir, "*.dds"))
                cleaned_count = 0
                for dds_path in all_dds_files:
                    f_name = os.path.basename(dds_path)
                    name_without_ext = os.path.splitext(f_name)[0]
                    if name_without_ext.endswith('_'):
                        try:
                            os.remove(dds_path)
                            cleaned_count += 1
                        except: pass
                if cleaned_count > 0:
                    type_7md_text(_col(255, 230, 0, f"  ├── 🧹 [CLEANED] Removed {cleaned_count} corrupted duplicate asset keys."))

                size_status = check_7md_folder_size(str(out_dir))
                if size_status == 'skip':
                    if os.path.exists(out_dir): shutil.rmtree(out_dir)
                    record_failed_file(f)
                    continue
                if size_status == 'stop':
                    if os.path.exists(out_dir): shutil.rmtree(out_dir)
                    record_failed_file(f)
                    break

                final_otd = archive_input_folder / f"{f.stem}.otd"
                try:
                    if final_otd.exists():
                        final_otd.unlink()
                except Exception:
                    pass
                if run_7md_ragebuilder_forced(str(out_dir), str(final_otd)):
                    type_7md_text(_col(0, 255, 100, f"  └── 💾 [COMPILED OTD] -> archive_input/{final_otd.name}"))
                    # Original YTD is kept until the final DLC cleanup gate.
                    pass
                else:
                    type_7md_text(_col(255, 30, 30, f"  └── 💥 [YTD FAILED] Could not build OTD: {f.name}"))
                    record_failed_file(f)
                
                if os.path.exists(out_dir): shutil.rmtree(out_dir)
                
            except Exception as e:
                type_7md_text(_col(255, 30, 30, f"  ❌ [YTD FAILED] {f.name} — {e}"))
                record_failed_file(f)








    if os.path.exists(isolated_temp_root): shutil.rmtree(isolated_temp_root)
    if failed_files:
        type_7md_text(_col(255, 80, 80, f"[❌] Failed files: {len(failed_files)} — saved in 'Conversion failed ❌/'"), 0.01)
        for failed_name in failed_files:
            type_7md_text(_col(255, 160, 80, f"    └── {failed_name}"), 0.01)
    else:
        type_7md_text(_col(0, 255, 150, "[✅] No failed files."), 0.01)
    print_7md_gradient_line(55, 7.0)
    type_7md_text(_col(0, 255, 150, "[🎉] All processing complete! Check the 'archive_input' directory."), 0.01)
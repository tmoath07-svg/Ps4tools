#!/bin/bash
# تشغيل الأداة
cd "$(dirname "$0")"
export WINEDEBUG=-all
export PYTHONIOENCODING=utf-8
exec xvfb-run -a python3 7N-RL_One_IRAQ.py
